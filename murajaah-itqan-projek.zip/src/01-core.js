'use strict';
/* ---------- Persekitaran ---------- */
const NATIVE=!!(window.Capacitor&&Capacitor.isNativePlatform&&Capacitor.isNativePlatform());
const CFG=Object.assign({aiBase:'ai/',apkUrl:'https://github.com/edzmar536-gif/murajaah-itqan/releases/latest/download/MurajaahItqan.apk'},window.APP_CFG||{});
const D=window.QD, LAYOUT=window.QPC_LAYOUT||null;

/* ---------- Indeks Al-Quran ---------- */
const T=D.t.split('|'), N=T.length;
const SURAH=["Al-Fatihah","Al-Baqarah","Ali 'Imran","An-Nisa'","Al-Ma'idah","Al-An'am","Al-A'raf","Al-Anfal","At-Taubah","Yunus","Hud","Yusuf","Ar-Ra'd","Ibrahim","Al-Hijr","An-Nahl","Al-Isra'","Al-Kahfi","Maryam","Taha","Al-Anbiya'","Al-Hajj","Al-Mu'minun","An-Nur","Al-Furqan","Asy-Syu'ara'","An-Naml","Al-Qasas","Al-'Ankabut","Ar-Rum","Luqman","As-Sajdah","Al-Ahzab","Saba'","Fatir","Yasin","As-Saffat","Sad","Az-Zumar","Ghafir","Fussilat","Asy-Syura","Az-Zukhruf","Ad-Dukhan","Al-Jathiyah","Al-Ahqaf","Muhammad","Al-Fath","Al-Hujurat","Qaf","Az-Zariyat","At-Tur","An-Najm","Al-Qamar","Ar-Rahman","Al-Waqi'ah","Al-Hadid","Al-Mujadalah","Al-Hasyr","Al-Mumtahanah","As-Saff","Al-Jumu'ah","Al-Munafiqun","At-Taghabun","At-Talaq","At-Tahrim","Al-Mulk","Al-Qalam","Al-Haqqah","Al-Ma'arij","Nuh","Al-Jinn","Al-Muzzammil","Al-Muddaththir","Al-Qiyamah","Al-Insan","Al-Mursalat","An-Naba'","An-Nazi'at","'Abasa","At-Takwir","Al-Infitar","Al-Mutaffifin","Al-Insyiqaq","Al-Buruj","At-Tariq","Al-A'la","Al-Ghasyiyah","Al-Fajr","Al-Balad","Asy-Syams","Al-Lail","Ad-Duha","Asy-Syarh","At-Tin","Al-'Alaq","Al-Qadr","Al-Bayyinah","Az-Zalzalah","Al-'Adiyat","Al-Qari'ah","At-Takathur","Al-'Asr","Al-Humazah","Al-Fil","Quraisy","Al-Ma'un","Al-Kauthar","Al-Kafirun","An-Nasr","Al-Masad","Al-Ikhlas","Al-Falaq","An-Nas"];
const VS=new Uint8Array(N),VA=new Uint16Array(N),VP=new Uint16Array(N),VJ=new Uint8Array(N),VM=new Uint8Array(N),SS=[];
{let k=0;D.sc.forEach((c,s)=>{SS[s]=k;for(let a=1;a<=c;a++){VS[k]=s+1;VA[k]=a;k++}});SS[114]=N;
 for(let p=1;p<=604;p++)for(let i=D.pg[p-1];i<D.pg[p];i++)VP[i]=p;
 for(let j=0;j<30;j++){const e=j<29?D.jz[j+1]:N;for(let i=D.jz[j];i<e;i++)VJ[i]=j+1}
 for(let m=0;m<240;m++){const e=m<239?D.mq[m+1]:N;for(let i=D.mq[m];i<e;i++)VM[i]=m+1}}
const pageFirst=p=>D.pg[p-1], pageEnd=p=>D.pg[p];
const PJ=[0];for(let p=1;p<=604;p++){const c={};for(let i=pageFirst(p);i<pageEnd(p);i++)c[VJ[i]]=(c[VJ[i]]||0)+1;PJ[p]=+Object.keys(c).sort((a,b)=>c[b]-c[a])[0]}
const juzPages=j=>{const a=VP[D.jz[j-1]],b=j<30?VP[D.jz[j]]-(D.jz[j]===pageFirst(VP[D.jz[j]])?1:0):604;return[a,b]};
const surahPages=s=>[VP[SS[s-1]],VP[SS[s]-1]];
const maqraPages=m=>{const a=D.mq[m-1],e=(m<240?D.mq[m]:N)-1;return[VP[a],VP[e]]};
const chunkPages=(st,k)=>{const a=D.mq[st],e=(st+k<240?D.mq[st+k]:N)-1;return[VP[a],VP[e]]};
const AR=n=>String(n).replace(/\d/g,d=>'٠١٢٣٤٥٦٧٨٩'[d]);
const range=(a,b)=>{const r=[];for(let i=a;i<=b;i++)r.push(i);return r};
const surahsOnPage=p=>{const s=new Set();for(let i=pageFirst(p);i<pageEnd(p);i++)s.add(VS[i]);return[...s]};
const pageLabel=p=>surahsOnPage(p).map(x=>SURAH[x-1]).join(', ');
const esc=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const vkey=i=>VS[i]+':'+VA[i];
const vIndex=(s,a)=>SS[s-1]+a-1;
const pad3=n=>String(n).padStart(3,'0');
const HL=p=>'Halaman '+p;
const rangeText=([a,b])=>a===b?'Halaman '+a:'Halaman '+a+'–'+b;
function groupRanges(pages){const s=[...new Set(pages)].sort((a,b)=>a-b),r=[];for(const p of s){const l=r[r.length-1];if(l&&p===l[1]+1)l[1]=p;else r.push([p,p])}return r}
function chunkLabel(st,k){const j=Math.floor(st/8)+1;
  if(k>=16)return'Juz '+j+'–'+(j+k/8-1);if(k===8)return'Juz '+j;
  if(k===4)return'Hizb '+(st/4+1)+', Juz '+j;return'Suku '+((st%8)/2+1)+' Juz '+j}

/* ---------- Tarikh ---------- */
const dkey=(d=new Date())=>{const z=n=>String(n).padStart(2,'0');return d.getFullYear()+'-'+z(d.getMonth()+1)+'-'+z(d.getDate())};
const addDays=(k,n)=>{const [y,m,d]=k.split('-').map(Number);return dkey(new Date(y,m-1,d+n))};
const HARI=['Ahad','Isnin','Selasa','Rabu','Khamis','Jumaat','Sabtu'],BULAN=['Januari','Februari','Mac','April','Mei','Jun','Julai','Ogos','September','Oktober','November','Disember'];
const fmtDate=k=>{const [y,m,d]=k.split('-').map(Number);const dt=new Date(y,m-1,d);return HARI[dt.getDay()]+', '+d+' '+BULAN[m-1]};
const fmtShort=k=>{const [y,m,d]=k.split('-').map(Number);return d+' '+BULAN[m-1].slice(0,3)};

/* ---------- Ikon ---------- */
const IC={
  check:'<path d="M5 12.5l4.5 4.5L19 7.5"/>',x:'<path d="M6 6l12 12M18 6L6 18"/>',play:'<path d="M7 5l12 7-12 7z"/>',stop:'<rect x="6" y="6" width="12" height="12" rx="2"/>',
  mic:'<rect x="9" y="3" width="6" height="11" rx="3"/><path d="M5 11a7 7 0 0 0 14 0M12 18v3"/>',search:'<circle cx="11" cy="11" r="7"/><path d="M20 20l-4-4"/>',
  expand:'<path d="M4 9V4h5M20 9V4h-5M4 15v5h5M20 15v5h-5"/>',shrink:'<path d="M9 4v5H4M15 4v5h5M9 20v-5H4M15 20v-5h5"/>',eye:'<path d="M2 12s4-7 10-7 10 7 10 7-4 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/>',
  more:'<circle cx="5" cy="12" r="1.5"/><circle cx="12" cy="12" r="1.5"/><circle cx="19" cy="12" r="1.5"/>',left:'<path d="M15 5l-7 7 7 7"/>',right:'<path d="M9 5l7 7-7 7"/>',
  plus:'<path d="M12 5v14M5 12h14"/>',head:'<path d="M4 15v-3a8 8 0 0 1 16 0v3"/><rect x="3" y="14" width="5" height="7" rx="2"/><rect x="16" y="14" width="5" height="7" rx="2"/>',
  drop:'<path d="M12 3s6 7 6 11a6 6 0 0 1-12 0c0-4 6-11 6-11z"/>',book:'<path d="M2 4h6a4 4 0 0 1 4 4v13a3 3 0 0 0-3-3H2zM22 4h-6a4 4 0 0 0-4 4v13a3 3 0 0 1 3-3h7z"/>'};
const ico=(n,s=20)=>`<svg class="i" viewBox="0 0 24 24" style="width:${s}px;height:${s}px" aria-hidden="true">${IC[n]}</svg>`;

/* ---------- Palet & tema ---------- */
const PALET={
  sakura:{n:'Pink Sakura',L:['#fdf4f6','#ffffff','#e1879f','#fbe1e8','#f2dce2','#3a2930','#8a6c76'],Dk:['#1d1418','#291d22','#f0a3b8','#3e2630','#3b2a31','#f5e8ec','#b89aa4']},
  hijau:{n:'Hijau Lembut',L:['#f2f7f1','#ffffff','#5fa577','#dcefe1','#dbe8dd','#23362a','#66806d'],Dk:['#121a15','#1a251e','#8cc9a0','#213a2a','#283a2e','#e5f1e8','#93ad9b']},
  awan:{n:'Biru Awan',L:['#eef6fd','#ffffff','#5ea8de','#d9ecfa','#d5e6f3','#1f3a55','#6a84a0'],Dk:['#0f1a2b','#16253b','#8fcaf3','#1b3554','#253a56','#e4f0fb','#94aac3']},
  oren:{n:'Oren Lembut',L:['#fff6ee','#ffffff','#e58f4f','#fde5d1','#f3e0d0','#3d2a1c','#8c705c'],Dk:['#1d150f','#281d15','#f4b07c','#3d2a1b','#3a2b20','#f6eadf','#b89f8b']},
  ungu:{n:'Ungu Lembut',L:['#f5f2fc','#ffffff','#957ed3','#e7e0f7','#e3ddf2','#2c2540','#776e92'],Dk:['#16131f','#201b2d','#b9a6ee','#2f2745','#2f2942','#ece8f7','#a59dbd']}};
const mqDark=window.matchMedia?matchMedia('(prefers-color-scheme: dark)'):null;
function isDark(){const t=S.set.theme;return t==='dark'||(t!=='light'&&!!(mqDark&&mqDark.matches))}
function applyTheme(){
  const P=PALET[S.set.palette]||PALET.awan,dark=isDark(),c=dark?P.Dk:P.L,r=document.documentElement;
  ['--bg','--paper','--accent','--accent-soft','--line','--ink','--muted'].forEach((k,i)=>r.style.setProperty(k,c[i]));
  r.style.setProperty('--on-accent',dark?c[0]:'#ffffff');r.classList.toggle('dark',dark);
  const m=document.querySelector('meta[name=theme-color]');if(m)m.content=c[0];applySky()}
if(mqDark&&mqDark.addEventListener)mqDark.addEventListener('change',()=>{applyTheme()});

/* ---------- Langit ikut waktu ---------- */
function skyNow(){const h=new Date().getHours()+new Date().getMinutes()/60;
  if(h>=5&&h<7)return{k:'subuh',a:'#c9c2ec',b:'#fbd7c4',ink:'#2d2a4a',sun:[300,70,'#ffcf9e']};
  if(h>=7&&h<11)return{k:'pagi',a:'#bfe3fb',b:'#e6f4fd',ink:'#1f3a55',sun:[330,38,'#ffe3a3']};
  if(h>=11&&h<15)return{k:'tengahari',a:'#9fd2f6',b:'#d8eefc',ink:'#173750',sun:[350,22,'#fff1b8']};
  if(h>=15&&h<18.5)return{k:'petang',a:'#ffd8b0',b:'#fff0de',ink:'#4a2e15',sun:[330,48,'#ffbf7a']};
  if(h>=18.5&&h<20)return{k:'maghrib',a:'#f2a7a9',b:'#fbd2b0',ink:'#3f2130',sun:[320,82,'#ff9f7a']};
  return{k:'malam',a:'#1d2a4d',b:'#33416d',ink:'#eef2ff',moon:true}}
function applySky(){
  const s=skyNow(),hd=document.getElementById('sky');if(!hd)return;
  hd.style.setProperty('--sky1',s.a);hd.style.setProperty('--sky2',s.b);hd.style.setProperty('--sky-ink',s.ink);
  let g='';
  if(s.moon){g+=`<circle cx="340" cy="30" r="14" fill="#f6f1d3"/><circle cx="347" cy="25" r="12" fill="${s.a}"/>`;
    [[60,20],[120,45],[200,15],[250,60],[290,25],[385,55],[160,70],[30,62]].forEach(([x,y],i)=>g+=`<circle cx="${x}" cy="${y}" r="${i%3?1.3:1.9}" fill="#fff" opacity=".8"/>`)}
  else{const [x,y,c]=s.sun;g+=`<circle cx="${x}" cy="${y}" r="20" fill="${c}" opacity=".9"/>`;
    g+=`<g fill="#fff" opacity=".55"><ellipse cx="250" cy="70" rx="34" ry="10"/><ellipse cx="272" cy="62" rx="20" ry="11"/><ellipse cx="90" cy="22" rx="26" ry="8"/><ellipse cx="106" cy="16" rx="15" ry="9"/></g>`}
  document.getElementById('celestial').innerHTML=g}
