/* ---------- Kuiz ---------- */
const QZ={};
const words=i=>T[i].split(' ').filter(Boolean);
const head=(i,n=5)=>{const w=words(i);return w.slice(0,n).join(' ')+(w.length>n?' …':'')};
const tail=(i,n=6)=>{const w=words(i);return(w.length>n?'… ':'')+w.slice(-n).join(' ')};
const shuffle=a=>{a=[...a];for(let i=a.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[a[i],a[j]]=[a[j],a[i]]}return a};
function nearVerses(p,r){const out=[];for(let q=Math.max(1,p-r);q<=Math.min(604,p+r);q++)for(let i=pageFirst(q);i<pageEnd(q);i++)out.push(i);return out}
function distract(correct,fn,p){const ct=fn(correct),first=words(correct)[0],seen=new Set([ct]),out=[];
  for(const r of [3,8,20]){const c=shuffle(nearVerses(p,r).filter(i=>i!==correct)).sort((a,b)=>(words(a)[0]===first?0:1)-(words(b)[0]===first?0:1));
    for(const i of c){const t=fn(i);if(!seen.has(t)){seen.add(t);out.push(t)}if(out.length>=3)return out}}return out}
function makeQuiz(pages,n){
  const verses=[];pages.forEach(p=>{for(let i=pageFirst(p);i<pageEnd(p);i++)verses.push(i)});
  const qs=[],used=new Set(),startDone=new Set(),pool=shuffle(verses);let k=0;
  while(qs.length<n&&k<pool.length*3){const i=pool[k%pool.length];k++;const p=VP[i],r=Math.random();
    if(r<0.18&&!startDone.has(p)){startDone.add(p);const c=pageFirst(p);qs.push({label:HL(p)+' dimulakan dengan ayat apa?',ar:'',ok:head(c),opts:distract(c,x=>head(x),p),target:c});continue}
    if(used.has(i))continue;
    if(r<0.36&&VA[i]>1){used.add(i);qs.push({label:'Apakah ayat sebelum ayat ini?',ar:head(i,7),num:VA[i],ok:tail(i-1),opts:distract(i-1,x=>tail(x),p),target:i-1});continue}
    if(i+1<N&&VS[i+1]===VS[i]){used.add(i);qs.push({label:'Apakah sambungan ayat ini?',ar:tail(i,7),num:VA[i],ok:head(i+1),opts:distract(i+1,x=>head(x),p),target:i+1})}}
  return qs.map(q=>({...q,choices:shuffle([{t:q.ok,ok:true},...q.opts.map(t=>({t,ok:false}))])}))}
const KINDN={sabaq:'Sabaq',sabqi:'Sabqi',manzil:'Manzil'};
function startQuiz(cfg){const qs=makeQuiz(cfg.pages,cfg.n);if(!qs.length){cfg.onPass();return}Object.assign(QZ,{cfg,qs,i:0,score:0,wrong:[],answered:false});renderQuiz()}
function renderQuiz(){
  const {qs,i,cfg}=QZ;
  if(i>=qs.length){const pct=Math.round(QZ.score/qs.length*100),pass=pct>=70;
    openSheet(`<div class="qz-res ${pass?'pass':'fail'}"><div class="qz-pct">${pct}%</div><h3>${pass?'Lulus. Masya-Allah!':'Hampir sampai'}</h3><p class="muted" style="margin:0">${QZ.score} betul daripada ${qs.length}. ${pass?'Bacaan ini dikira lancar.':'Perlukan 70% untuk lulus. Ulang sedikit lagi, kemudian cuba semula.'}</p></div>
      ${QZ.wrong.length?`<button class="btn soft" id="qzShow">Lihat ${QZ.wrong.length} ayat untuk diulang</button><div id="qzWrong" hidden class="ranges">${QZ.wrong.map(t=>`<button data-open="${VP[t]}" data-ay="${t}" style="font-size:15px">${esc(SURAH[VS[t]-1])} ${vkey(t)}</button>`).join('')}</div><small class="muted">Ayat ini disimpan dalam tab Tanda supaya diingatkan esok.</small>`:''}
      <button class="btn pri" data-qzend="1">${pass?'Teruskan':'Baik, saya ulang dulu'}</button>`,sh=>{const b=sh.querySelector('#qzShow');if(b)b.onclick=()=>{sh.querySelector('#qzWrong').hidden=false;b.hidden=true}});return}
  const q=qs[i];
  openSheet(`<div class="qz-top"><b>Kuiz ${KINDN[cfg.kind]}</b><span class="small muted">Soalan ${i+1} daripada ${qs.length}</span></div><div class="qz-bar"><i style="width:${i/qs.length*100}%"></i></div>
    <h3>${esc(q.label)}</h3>${q.ar?`<div class="ar-big">${esc(q.ar)}${q.num?` ${AR(q.num)}`:''}</div>`:''}
    <div class="qz-opts">${q.choices.map((c,k)=>`<button class="qz-opt" data-qz="${k}">${esc(c.t)}</button>`).join('')}</div>
    <div class="row" style="justify-content:space-between"><button class="btn ghost sm" data-close="1">Batal kuiz</button><button class="btn pri" id="qzNext" hidden>${i+1<qs.length?'Seterusnya':'Lihat keputusan'}</button></div>`)}
function answerQuiz(k){if(QZ.answered)return;QZ.answered=true;const q=QZ.qs[QZ.i],c=q.choices[k];
  if(c.ok)QZ.score++;else{QZ.wrong.push(q.target);if(!openMarks().some(m=>m.i===q.target))addMark(q.target,'lupa','','kuiz '+KINDN[QZ.cfg.kind].toLowerCase())}
  document.querySelectorAll('.qz-opt').forEach((b,j)=>{b.disabled=true;if(q.choices[j].ok)b.classList.add('ok');else if(j===k)b.classList.add('no')});
  const n=document.getElementById('qzNext');n.hidden=false;n.onclick=()=>{QZ.i++;QZ.answered=false;renderQuiz()}}
function endQuiz(){const pass=QZ.score/QZ.qs.length>=0.7;closeLayer();if(pass)QZ.cfg.onPass();else QZ.cfg.onFail(QZ.wrong)}

/* ---------- Bacaan imam ---------- */
const QARI={ghamidi:{n:'Saad Al-Ghamidi',dir:'Ghamadi_40kbps'},baleela:{n:'Bandar Baleela (surah penuh)',surah:true},husary:{n:'Mahmoud Al-Husary',dir:'Husary_128kbps'},alafasy:{n:'Mishary Alafasy',dir:'Alafasy_128kbps'}};
const AP={qari:null,s:1,from:1,to:7,repA:1,repAll:1,queue:[],pos:0,playing:false,cur:null};
let AU=null;
const ayahUrl=(q,s,a)=>QARI[q].surah?`https://archive.org/download/alfirdwsiy1433_gmail_0356835683568568356856802/${pad3(s)}.mp3`:`https://everyayah.com/data/${QARI[q].dir}/${pad3(s)}${pad3(a)}.mp3`;
function playStart(){
  if(!AU){AU=new Audio();AU.preload='auto';AU.addEventListener('ended',playNext);AU.addEventListener('error',()=>{if(AP.playing){toast('Audio tidak dapat dimainkan. Semak sambungan internet.');playStop()}})}
  const Q=[];if(QARI[AP.qari].surah){for(let r=0;r<AP.repAll;r++)Q.push(vIndex(AP.s,1))}
  else for(let r=0;r<AP.repAll;r++)for(let a=AP.from;a<=AP.to;a++)for(let k=0;k<AP.repA;k++)Q.push(vIndex(AP.s,a));
  AP.queue=Q;AP.pos=-1;AP.playing=true;playNext()}
function playNext(){AP.pos++;if(AP.pos>=AP.queue.length){playStop();toast('Bacaan selesai');return}
  const i=AP.queue[AP.pos];AP.cur=i;AU.src=ayahUrl(AP.qari,VS[i],VA[i]);AU.play().catch(()=>{});
  if(!QARI[AP.qari].surah&&tab==='mushaf'&&VP[i]!==curPage){curPage=VP[i];render()}else markPlaying();renderDock()}
function playStop(){AP.playing=false;AP.cur=null;if(AU)AU.pause();markPlaying();renderDock()}
function markPlaying(){document.querySelectorAll('.w.play').forEach(e=>e.classList.remove('play'));if(AP.playing&&AP.cur!==null&&!QARI[AP.qari].surah)document.querySelectorAll(`.w[data-i="${AP.cur}"]`).forEach(e=>e.classList.add('play'))}
function playerSheet(i){
  if(i!=null){AP.s=VS[i];AP.from=VA[i];let e=i;while(e+1<pageEnd(VP[i])&&VS[e+1]===VS[i])e++;AP.to=VA[e]}
  else if(!AP.playing){const f=pageFirst(curPage);AP.s=VS[f];AP.from=VA[f];let e=f;while(e+1<pageEnd(curPage)&&VS[e+1]===VS[f])e++;AP.to=VA[e]}
  if(!AP.qari)AP.qari=QARI[S.set.reciter]?S.set.reciter:'ghamidi';
  openSheet(`<h3>Dengar bacaan imam</h3>
   <div class="field"><label for="apQ">Qari</label><select id="apQ">${Object.entries(QARI).map(([k,v])=>`<option value="${k}" ${AP.qari===k?'selected':''}>${esc(v.n)}</option>`).join('')}</select></div>
   <div class="field"><label for="apS">Surah</label><select id="apS">${SURAH.map((n,k)=>`<option value="${k+1}" ${AP.s===k+1?'selected':''}>${k+1}. ${esc(n)}</option>`).join('')}</select></div>
   <div class="grid2" id="apRange"><div class="field"><label for="apF">Dari ayat</label><input type="number" id="apF" min="1" value="${AP.from}"></div><div class="field"><label for="apT">Hingga ayat</label><input type="number" id="apT" min="1" value="${AP.to}"></div></div>
   <div class="grid2"><div class="field" id="apRAw"><label for="apRA">Ulang setiap ayat</label><input type="number" id="apRA" min="1" max="20" value="${AP.repA}"></div><div class="field"><label for="apRAll">Ulang keseluruhan</label><input type="number" id="apRAll" min="1" max="20" value="${AP.repAll}"></div></div>
   <small class="muted" id="apNote"></small>
   <div class="grid2"><button class="btn pri" id="apPlay">${ico('play',18)}Main</button><button class="btn" id="apStop">${ico('stop',18)}Henti</button></div>
   <button class="btn ghost" data-close="1">Tutup</button>`,sh=>{
    const upd=()=>{const q=sh.querySelector('#apQ').value,s=+sh.querySelector('#apS').value,surah=QARI[q].surah;
      sh.querySelector('#apRange').hidden=surah;sh.querySelector('#apRAw').hidden=surah;['#apF','#apT'].forEach(id=>sh.querySelector(id).max=D.sc[s-1]);
      sh.querySelector('#apNote').textContent=surah?'Bacaan Bandar Baleela hanya tersedia untuk surah penuh.':'Surah '+SURAH[s-1]+' ada '+D.sc[s-1]+' ayat. Perlukan internet.'};
    sh.querySelector('#apQ').onchange=upd;sh.querySelector('#apS').onchange=()=>{const s=+sh.querySelector('#apS').value;sh.querySelector('#apF').value=1;sh.querySelector('#apT').value=D.sc[s-1];upd()};upd();
    sh.querySelector('#apPlay').onclick=()=>{const g=(id,lo,hi,d)=>Math.min(hi,Math.max(lo,parseInt(sh.querySelector(id).value)||d));
      AP.qari=sh.querySelector('#apQ').value;AP.s=+sh.querySelector('#apS').value;const mx=D.sc[AP.s-1];
      AP.from=g('#apF',1,mx,1);AP.to=g('#apT',AP.from,mx,mx);AP.repA=g('#apRA',1,20,1);AP.repAll=g('#apRAll',1,20,1);
      closeLayer();selAyah=null;if(!QARI[AP.qari].surah){curPage=VP[vIndex(AP.s,AP.from)];tab='mushaf';render()}playStart()};
    sh.querySelector('#apStop').onclick=()=>{playStop();closeLayer()}})}

/* ---------- Dok bawah (audio / AI) ---------- */
function renderDock(){const d=document.getElementById('dock');
  if(AI.active){d.hidden=false;d.innerHTML=aiDock();return}
  if(!AP.playing){d.hidden=true;d.innerHTML='';return}
  const i=AP.cur;d.hidden=false;
  d.innerHTML=`<div class="dock-in"><span class="eq"><i></i><i></i><i></i></span><div class="dock-t"><b>${esc(SURAH[VS[i]-1])} ${QARI[AP.qari].surah?'(surah penuh)':vkey(i)}</b><span>${esc(QARI[AP.qari].n)}, ${AP.pos+1} daripada ${AP.queue.length}</span></div><button class="btn sm" data-player="1">Ubah</button><button class="btn sm" data-stop="1">${ico('stop',16)}Henti</button></div>`}
