/* ---------- Soalan permulaan ---------- */
const W={step:0,brush:2,jl:[]};
const WLV=[[2,'Lancar'],[1,'Sederhana'],[0,'Lemah'],[3,'Belum hafal']];
function juzLevelNow(j){const [a,b]=juzPages(j),c=[0,0,0,0];for(let p=a;p<=b;p++)c[lv(p)]++;return c.indexOf(Math.max(...c))}
function openWizard(again){const st=S.set;
  Object.assign(W,{step:0,brush:2,again:!!again,name:st.name,palette:st.palette,mode:st.sabaqMode,dir:st.sabaqDir,start:st.start,startAuto:!again,order:st.order,sabaqN:st.sabaqN,need:st.need,recentN:st.recentN,sqMaqra:st.sqMaqra,mzMaqra:st.mzMaqra,rem1:st.rem1,rem2:st.rem2,remOn:st.remOn});
  W.jl=range(1,30).map(j=>again?juzLevelNow(j):3);renderWiz()}
function wizAutoStart(){const want=W.order==='baru'?[3,0,1]:[0,1,3];let j=1;for(const v of want){const k=W.jl.findIndex(x=>x===v);if(k>=0){j=k+1;break}}
  if(W.mode==='juz')return j;const [a]=juzPages(j);if(W.mode==='surah')return VS[pageFirst(a)];return a}
function renderWiz(){
  let el=$('#wiz');if(!el){el=document.createElement('div');el.id='wiz';document.body.appendChild(el)}
  const last=NATIVE?6:5,s=W.step,cnt=[0,0,0,0];W.jl.forEach(v=>cnt[v]++);
  if(W.startAuto)W.start=wizAutoStart();
  let h=`<div class="wiz-in"><div class="row" style="justify-content:space-between;min-height:34px"><span class="small muted">Langkah ${s+1} daripada ${last+1}</span>${W.again?'<button class="btn sm ghost" data-wz="cancel">Batal</button>':''}</div><div class="qz-bar"><i style="width:${s/last*100}%"></i></div>`;
  if(s===0)h+=`<div class="wiz-hero">${document.getElementById('splash')?'':''}<svg viewBox="0 0 120 120" width="150" height="150" aria-hidden="true"><circle cx="60" cy="58" r="26" fill="#ffd9a8"/><path d="M6 96c22-14 40-14 58-6s36 8 50-2v32H6z" fill="#bfe3c6"/><path d="M0 104c26-10 46-8 66-2s38 6 54-2v20H0z" fill="#9fd3ab"/><path d="M60 98V66" stroke="#4f9a68" stroke-width="4" stroke-linecap="round"/><path d="M60 72c-3-10-12-14-20-12 2 9 10 14 20 12z" fill="#6fbf86"/><path d="M60 68c3-11 13-15 22-13-2 10-12 15-22 13z" fill="#83cc98"/></svg><h2>Assalamualaikum!</h2><p>Murajaah Itqan menyusun sabaq, sabqi dan manzil ikut tahap hafazan anda. Setiap hari yang selesai menyiram Taman Murajaah anda.</p><p class="small muted">Susunan halaman ikut Mushaf Madinah 604 halaman, 15 baris. Jawab beberapa soalan dan jadual akan disediakan. Semuanya boleh diubah kemudian.</p></div>`;
  else if(s===1)h+=`<h2>Kenalkan diri</h2><div class="field"><label for="wName">Nama panggilan</label><input type="text" id="wName" maxlength="24" value="${esc(W.name)}" placeholder="Contoh: Ainul"><small>Untuk ucapan "Bismillah, jom mula …" di atas.</small></div>
    <div class="field"><span class="lbl">Warna kegemaran</span><div class="swatches">${Object.entries(PALET).map(([k,v])=>`<button class="${W.palette===k?'on':''}" data-wpal="${k}" aria-label="${v.n}"><span style="background:${v.L[2]}"></span></button>`).join('')}</div><small>${PALET[W.palette].n}</small></div>`;
  else if(s===2)h+=`<h2>Tahap hafazan setiap juz</h2><p class="muted" style="margin:0">Pilih tahap, kemudian tekan juz untuk mewarnakannya.</p>
    <div class="brushes">${WLV.map(([v,l])=>`<button class="br l${v}b ${W.brush===v?'on':''}" data-wbrush="${v}">${l}</button>`).join('')}</div>
    <div class="juzgrid">${W.jl.map((v,k)=>`<button class="jz l${v}b" data-wjuz="${k}" aria-label="Juz ${k+1}: ${WLV.find(x=>x[0]===v)[1]}"><b>${k+1}</b><span>${WLV.find(x=>x[0]===v)[1]}</span></button>`).join('')}</div>
    <button class="btn sm" data-wfill="1" style="align-self:flex-start">Isi semua juz dengan "${WLV.find(x=>x[0]===W.brush)[1]}"</button>`;
  else if(s===3){const both=cnt[3]>0&&(cnt[0]+cnt[1])>0;
    h+=`<h2>Sabaq</h2><p class="muted" style="margin:0">Sabaq ialah bacaan yang sedang dihafal atau diperkuat.</p>
    <div class="field"><span class="lbl">Ikut susunan</span><div class="opts">${[['halaman','Halaman','Satu demi satu halaman'],['surah','Surah','Surah demi surah, sesuai untuk Juz Amma'],['juz','Juz','Juz demi juz']].map(([k,l,d])=>`<button class="${W.mode===k?'on':''}" data-wmode="${k}"><b>${l}</b><span>${d}</span></button>`).join('')}</div></div>
    <div class="grid2"><div class="field"><label for="wStart">Mula dari</label><select id="wStart">${startOptions(W.mode,W.start)}</select></div><div class="field"><label for="wDir">Arah</label><select id="wDir"><option value="maju" ${W.dir==='maju'?'selected':''}>Ke hadapan</option><option value="undur" ${W.dir==='undur'?'selected':''}>Ke belakang (contoh: An-Nas dahulu)</option></select></div></div>
    ${both?`<div class="field"><span class="lbl">Utamakan</span><div class="opts"><button class="${W.order==='lemah'?'on':''}" data-worder="lemah"><b>Kuatkan yang lemah</b><span>Lemah dan sederhana dahulu</span></button><button class="${W.order==='baru'?'on':''}" data-worder="baru"><b>Hafazan baru</b><span>Yang lemah dijaga dalam sabqi</span></button></div></div>`:''}
    <div class="grid2"><div class="field"><label for="wN">Halaman sabaq serentak</label><input type="number" id="wN" min="1" max="10" value="${W.sabaqN}"></div><div class="field"><label for="wNeed">Tasmik untuk lancar</label><input type="number" id="wNeed" min="1" max="10" value="${W.need}"><small>kali berturut-turut</small></div></div>`}
  else if(s===4){h+=`<h2>Sabqi & Manzil</h2>
    <div class="field"><label for="wR">Sabqi: berapa halaman terakhir yang baru lancar diulang?</label><input type="number" id="wR" min="0" max="20" value="${W.recentN}"></div>
    <div class="field"><span class="lbl">Sabqi: bahagian daripada juz sederhana setiap hari</span><div class="opts">${sqOpts.map(([v,l])=>`<button class="${W.sqMaqra===v?'on':''}" data-wsq="${v}"><b>${l}</b></button>`).join('')}</div></div>
    <div class="field"><span class="lbl">Manzil: pusingan halaman lancar setiap hari</span><div class="opts">${mzOpts.map(([v,l])=>`<button class="${W.mzMaqra===v?'on':''}" data-wmz="${v}"><b>${l}</b></button>`).join('')}</div><small>Dengan ${cnt[2]} juz lancar, satu pusingan manzil ambil kira-kira ${Math.max(1,Math.ceil(cnt[2]*8/W.mzMaqra))} hari.</small></div>`}
  else if(s===5&&NATIVE){h+=`<h2>Reminder harian</h2><p class="muted" style="margin:0">Notifikasi menunjukkan bacaan hari itu.</p>
    <div class="grid2"><div class="field"><label for="wr1">Pertama</label><input type="time" id="wr1" value="${W.rem1}"></div><div class="field"><label for="wr2">Kedua</label><input type="time" id="wr2" value="${W.rem2}"></div></div>
    <label class="row" style="font-weight:600"><input type="checkbox" id="wrOn" ${W.remOn?'checked':''}> Hidupkan reminder</label>`}
  else{const jt=v=>{const r=groupRanges(W.jl.map((x,k)=>x===v?k+1:0).filter(Boolean));return r.length?r.map(([a,b])=>a===b?'Juz '+a:'Juz '+a+'–'+b).join(', '):'tiada'};
    const sl=W.mode==='surah'?'Surah '+SURAH[W.start-1]:W.mode==='juz'?'Juz '+W.start:HL(W.start);
    h+=`<h2>Sedia, ${esc(W.name||'sahabat')}?</h2><div class="panel" style="display:flex;flex-direction:column;gap:6px">
    <div><b>Lancar:</b> ${jt(2)}</div><div><b>Sederhana:</b> ${jt(1)}</div><div><b>Lemah:</b> ${jt(0)}</div><div><b>Belum hafal:</b> ${jt(3)}</div></div>
    <div class="panel" style="display:flex;flex-direction:column;gap:4px"><div>Sabaq ikut ${W.mode}, mula ${esc(sl)}, ${W.dir==='undur'?'ke belakang':'ke hadapan'}</div><div>Sabqi ${W.recentN} halaman baru lancar${W.sqMaqra?' + '+sqOpts.find(x=>x[0]===W.sqMaqra)[1]+' juz sederhana':''}</div><div>Manzil ${mzOpts.find(x=>x[0]===W.mzMaqra)[1]} sehari</div>${NATIVE&&W.remOn?`<div>Reminder ${W.rem1} dan ${W.rem2}</div>`:''}</div>
    ${W.again?'<p class="small muted" style="margin:0">Tanda ayat, rekod dan taman kekal. Kiraan tasmik sabaq semasa bermula semula.</p>':''}`}
  h+=`<div class="wiz-nav">${s>0?`<button class="btn" data-wz="back">${ico('left',18)}Kembali</button>`:'<span></span>'}<button class="btn pri" data-wz="${s>=last?'done':'next'}">${s===0?'Mula':s>=last?'Mula murajaah':'Seterusnya'}</button></div></div>`;
  el.innerHTML=h;el.scrollTop=0}
function wizCollect(){const v=id=>{const e=document.querySelector('#wiz '+id);return e?e.value:null},n=(id,lo,hi,d)=>{const x=v(id);return x===null?null:Math.min(hi,Math.max(lo,parseInt(x)||d))};
  if(W.step===1){W.name=(v('#wName')||'').trim()}
  if(W.step===3){const st=+v('#wStart');if(st&&st!==W.start){W.start=st;W.startAuto=false}W.dir=v('#wDir')||'maju';W.sabaqN=n('#wN',1,10,1);W.need=n('#wNeed',1,10,3)}
  if(W.step===4){W.recentN=n('#wR',0,20,5)}
  if(W.step===5&&NATIVE){W.rem1=v('#wr1')||'06:30';W.rem2=v('#wr2')||'19:15';W.remOn=$('#wrOn').checked}}
function wizFinish(){
  let s='';for(let p=1;p<=604;p++)s+=W.jl[PJ[p]-1];S.levels=s;
  Object.assign(S.set,{name:W.name,palette:W.palette,sabaqMode:W.mode,sabaqDir:W.dir,start:W.start,order:W.order,sabaqN:W.sabaqN,need:W.need,recentN:W.recentN,sqMaqra:W.sqMaqra,mzMaqra:W.mzMaqra,rem1:W.rem1,rem2:W.rem2,remOn:W.remOn});
  S.tas={};S.sabaq=[];S.recent=[];S.sqPtr=0;S.mzPtr=0;S.plan=null;S.onboarded=true;orderCache.key='';
  $('#wiz').remove();applyTheme();ensure();save();go('home');if(NATIVE)setTimeout(()=>scheduleReminders(true),500);petals();toast('Jadual anda dah siap. Bismillah!')}

/* ---------- Kawalan butang Back ---------- */
let backAt=0;
function handleBack(){
  if($('#wiz')){if(W.step>0){wizCollect();W.step--;renderWiz();return true}if(W.again){$('#wiz').remove();return true}return false}
  if(layerOpen()){closeSheet();return true}
  if(AI.active&&AI.phase!=='recording'){aiClose();return true}
  if(fullscreen){setFullscreen(false);return true}
  if(tab!=='home'){go('home');return true}
  if(Date.now()-backAt<2000)return false;
  backAt=Date.now();toast('Tekan sekali lagi untuk keluar');return true}
if(NATIVE&&Capacitor.Plugins&&Capacitor.Plugins.App){Capacitor.Plugins.App.addListener('backButton',()=>{if(!handleBack())Capacitor.Plugins.App.exitApp()})}
else{try{history.pushState({m:1},'');window.addEventListener('popstate',()=>{if(handleBack())history.pushState({m:1},'');else history.back()})}catch(e){}}

/* ---------- Peristiwa ---------- */
document.addEventListener('click',e=>{
  const t=e.target.closest('button,[data-close],.w,.ln.hl,label[for]');if(!t||t.closest('#wiz'))return;const d=t.dataset;
  if(t.classList.contains('w')||t.classList.contains('ln')){const ln=t.closest('.ln.hl');if(ln&&!(t.classList.contains('w')&&!t.classList.contains('h'))){revealed.add(+ln.dataset.ln);render();return}if(t.classList.contains('w')){ayahSheet(+d.i)}return}
  if(d.tab){go(d.tab);return}
  if(d.tabGo){go(d.tabGo);return}
  if(d.qz!==undefined){answerQuiz(+d.qz);return}
  if(d.qzend){endQuiz();return}
  if(d.res){resolveMark(d.res,true);if(d.close)closeSheet();toast('Alhamdulillah, ditanda dah baik');return}
  if(d.unres){resolveMark(d.unres,false);return}
  if(d.del){deleteMark(d.del);if(d.close)closeSheet();return}
  if(d.close){closeSheet();return}
  if(d.open){closeLayer();curPage=+d.open;selAyah=d.ay!==undefined?+d.ay:null;go('mushaf');if(d.ay!==undefined)setTimeout(()=>{const el=document.querySelector(`.w[data-i="${d.ay}"]`);el&&el.scrollIntoView({block:'center'})},120);return}
  if(d.goto){closeLayer();gotoPage(+d.goto);return}
  if(d.tas){tasmik(+d.tas,d.ok==='1');return}
  if(d.grad){askGraduate(+d.grad);return}
  if(d.rmsabaq){removeSabaq(+d.rmsabaq);return}
  if(d.done){toggleDone(d.done);return}
  if(d.info){const [n,txt]=INFO[d.info];openSheet(`<h3>${n}</h3><p style="margin:0">${esc(txt)}</p><button class="btn ghost" data-close="1">Faham</button>`);return}
  if(d.quizmarks){marksListSheet(openMarks().filter(m=>m.src===d.quizmarks&&(m.d===dkey()||m.d===addDays(dkey(),-1))),d.quizmarks.replace('kuiz','Kuiz')+': ayat untuk diulang');return}
  if(d.manualmarks){const tp=new Set([...S.sabaq,...sqPages(),...S.plan.mz]);marksListSheet(openMarks().filter(m=>!(m.src&&m.src.startsWith('kuiz'))&&(tp.has(m.p)||m.d===dkey()||m.d===addDays(dkey(),-1))),'Ayat yang anda tandakan');return}
  if(d.savename){const v=$('#nmIn').value.trim();if(v){S.set.name=v;save();render();scheduleReminders(false);toast('Selamat datang, '+v+'!')}return}
  if(d.lv!==undefined){const v=+d.lv;setLv(curPage,v);if(v===2){S.sabaq=S.sabaq.filter(x=>x!==curPage);delete S.tas[curPage]}save();closeLayer();render();toast(HL(curPage)+': '+LVN[v]);return}
  if(d.view){S.set.view=d.view;revealed=new Set();save();closeLayer();render();return}
  if(d.cycleview){const o=['full','awal','sorok'];S.set.view=o[(o.indexOf(S.set.view||'full')+1)%3];revealed=new Set();save();render();return}
  if(d.revealall){S.set.view='full';save();render();return}
  if(d.addsabaqpage){const p=+d.addsabaqpage;if(lv(p)===2)setLv(p,1);S.sabaq.push(p);save();closeLayer();render();toast(HL(p)+' ditambah ke sabaq');return}
  if(d.pagemenu){pageMenu();return}
  if(d.picker){pickerSheet(d.picker==='1'?null:d.picker);return}
  if(d.pktab){pickerSheet(d.pktab);return}
  if(d.fs!==undefined){setFullscreen(d.fs==='1');return}
  if(d.pg){gotoPage(+d.pg);return}
  if(d.map){mapMode=d.map;render();return}
  if(d.mf){markFilter=d.mf;render();return}
  if(d.playerI!==undefined){closeLayer();playerSheet(+d.playerI);return}
  if(d.player){if(AI.active)aiClose();playerSheet(null);return}
  if(d.stop){playStop();return}
  if(d.ai){aiOpen(+d.ai);return}
  if(d.aiload){aiLoad();return}
  if(d.aiclose){aiClose();return}
  if(d.aistart){aiStartRec();return}
  if(d.aistop){aiFinish();return}
  if(d.aimark!==undefined){aiMark(AI.issues[+d.aimark]);t.disabled=true;t.textContent='Ditanda';return}
  if(d.aimarkall){AI.issues.forEach(aiMark);closeLayer();render();toast('Ayat ditanda untuk diulang');return}
  if(d.aicount!==undefined){closeLayer();tasmik(AI.page,d.aicount==='1');return}
  if(d.themeset!==undefined){S.set.theme=d.themeset;applyTheme();save();document.querySelectorAll('[data-themeset]').forEach(b=>b.classList.toggle('on',b.dataset.themeset===S.set.theme));return}
  if(d.palette){S.set.palette=d.palette;applyTheme();save();document.querySelectorAll('[data-palette]').forEach(b=>b.classList.toggle('on',b.dataset.palette===S.set.palette));return}
  if(t.id==='addSabaq'){const p=nextSabaqPage();if(p){S.sabaq.push(p);save();render();toast(HL(p)+' ditambah ke sabaq')}return}
  if(t.id==='btnSet'){settingsSheet();return}
});
document.addEventListener('click',e=>{const t=e.target.closest('#wiz button');if(!t)return;const d=t.dataset;
  if(d.wbrush!==undefined){W.brush=+d.wbrush;renderWiz();return}
  if(d.wjuz!==undefined){W.jl[+d.wjuz]=W.brush;renderWiz();return}
  if(d.wfill){W.jl=W.jl.map(()=>W.brush);renderWiz();return}
  if(d.wpal){wizCollect();W.palette=d.wpal;S.set.palette=d.wpal;applyTheme();renderWiz();return}
  if(d.wmode){wizCollect();W.mode=d.wmode;W.startAuto=true;renderWiz();return}
  if(d.worder){wizCollect();W.order=d.worder;W.startAuto=true;renderWiz();return}
  if(d.wsq!==undefined){wizCollect();W.sqMaqra=+d.wsq;renderWiz();return}
  if(d.wmz!==undefined){wizCollect();W.mzMaqra=+d.wmz;renderWiz();return}
  if(d.wz==='cancel'){$('#wiz').remove();applyTheme();return}
  wizCollect();
  if(d.wz==='next'){W.step++;if(W.step===3&&W.startAuto)W.start=wizAutoStart();renderWiz()}else if(d.wz==='back'){W.step--;renderWiz()}else if(d.wz==='done')wizFinish()});
document.addEventListener('keydown',e=>{if(e.key==='Escape')handleBack();if(e.key==='Enter'&&e.target.id==='nmIn'){const b=document.querySelector('[data-savename]');b&&b.click()}});
// leret untuk tukar halaman (mushaf Arab: leret ke kanan = halaman seterusnya)
let tx=null,ty=null;
document.addEventListener('touchstart',e=>{if(tab!=='mushaf'||!e.target.closest('.mushaf'))return;tx=e.touches[0].clientX;ty=e.touches[0].clientY},{passive:true});
document.addEventListener('touchend',e=>{if(tx===null)return;const dx=e.changedTouches[0].clientX-tx,dy=e.changedTouches[0].clientY-ty;tx=null;if(Math.abs(dx)>70&&Math.abs(dx)>Math.abs(dy)*1.5)gotoPage(curPage+(dx>0?1:-1))},{passive:true});
window.addEventListener('resize',()=>{clearTimeout(window._rz);window._rz=setTimeout(fitPage,150)});
document.addEventListener('visibilitychange',()=>{if(!document.hidden){applySky();if(S.plan&&S.plan.date!==dkey())render()}});
setInterval(applySky,5*60*1000);

/* ---------- Mula ---------- */
applyTheme();
{const h=(location.hash||'').slice(1);if(['home','mushaf','peta','tanda'].includes(h))tab=h}
ensure();saveLocal();render();
if(!S.onboarded)openWizard(false);
/* ---------- Kod jemputan (web app sahaja) ---------- */
const INVITE_HASH='f5918f1ee5f6d1d2e1ae26b755993e8c7f6b600a53410389f38c37edb777fb20';
function inviteOk(){try{return localStorage.getItem('mi-invite')===INVITE_HASH}catch(e){return false}}
async function sha256(s){const b=await crypto.subtle.digest('SHA-256',new TextEncoder().encode(s));return[...new Uint8Array(b)].map(x=>x.toString(16).padStart(2,'0')).join('')}
if(!NATIVE&&!inviteOk()){
  const g=document.createElement('div');g.id='gate';
  g.innerHTML=`<form class="gate-in" id="gateF"><svg viewBox="0 0 120 120" width="120" height="120" aria-hidden="true"><circle cx="60" cy="58" r="26" fill="#ffd9a8"/><path d="M6 96c22-14 40-14 58-6s36 8 50-2v32H6z" fill="#bfe3c6"/><path d="M0 104c26-10 46-8 66-2s38 6 54-2v20H0z" fill="#9fd3ab"/><path d="M60 98V66" stroke="#4f9a68" stroke-width="4" stroke-linecap="round"/><path d="M60 72c-3-10-12-14-20-12 2 9 10 14 20 12z" fill="#6fbf86"/><path d="M60 68c3-11 13-15 22-13-2 10-12 15-22 13z" fill="#83cc98"/></svg>
    <h2>Murajaah Itqan</h2><p class="muted">App ini untuk jemputan sahaja. Masukkan kod yang diberi oleh rakan anda.</p>
    <div class="field"><label for="gateIn">Kod jemputan</label><input type="text" id="gateIn" autocomplete="off" autocapitalize="characters" spellcheck="false" placeholder="Contoh: ABCDE12"></div>
    <p class="small" id="gateErr" style="color:var(--bad);margin:0" hidden>Kod tidak betul. Semak semula dengan rakan yang menjemput anda.</p>
    <button class="btn pri" type="submit">Masuk</button></form>`;
  document.body.appendChild(g);
  g.querySelector('#gateF').addEventListener('submit',async e=>{e.preventDefault();const v=g.querySelector('#gateIn').value.trim().toUpperCase();
    let h='';try{h=await sha256(v)}catch(err){h=''}
    if(h===INVITE_HASH){try{localStorage.setItem('mi-invite',h)}catch(err){}g.remove();toast('Selamat datang!')}
    else{g.querySelector('#gateErr').hidden=false}});
}
if(NATIVE&&S.onboarded)setTimeout(()=>scheduleReminders(true),800);
setTimeout(()=>{const s=$('#splash');if(s){s.classList.add('out');setTimeout(()=>s.remove(),500)}},matchMedia('(prefers-reduced-motion: reduce)').matches?100:1300);
if(!NATIVE&&'serviceWorker' in navigator&&location.protocol==='https:')navigator.serviceWorker.register('sw.js').catch(()=>{});
