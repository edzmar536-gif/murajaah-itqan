/* ---------- Keadaan (disimpan dalam fon) ---------- */
const LKEY='murajaah-itqan-v1';
function initialLevels(){let s='';for(let p=1;p<=604;p++){const j=PJ[p];s+=(j<=6||j>=25)?'2':(j<=10?'1':'0')}return s}
function defSet(){return{name:'',sabaqMode:'halaman',sabaqDir:'maju',start:VP[D.jz[10]],sabaqN:1,need:3,recentN:5,sqMaqra:2,mzMaqra:4,
  reciter:'ghamidi',theme:'',palette:'awan',view:'full',order:'lemah',remOn:true,rem1:'06:30',rem2:'19:15',rest:true}}
function freshState(){return{v:2,updatedAt:0,levels:'3'.repeat(604),tas:{},sabaq:[],recent:[],sqPtr:0,mzPtr:0,plan:null,log:{},marks:[],
  onboarded:false,lastPage:1,trees:[],grads:[],set:defSet()}}
function migrate(s){
  const legacy=!!s&&s.onboarded===undefined;const had=!!s;
  s=Object.assign(freshState(),s||{});if(legacy)s.onboarded=true;
  const old=s.set||{};s.set=Object.assign(defSet(),old);
  if(had&&(s.v||1)<2){ // daripada versi 1.x
    s.sqPtr=((s.sqPtr|0)*2)%240;
    const mp=Math.min(604,Math.max(1,s.mzPtr|0||1));s.mzPtr=Math.floor((VM[pageFirst(mp)]-1)/4)*4;
    s.set.mzMaqra=({5:2,10:4,20:8,40:16})[old.mzN]||4;s.set.sqMaqra=2;s.set.sabaqMode='halaman';s.set.sabaqDir='maju';
    if(!old.palette)s.set.palette='awan';s.plan=null;s.lastPage=(s.sabaq&&s.sabaq[0])||1;s.v=2}
  if(typeof s.levels!=='string'||s.levels.length!==604)s.levels=had&&!legacy?'3'.repeat(604):initialLevels();
  if(!Array.isArray(s.trees))s.trees=[];if(!Array.isArray(s.grads))s.grads=[];
  return s}
let S;
try{S=migrate(JSON.parse(localStorage.getItem(LKEY)||'null'))}catch(e){S=freshState()}
const lv=p=>+S.levels[p-1];
const setLv=(p,v)=>{S.levels=S.levels.slice(0,p-1)+v+S.levels.slice(p)};
let remT=null;
function saveLocal(){try{localStorage.setItem(LKEY,JSON.stringify(S))}catch(e){}}
function save(){S.updatedAt=Date.now();saveLocal();clearTimeout(remT);remT=setTimeout(()=>scheduleReminders(false),2500)}

/* ---------- Susunan sabaq ---------- */
let orderCache={key:'',list:[]};
function sabaqOrder(){
  const st=S.set,key=st.sabaqMode+st.sabaqDir+st.start;if(orderCache.key===key)return orderCache.list;
  const out=[],seen=new Set(),push=p=>{if(!seen.has(p)){seen.add(p);out.push(p)}};
  const seq=(from,max,dir)=>{const r=[];if(dir==='undur'){for(let x=from;x>=1;x--)r.push(x);for(let x=max;x>from;x--)r.push(x)}else{for(let x=from;x<=max;x++)r.push(x);for(let x=1;x<from;x++)r.push(x)}return r};
  if(st.sabaqMode==='surah')seq(Math.min(114,Math.max(1,st.start)),114,st.sabaqDir).forEach(s=>{const [a,b]=surahPages(s);for(let p=a;p<=b;p++)push(p)});
  else if(st.sabaqMode==='juz')seq(Math.min(30,Math.max(1,st.start)),30,st.sabaqDir).forEach(j=>{const [a,b]=juzPages(j);for(let p=a;p<=b;p++)push(p)});
  else seq(Math.min(604,Math.max(1,st.start)),604,st.sabaqDir).forEach(push);
  orderCache={key,list:out};return out}
function nextSabaqPage(){const taken=new Set(S.sabaq),ord=sabaqOrder();
  for(const want of (S.set.order==='baru'?[3,0,1]:[0,1,3]))for(const p of ord)if(lv(p)===want&&!taken.has(p))return p;return null}
function fillSabaq(){S.sabaq=S.sabaq.filter(p=>lv(p)!==2);while(S.sabaq.length<S.set.sabaqN){const p=nextSabaqPage();if(!p)break;S.sabaq.push(p)}}

/* ---------- Pelan harian ---------- */
const sqPool=p=>{const v=lv(p);return(v===1||(S.set.order==='baru'&&v===0))&&!S.sabaq.includes(p)};
function makePlan(){
  const today=dkey();if(S.plan&&S.plan.date===today)return;
  let sq=null;const k=S.set.sqMaqra|0;
  if(k>0){const n=Math.ceil(240/k),c0=Math.floor(S.sqPtr/k)%n;
    for(let i=0;i<n;i++){const st=((c0+i)%n)*k,kk=Math.min(k,240-st),[a,b]=chunkPages(st,kk);if(range(a,b).some(sqPool)){sq={st,k:kk,a,b};break}}}
  const recent=S.recent.slice(0,S.set.recentN),rs=new Set(recent),sab=new Set(S.sabaq);
  const km=S.set.mzMaqra|0||4,nm=Math.ceil(240/km),m0=Math.floor(S.mzPtr/km)%nm;let mz=[],mzc=null;
  for(let i=0;i<nm;i++){const st=((m0+i)%nm)*km,kk=Math.min(km,240-st),[a,b]=chunkPages(st,kk);const pg=range(a,b).filter(p=>lv(p)===2&&!rs.has(p)&&!sab.has(p));if(pg.length){mz=pg;mzc={st,k:kk,a,b};break}}
  S.plan={date:today,sq,recent,mz,mzc,done:{sq:false,mz:false},prev:{sqPtr:S.sqPtr,mzPtr:S.mzPtr}}}
function sqPages(){const P=S.plan,out=[...P.recent];if(P.sq)for(let p=P.sq.a;p<=P.sq.b;p++)if(!out.includes(p))out.push(p);return out}
function ensure(){fillSabaq();makePlan()}
function logAdd(field,n=1){const k=dkey();const L=S.log[k]||(S.log[k]={p:0,t:0});L[field]=(L[field]||0)+n}
function streak(){ // hari rehat: satu hari terlepas setiap 7 hari tidak memutuskan siraman
  const did=k=>S.log[k]&&S.log[k].p>0;let k=dkey(),n=0,lastRest=-99,i=0;if(!did(k))k=addDays(k,-1);
  for(;i<2000;i++){if(did(k)){n++}else if(S.set.rest&&n>0&&i-lastRest>=7&&did(addDays(k,-1))){lastRest=i}else break;k=addDays(k,-1)}return n}

/* ---------- Tasmik, lancar, selesai ---------- */
function tasmik(p,ok){
  if(ok){const n=(S.tas[p]||0)+1;
    if(n>=S.set.need){startQuiz({kind:'sabaq',pages:[p],n:5,
      onPass:()=>{logAdd('p');logAdd('t');graduate(p)},
      onFail:()=>{S.tas[p]=0;logAdd('p');save();render();toast('Hampir! Ulang halaman ini dan tasmik semula.')}});return}
    S.tas[p]=n;logAdd('p');logAdd('t');toast('Tasmik lancar '+n+' daripada '+S.set.need)}
  else{S.tas[p]=0;logAdd('p');toast('Kiraan bermula semula. Tandakan ayat yang tersalah dalam mushaf.')}
  save();render()}
function askGraduate(p){startQuiz({kind:'sabaq',pages:[p],n:5,onPass:()=>graduate(p,true),onFail:()=>{S.tas[p]=0;save();render();toast('Hampir! Ulang halaman ini dan cuba lagi.')}})}
function graduate(p,manual){
  setLv(p,2);delete S.tas[p];S.sabaq=S.sabaq.filter(x=>x!==p);S.recent=[p,...S.recent.filter(x=>x!==p)].slice(0,20);
  S.grads.push({p,d:dkey()});if(manual)logAdd('p');
  const t=checkTree(p);fillSabaq();save();render();petals();
  toast(t?'Masya-Allah! '+t+' lancar sepenuhnya. Sebatang pokok berbuah tumbuh di taman.':'Alhamdulillah! '+HL(p)+' lancar. Sekuntum bunga mekar di taman.')}
function checkTree(p){
  const units=S.set.sabaqMode==='surah'?surahsOnPage(p).map(s=>['surah',s,surahPages(s)]):[['juz',PJ[p],juzPages(PJ[p])]];
  let made=null;for(const [t,n,[a,b]] of units){if(S.trees.some(x=>x.t===t&&x.n===n))continue;
    if(range(a,b).every(q=>lv(q)===2)){S.trees.push({t,n,d:dkey()});made=t==='surah'?'Surah '+SURAH[n-1]:'Juz '+n}}return made}
function removeSabaq(p){S.sabaq=S.sabaq.filter(x=>x!==p);delete S.tas[p];if(S.set.sabaqN>S.sabaq.length)S.set.sabaqN=Math.max(1,S.sabaq.length);fillSabaq();save();render();toast(HL(p)+' dibuang daripada sabaq')}
function markDone(which){
  const P=S.plan,L=S.log[dkey()]||(S.log[dkey()]={p:0,t:0});
  if(which==='sq'){P.done.sq=true;if(P.sq)S.sqPtr=(P.sq.st+P.sq.k)%240;L.p+=sqPages().length}
  else{P.done.mz=true;if(P.mzc)S.mzPtr=(P.mzc.st+P.mzc.k)%240;L.p+=P.mz.length}
  save();render();petals()}
function downgrade(pages){const out=[];for(const p of new Set(pages)){const v=lv(p);if(v>0&&v<3){setLv(p,v-1);out.push(p)}}return out}
function toggleDone(which){
  const P=S.plan;if(!P)return;const L=S.log[dkey()]||(S.log[dkey()]={p:0,t:0});
  if(P.done[which]){
    if(which==='sq'){P.done.sq=false;S.sqPtr=P.prev.sqPtr;L.p=Math.max(0,L.p-sqPages().length)}
    else{P.done.mz=false;S.mzPtr=P.prev.mzPtr;L.p=Math.max(0,L.p-P.mz.length)}
    save();render();return}
  const pages=which==='sq'?sqPages():P.mz;
  startQuiz({kind:which==='sq'?'sabqi':'manzil',pages,n:which==='sq'?8:10,
    onPass:()=>markDone(which),
    onFail:(wrong)=>{const d=downgrade(wrong.map(i=>VP[i]));save();render();toast(d.length?'Hampir! '+groupRanges(d).map(rangeText).join(', ')+' perlu lebih ulangan. Ulang dan cuba kuiz lagi.':'Hampir! Ulang sedikit lagi dan cuba kuiz semula.')}})}

/* ---------- Tanda ayat ---------- */
const openMarks=()=>S.marks.filter(m=>!m.r);
const marksOnPage=p=>openMarks().filter(m=>m.p===p);
function addMark(i,t,note,src){S.marks.unshift({id:Date.now().toString(36)+Math.random().toString(36).slice(2,6),i,s:VS[i],a:VA[i],p:VP[i],t,n:note||'',src:src||'',d:dkey(),r:false});save()}
function resolveMark(id,val=true){const m=S.marks.find(x=>x.id===id);if(m){m.r=val;m.rd=dkey();save();render()}}
function deleteMark(id){S.marks=S.marks.filter(x=>x.id!==id);save();render()}
