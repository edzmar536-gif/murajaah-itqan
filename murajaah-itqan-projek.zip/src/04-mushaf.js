/* ---------- Mushaf ---------- */
let curPage=S.lastPage||1,selAyah=null,revealed=new Set(),lastPg=0,fullscreen=false;
const heard={}; // `${i}` -> Set kedudukan perkataan yang didengar AI
const aiIssue=new Set(); // indeks ayat yang AI tandakan
const fontP={};
function loadPageFont(p){if(!LAYOUT||p<1||p>604)return Promise.resolve();if(fontP[p])return fontP[p];
  const f=new FontFace('qpc'+p,`url(qpc1/p${pad3(p)}.woff2)`);fontP[p]=f.load().then(x=>{document.fonts.add(x)}).catch(()=>{delete fontP[p]});return fontP[p]}
function qpcLines(p,mmap){
  const mode=S.set.view||'full';
  return LAYOUT[p-1].map((ln,k)=>{
    if(ln[0]===0)return`<div class="ln hdr"><span>${esc(D.sa[ln[1]-1])}</span></div>`;
    if(ln[0]===1)return`<div class="ln bsm">بِسۡمِ ٱللَّهِ ٱلرَّحۡمَٰنِ ٱلرَّحِيمِ</div>`;
    const open=mode==='full'||revealed.has(k);
    return`<div class="ln${open?'':' hl'}" data-ln="${k}">`+ln[1].map(([i,w,g])=>{const c=['w'],hs=heard[i],isH=hs&&hs.has(w);
      if(!open&&!(mode==='awal'&&w===1)&&!isH)c.push('h');
      else{if(mmap[i])c.push('m-'+mmap[i]);if(selAyah===i)c.push('sel');if(AP.playing&&AP.cur===i)c.push('play');if(isH)c.push('heard');if(aiIssue.has(i))c.push('issue')}
      return`<span class="${c.join(' ')}" data-i="${i}" data-w="${w}">${esc(g)}</span>`}).join('')+'</div>'}).join('')}
function fitPage(){
  const el=document.getElementById('qlines');if(!el)return;const W=el.clientWidth;if(!W)return;
  el.style.fontSize='40px';const lines=[...el.querySelectorAll('.ln')];
  lines.forEach(l=>l.classList.add('measure'));
  let mx=0;const wd=lines.map(l=>{const w=l.classList.contains('hdr')||l.classList.contains('bsm')?0:l.offsetWidth;mx=Math.max(mx,w);return w});
  lines.forEach(l=>l.classList.remove('measure'));
  let fs=Math.min(fullscreen?60:46,40*W/mx*(curPage<=2?0.86:0.985));
  if(fullscreen){const avail=window.innerHeight-90;fs=Math.min(fs,avail/15/1.9)}
  el.style.fontSize=fs+'px';
  const center=curPage<=2;
  lines.forEach((l,k)=>{if(!wd[k])return;l.classList.toggle('center',center||wd[k]*fs/40<W*0.8)});
  el.classList.add('ready')}
function afterMushaf(){if(!LAYOUT||tab!=='mushaf')return;const p=curPage;
  loadPageFont(p).then(()=>{if(p===curPage&&tab==='mushaf')fitPage()});
  setTimeout(()=>{loadPageFont(p+1);loadPageFont(p-1)},400)}
function gotoPage(p){curPage=Math.min(604,Math.max(1,p));selAyah=null;S.lastPage=curPage;saveLocal();if(tab!=='mushaf')tab='mushaf';render();window.scrollTo(0,0)}
const VIEWN={full:'Penuh',awal:'Awal ayat',sorok:'Sorok'};
function vMushaf(){
  const p=curPage,marks=marksOnPage(p),mmap={};marks.forEach(m=>{mmap[m.i]=mmap[m.i]||m.t});
  const f=pageFirst(p),e=pageEnd(p),inSab=S.sabaq.includes(p),mode=S.set.view||'full',P=S.plan;
  let body;
  if(LAYOUT)body=`<div class="qlines" id="qlines" style="font-family:qpc${p},var(--f-ar)">${qpcLines(p,mmap)}</div>`;
  else{let txt='';for(let i=f;i<e;i++){
      if(VA[i]===1)txt+=`<div style="text-align:center;font-size:.8em">${esc(D.sa[VS[i]-1])}</div>${VS[i]!==1&&VS[i]!==9?'<div style="text-align:center">بِسۡمِ ٱللَّهِ ٱلرَّحۡمَٰنِ ٱلرَّحِيمِ</div>':''}`;
      txt+=`<span class="w ${mmap[i]?'m-'+mmap[i]:''}" data-i="${i}" data-w="1">${esc(T[i])} ${AR(VA[i])}</span> `}
    body=`<div class="qtext">${txt}</div>`}
  const jumps=[];if(S.sabaq[0])jumps.push(['sb','Sabaq',S.sabaq[0]]);const sq=sqPages();if(sq.length)jumps.push(['sq','Sabqi',Math.min(...sq)]);if(P.mz.length)jumps.push(['mz','Manzil',P.mz[0]]);
  let h=`<div class="mtool"><button class="picker-btn" data-picker="1">${ico('search')}<span class="t"><b>${esc(pageLabel(p))}</b><span>Juz ${PJ[p]}, ${HL(p)}</span></span></button>
    <button class="ibtn" data-player="1" aria-label="Dengar bacaan">${ico('head')}</button><button class="ibtn" data-ai="${p}" aria-label="Tasmik dengan AI">${ico('mic')}</button><button class="ibtn" data-fs="1" aria-label="Skrin penuh">${ico('expand')}</button><button class="ibtn" data-pagemenu="1" aria-label="Pilihan halaman">${ico('more')}</button></div>
  <div class="jumps">${jumps.map(([c,l,pg])=>`<button class="chip ${c}" data-goto="${pg}">${l} ${pg}</button>`).join('')}${LAYOUT?`<button class="chip mode" data-cycleview="1">${ico('eye',16)}${VIEWN[mode]}</button>`:''}</div>`;
  if(LAYOUT&&mode!=='full')h+=`<div class="banner row" style="justify-content:space-between"><span>Tekan baris untuk membukanya satu per satu.</span><button class="btn sm" data-revealall="1">Papar semua</button></div>`;
  if(marks.length)h+=`<div class="banner">${marks.length} ayat bertanda di halaman ini.</div>`;
  h+=`<article class="mushaf" id="mushaf"><div class="mhead"><span>${esc(SURAH[VS[f]-1])}</span><span>Juz ${PJ[p]}</span></div>${body}<div class="mfoot">${AR(p)}</div></article>`;
  if(fullscreen)h+=`<button class="fs-exit" data-fs="0" aria-label="Keluar skrin penuh">${ico('shrink')}</button>`;
  h+=`<p class="hint small muted" style="margin:0;text-align:center">Tekan ayat untuk terjemahan, tanda atau dengar. Leret ke kiri atau kanan untuk tukar halaman.</p>`;
  if(inSab){const n=S.tas[p]||0;h+=`<section class="task sb sabaqbox"><div class="task-h"><h3>Sabaq</h3><span class="count">${n} daripada ${S.set.need} tasmik</span></div><div class="row"><button class="btn ok" data-tas="${p}" data-ok="1">${ico('check',18)}Lancar</button><button class="btn" data-tas="${p}" data-ok="0">${ico('x',18)}Ada salah</button><button class="btn ghost sm" data-grad="${p}">Tanda lancar terus</button></div></section>`}
  h+=`<div class="pager"><button class="pg" data-pg="${p+1}" ${p>=604?'disabled':''} aria-label="Halaman seterusnya">${ico('left',18)} ${Math.min(604,p+1)}</button><button class="pg" data-picker="halaman">${p}</button><button class="pg" data-pg="${p-1}" ${p<=1?'disabled':''} style="justify-self:end" aria-label="Halaman sebelum">${Math.max(1,p-1)} ${ico('right',18)}</button></div>`;
  return h}
function setFullscreen(on){fullscreen=on;document.body.classList.toggle('fs',on);
  try{if(on&&document.documentElement.requestFullscreen&&!NATIVE)document.documentElement.requestFullscreen().catch(()=>{});else if(!on&&document.fullscreenElement)document.exitFullscreen().catch(()=>{})}catch(e){}
  render()}

/* Pilihan halaman: tahap, mod */
function pageMenu(){const p=curPage,v=lv(p),mode=S.set.view||'full';
  openSheet(`<h3>${HL(p)}</h3>
  <div class="field"><span class="lbl">Tahap halaman ini</span><div class="seg">${[0,1,2,3].map(k=>`<button class="${v===k?'on':''}" data-lv="${k}">${LVN[k]}</button>`).join('')}</div></div>
  <div class="field"><span class="lbl">Paparan mushaf</span><div class="seg">${Object.entries(VIEWN).map(([k,l])=>`<button class="${mode===k?'on':''}" data-view="${k}">${l}</button>`).join('')}</div><small>Awal ayat: hanya perkataan pertama setiap ayat ditunjukkan. Sorok: semua disorok untuk uji hafazan.</small></div>
  ${S.sabaq.includes(p)?'':`<button class="btn" data-addsabaqpage="${p}">${ico('plus',18)}Jadikan halaman ini sabaq</button>`}
  <button class="btn ghost" data-close="1">Tutup</button>`)}

/* Pemilih surah / juz / halaman */
let pickTab='surah';
function pickerSheet(tabSel){pickTab=tabSel||pickTab;
  const p=curPage,curS=VS[pageFirst(p)];
  let body='';
  if(pickTab==='surah')body=`<input type="search" id="pkQ" placeholder="Cari nama atau nombor surah" aria-label="Cari surah"><div class="picklist" id="pkList">${SURAH.map((n,k)=>`<button class="${k+1===curS?'cur':''}" data-goto="${surahPages(k+1)[0]}" data-name="${esc((k+1)+' '+n.toLowerCase())}"><span class="n">${k+1}</span><span class="t"><b>${esc(n)}</b><span>${D.sc[k]} ayat, halaman ${surahPages(k+1)[0]}</span></span><span class="ar">${esc(D.sa[k])}</span></button>`).join('')}</div>`;
  else if(pickTab==='juz')body=`<div class="picklist">${range(1,30).map(j=>{const [a,b]=juzPages(j);return`<button class="${PJ[p]===j?'cur':''}" data-goto="${a}"><span class="n">${j}</span><span class="t"><b>Juz ${j}</b><span>Halaman ${a}–${b}, bermula ${esc(SURAH[VS[D.jz[j-1]]-1])} ${VA[D.jz[j-1]]}</span></span></button>`}).join('')}</div>`;
  else body=`<div class="field"><label for="pkN">Nombor halaman (1–604)</label><input type="number" id="pkN" min="1" max="604" inputmode="numeric" value="${p}"></div>
    <input type="range" id="pkR" min="1" max="604" value="${p}" aria-label="Leret untuk pilih halaman"><div class="small muted" id="pkInfo">${esc(pageLabel(p))}, Juz ${PJ[p]}</div>
    <button class="btn pri" id="pkGo">Buka halaman</button>`;
  openSheet(`<h3>Cari dalam mushaf</h3><div class="seg">${[['surah','Surah'],['juz','Juz'],['halaman','Halaman']].map(([k,l])=>`<button class="${pickTab===k?'on':''}" data-pktab="${k}">${l}</button>`).join('')}</div>${body}<button class="btn ghost" data-close="1">Tutup</button>`,sh=>{
    const q=sh.querySelector('#pkQ');if(q)q.oninput=()=>{const v=q.value.trim().toLowerCase();sh.querySelectorAll('#pkList button').forEach(b=>b.hidden=!!v&&!b.dataset.name.includes(v))};
    const c=sh.querySelector('.picklist .cur');if(c)c.scrollIntoView({block:'center'});
    const n=sh.querySelector('#pkN'),r=sh.querySelector('#pkR');
    if(n){const sync=v=>{v=Math.min(604,Math.max(1,v|0||1));sh.querySelector('#pkInfo').textContent=pageLabel(v)+', Juz '+PJ[v];return v};
      n.oninput=()=>{r.value=sync(+n.value)};r.oninput=()=>{n.value=sync(+r.value)};
      sh.querySelector('#pkGo').onclick=()=>{closeLayer();gotoPage(+n.value)};n.onkeydown=e=>{if(e.key==='Enter'){closeLayer();gotoPage(+n.value)}}}
  })}

/* Ayat: terjemahan, maksud perkataan, tanda, dengar */
const DATA={};
function loadJSON(name){if(DATA[name])return DATA[name];DATA[name]=fetch('data/'+name).then(r=>{if(!r.ok)throw 0;return r.json()}).catch(()=>{delete DATA[name];return null});return DATA[name]}
function ayahSheet(i){
  selAyah=i;render();
  const ms=S.marks.filter(m=>m.i===i),p=VP[i];
  openSheet(`<h3>${esc(SURAH[VS[i]-1])} ${vkey(i)}</h3><div class="small muted" style="margin-top:-8px">${HL(p)}, Juz ${PJ[p]}</div>
  ${(()=>{if(LAYOUT){const g=[];LAYOUT[p-1].forEach(ln=>{if(ln[0]===2)ln[1].forEach(([v,w,gl])=>{if(v===i)g.push(gl)})});if(g.length)return`<div class="ar-big" style="font-family:qpc${p},var(--f-ar);font-size:28px">${esc(g.join(' '))}</div>`}return`<div class="ar-big">${esc(T[i])} ${AR(VA[i])}</div>`})()}
  <div class="seg"><button class="on" data-trtab="ms">Terjemahan</button><button data-trtab="wbw">Maksud perkataan</button></div>
  <div id="trBox" class="trans">Memuatkan terjemahan…</div>
  ${ms.length?`<div>${ms.map(m=>`<div class="row" style="margin-bottom:6px"><span class="pill ${m.t}">${m.t==='lupa'?'Lupa':'Tertukar'}</span><span class="small muted">${fmtShort(m.d)}${m.r?', dah baik':''}</span>${m.n?`<span class="small">${esc(m.n)}</span>`:''}<span class="row" style="margin-left:auto">${m.r?'':`<button class="btn sm ok" data-res="${m.id}" data-close="1">Dah baik</button>`}<button class="btn sm ghost" data-del="${m.id}" data-close="1">Padam</button></span></div>`).join('')}</div>`:''}
  <div class="field"><label for="mkNote">Nota (pilihan)</label><textarea id="mkNote" placeholder="Contoh: tertukar dengan Al-A'raf 54"></textarea></div>
  <div class="grid2"><button class="btn" id="mkLupa" style="background:var(--bad-soft);border-color:transparent;color:var(--bad)">Tanda lupa</button><button class="btn" id="mkTukar" style="background:var(--swap-soft);border-color:transparent;color:var(--swap)">Tanda tertukar</button></div>
  <button class="btn soft" data-player-i="${i}">${ico('head',18)}Dengar dari ayat ini</button>
  <button class="btn ghost" data-close="1">Tutup</button>`,sh=>{
    const box=sh.querySelector('#trBox');
    const showMs=()=>loadJSON('tr_ms.json').then(t=>{box.className='trans';box.textContent=t?t[i]:'Terjemahan tidak dapat dimuatkan.'});
    const showW=()=>loadJSON('wbw_en.json').then(w=>{if(!w){box.textContent='Maksud perkataan tidak dapat dimuatkan.';return}
      const glyphs={};if(LAYOUT)LAYOUT[p-1].forEach(ln=>{if(ln[0]===2)ln[1].forEach(([v,wi,g])=>{if(v===i)glyphs[wi]=g})});
      box.className='wbw';box.innerHTML=w[i].map((e,k)=>`<div><span class="g" style="font-family:${glyphs[k+1]?'qpc'+p:'var(--f-ar)'}">${esc(glyphs[k+1]?glyphs[k+1].replace(/\s.*$/,''):T[i].split(' ')[k]||'')}</span><span class="e">${esc(e)}</span></div>`).join('')});
    showMs();
    sh.querySelectorAll('[data-trtab]').forEach(b=>b.onclick=()=>{sh.querySelectorAll('[data-trtab]').forEach(x=>x.classList.toggle('on',x===b));b.dataset.trtab==='ms'?showMs():showW()});
    sh.querySelector('#mkLupa').onclick=()=>{addMark(i,'lupa',sh.querySelector('#mkNote').value.trim());closeLayer();render();toast('Ditanda lupa: '+vkey(i))};
    sh.querySelector('#mkTukar').onclick=()=>{addMark(i,'tukar',sh.querySelector('#mkNote').value.trim());closeLayer();render();toast('Ditanda tertukar: '+vkey(i))};
  })}
