/* ---------- Tasmik AI (beta) ---------- */
const AI={w:null,ready:false,active:false,phase:'idle',pct:0,label:'',page:null,issues:[],total:{},stream:null,ctx:null,t0:0,timer:null,err:''};
const AI_KIND={possible_skipped_ayah:'Ayat mungkin tertinggal',possible_omission:'Perkataan mungkin tertinggal',possible_substitution:'Perkataan mungkin tertukar',possible_vowel:'Baris mungkin tersalah',possible_repetition:'Ada ulangan',unclear_ayah:'Bacaan kurang jelas'};
const aiModelUrl=()=>new URL(CFG.aiBase,location.href).href;
function aiWorker(){if(!AI.w){AI.w=new Worker('ai-rt/tasmik-worker.js',{type:'module'});AI.w.onmessage=e=>aiMsg(e.data);AI.w.onerror=()=>aiFail('Komponen AI tidak dapat dimulakan pada peranti ini.')}return AI.w}
async function aiCached(){try{const c=await caches.open('tasmik-ai-v1');return !!(await c.match(aiModelUrl()+'zipformer_a0w_ep1_a05.int8.onnx'))}catch(e){return false}}
async function aiOpen(p){
  if(p!==curPage||tab!=='mushaf')gotoPage(p);
  if(AP.playing)playStop();
  AI.active=true;AI.page=curPage;AI.issues=[];AI.err='';
  if(AI.ready)AI.phase='ready';else AI.phase=(await aiCached())?'loading':'ask';
  if(AI.phase==='loading')aiLoad();renderDock()}
function aiLoad(){AI.phase='loading';AI.pct=0;AI.label='';renderDock();aiWorker().postMessage({type:'init',base:aiModelUrl(),wasmPaths:new URL('ai-rt/',location.href).href})}
function aiFail(msg){AI.phase='error';AI.err=msg;aiStopMic();renderDock()}
function aiClose(){aiStopMic();AI.active=false;AI.phase=AI.ready?'ready':'idle';renderDock()}
function aiExpected(p){const f=pageFirst(p);let e=f;while(e+1<pageEnd(p)&&VS[e+1]===VS[f])e++;return{surah:VS[f],ayah:VA[f],ayahEnd:VA[e]}}
async function aiStartRec(){
  const p=AI.page;for(let i=pageFirst(p);i<pageEnd(p);i++){delete heard[i];aiIssue.delete(i)}
  AI.issues=[];AI.total={};render();
  try{AI.stream=await navigator.mediaDevices.getUserMedia({audio:{channelCount:1,echoCancellation:false,noiseSuppression:true,autoGainControl:true}})}
  catch(e){toast('Benarkan mikrofon untuk guna tasmik AI.');return}
  try{
    const Ctx=window.AudioContext||window.webkitAudioContext,ctx=new Ctx({sampleRate:16000});AI.ctx=ctx;
    const code=`class R extends AudioWorkletProcessor{constructor(){super();this.b=new Float32Array(7680);this.n=0}process(i){const c=i[0]&&i[0][0];if(c){let o=0;while(o<c.length){const k=Math.min(c.length-o,this.b.length-this.n);this.b.set(c.subarray(o,o+k),this.n);this.n+=k;o+=k;if(this.n===this.b.length){this.port.postMessage(this.b.slice(0));this.n=0}}}return true}}registerProcessor('rec16',R)`;
    await ctx.audioWorklet.addModule(URL.createObjectURL(new Blob([code],{type:'text/javascript'})));
    const src=ctx.createMediaStreamSource(AI.stream),node=new AudioWorkletNode(ctx,'rec16'),mute=ctx.createGain();mute.gain.value=0;
    node.port.onmessage=e=>{const s=e.data;let m=0;for(let i=0;i<s.length;i+=40)m=Math.max(m,Math.abs(s[i]));AI.level=m;AI.w.postMessage({type:'audio',samples:s},[s.buffer]);const b=document.getElementById('aiLvl');if(b)b.style.width=Math.min(100,m*140)+'%'};
    src.connect(node);node.connect(mute);mute.connect(ctx.destination);
  }catch(e){aiStopMic();aiFail('Rakaman tidak dapat dimulakan: '+(e&&e.message||e));return}
  aiWorker().postMessage({type:'start',expected:aiExpected(p)});
  AI.phase='recording';AI.t0=Date.now();clearInterval(AI.timer);AI.timer=setInterval(()=>{const t=document.getElementById('aiTime');if(t){const s=Math.floor((Date.now()-AI.t0)/1000);t.textContent=Math.floor(s/60)+':'+String(s%60).padStart(2,'0')}},500);
  renderDock()}
function aiStopMic(){clearInterval(AI.timer);try{if(AI.stream)AI.stream.getTracks().forEach(t=>t.stop())}catch(e){}try{if(AI.ctx)AI.ctx.close()}catch(e){}AI.stream=null;AI.ctx=null}
function aiFinish(){aiStopMic();AI.phase='processing';renderDock();aiWorker().postMessage({type:'stop'})}
function aiMsg(m){
  if(m.type==='loading'){AI.pct=m.percent;AI.label=m.label;const b=document.getElementById('aiMeter');if(b)b.style.width=m.percent+'%';const t=document.getElementById('aiLoadT');if(t)t.textContent=(m.label==='model'?'Memuat turun model AI':m.label==='korpus'?'Memuat turun data ayat':'Menyediakan')+' '+m.percent+'%';return}
  if(m.type==='ready'){AI.ready=true;if(AI.phase==='loading')AI.phase='ready';renderDock();return}
  if(m.type==='error'){aiFail(/fetch|404|Gagal/i.test(m.message)?'Model AI belum tersedia. Pastikan ada internet untuk muat turun kali pertama.':'Ralat AI: '+m.message);return}
  if(m.type==='progress'){const i=vIndex(m.surah,m.ayah);AI.total[i]=m.total;const set=heard[i]||(heard[i]=new Set());m.matched.forEach(x=>set.add(x+1));
    document.querySelectorAll(`.w[data-i="${i}"]`).forEach(el=>{if(set.has(+el.dataset.w)){el.classList.add('heard');el.classList.remove('h')}});
    const c=document.getElementById('aiCount');if(c)c.textContent=aiCoverage().txt;return}
  if(m.type==='issue'){const is=m.issue,i=vIndex(is.surah,is.ayah);AI.issues.push(is);aiIssue.add(i);document.querySelectorAll(`.w[data-i="${i}"]`).forEach(el=>el.classList.add('issue'));return}
  if(m.type==='done'){AI.phase='ready';renderDock();aiResult()}}
function aiCoverage(){const p=AI.page;let n=0,ok=0;for(let i=pageFirst(p);i<pageEnd(p);i++){n++;const t=AI.total[i],h=heard[i];if(t&&h&&h.size/t>=0.6)ok++}return{n,ok,txt:ok+' daripada '+n+' ayat didengar'}}
function aiDock(){
  const ph=AI.phase;let inner='';
  if(ph==='ask')inner=`<div class="dock-t"><b>Tasmik AI (beta)</b><span>Kali pertama perlu muat turun kira-kira 75 MB. Guna Wi-Fi jika boleh.</span></div><button class="btn sm pri" data-aiload="1">Muat turun</button><button class="btn sm ghost" data-aiclose="1">${ico('x',16)}</button>`;
  else if(ph==='loading')inner=`<div class="dock-t"><b id="aiLoadT">Menyediakan AI ${AI.pct||0}%</b><div class="meter"><i id="aiMeter" style="width:${AI.pct||0}%"></i></div></div><button class="btn sm ghost" data-aiclose="1">${ico('x',16)}</button>`;
  else if(ph==='ready')inner=`<button class="mic" data-aistart="1" aria-label="Mula tasmik">${ico('mic',22)}</button><div class="dock-t"><b>Sedia untuk ${HL(AI.page)}</b><span>Tekan mikrofon dan mula membaca. Perkataan yang didengar akan muncul hijau.</span></div><button class="btn sm ghost" data-aiclose="1">${ico('x',16)}</button>`;
  else if(ph==='recording')inner=`<button class="mic rec" data-aistop="1" aria-label="Selesai">${ico('stop',20)}</button><div class="dock-t"><b><span id="aiTime">0:00</span>, sedang mendengar</b><span id="aiCount">${aiCoverage().txt}</span><div class="meter" style="margin-top:4px"><i id="aiLvl" style="width:0"></i></div></div><button class="btn sm pri" data-aistop="1">Selesai</button>`;
  else if(ph==='processing')inner=`<span class="eq"><i></i><i></i><i></i></span><div class="dock-t"><b>Menyemak bacaan…</b></div>`;
  else inner=`<div class="dock-t"><b>Tasmik AI tidak dapat diteruskan</b><span>${esc(AI.err)}</span></div><button class="btn sm" data-aiload="1">Cuba lagi</button><button class="btn sm ghost" data-aiclose="1">${ico('x',16)}</button>`;
  return`<div class="dock-in">${inner}</div>`}
function aiResult(){
  const p=AI.page,cov=aiCoverage(),iss=AI.issues,inSab=S.sabaq.includes(p),good=!iss.length&&cov.ok>=Math.ceil(cov.n*0.9);
  openSheet(`<h3>${good?'Bacaan lancar, alhamdulillah':iss.length?iss.length+' perkara untuk disemak':'Sebahagian ayat belum didengar'}</h3>
   <p class="muted" style="margin:0">${cov.txt} di ${HL(p)}.</p>
   ${iss.length?`<div class="panel" style="display:flex;flex-direction:column;gap:10px">${iss.map((s,k)=>{const i=vIndex(s.surah,s.ayah);return`<div class="row"><span style="flex:1">${AI_KIND[s.kind]||'Perlu disemak'}: ${esc(SURAH[s.surah-1])} ${s.surah}:${s.ayah}${s.kind==='possible_skipped_ayah'?'':', perkataan ke-'+(s.word+1)}</span><button class="btn sm" data-aimark="${k}">Tanda</button></div>`}).join('')}</div><button class="btn soft" data-aimarkall="1">Tanda semua ayat ini</button>`:''}
   ${inSab?(good?`<button class="btn ok" data-aicount="1">${ico('check',18)}Kira sebagai tasmik lancar</button>`:`<button class="btn" data-aicount="0">Kira sebagai ada salah</button>`):''}
   <small class="muted">AI ini masih beta. Ia boleh tersilap dan tidak menyemak tajwid. Gunakan sebagai pembantu, bukan pengganti guru.</small>
   <button class="btn ghost" data-close="1">Tutup</button>`)}
function aiMark(is){const i=vIndex(is.surah,is.ayah);if(!openMarks().some(m=>m.i===i))addMark(i,is.kind==='possible_substitution'?'tukar':'lupa',AI_KIND[is.kind]||'','tasmik AI')}
