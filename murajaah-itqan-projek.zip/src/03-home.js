/* ---------- Taman Murajaah ---------- */
function unitProgress(){ // unit sabaq semasa (juz atau surah) dan peratus lancar
  const p=S.sabaq[0];if(!p)return null;
  const [t,n,[a,b]]=S.set.sabaqMode==='surah'?['surah',VS[pageFirst(p)],surahPages(VS[pageFirst(p)])]:['juz',PJ[p],juzPages(PJ[p])];
  let ok=0;for(let q=a;q<=b;q++)if(lv(q)===2)ok++;return{label:t==='surah'?'Surah '+SURAH[n-1]:'Juz '+n,pct:ok/(b-a+1)}}
function rnd(seed){let x=Math.sin(seed*999)*10000;return x-Math.floor(x)}
function gardenSVG(){
  const W=400,H=170,trees=S.trees,fl=S.grads.length,u=unitProgress(),night=skyNow().k==='malam';
  let s=`<svg viewBox="0 0 ${W} ${H}" role="img" aria-label="Taman: ${trees.length} pokok, ${fl} bunga">`;
  s+=`<defs><linearGradient id="gsky" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="${night?'#2c3a63':'#e4f3fd'}"/><stop offset="1" stop-color="${night?'#46507a':'#fbf3e8'}"/></linearGradient></defs>`;
  s+=`<rect width="${W}" height="${H}" fill="url(#gsky)"/>`;
  s+=`<path d="M0 118c60-22 120-22 190-8s140 12 210-6v66H0z" fill="${night?'#3f6b55':'#c5e6c9'}"/><path d="M0 132c70-14 140-10 210 0s130 8 190-4v42H0z" fill="${night?'#355d49':'#a9d8b2'}"/>`;
  // pokok berbuah (juz/surah lancar)
  const show=trees.slice(-7);
  show.forEach((t,i)=>{const x=34+i*46,y=124,h=38+((i*7)%10),fruit=t.t==='surah'?'#f4a259':'#e8687e';
    s+=`<rect x="${x-3}" y="${y-h}" width="6" height="${h}" rx="3" fill="#9a6b45"/><circle cx="${x}" cy="${y-h-6}" r="20" fill="#6dbb84"/><circle cx="${x-11}" cy="${y-h+2}" r="13" fill="#7fc795"/><circle cx="${x+12}" cy="${y-h+1}" r="12" fill="#5fae78"/>`;
    for(let f=0;f<5;f++){const fx=x-12+rnd(i*10+f)*24,fy=y-h-14+rnd(i*20+f)*22;s+=`<circle cx="${fx.toFixed(1)}" cy="${fy.toFixed(1)}" r="3.4" fill="${fruit}"/>`}
    s+=`<text x="${x}" y="${y+13}" text-anchor="middle" font-size="9.5" font-family="Atkinson,sans-serif" fill="${night?'#d7ecdd':'#3c6a4b'}">${t.t==='surah'?'S'+t.n:'J'+t.n}</text>`});
  if(trees.length>7)s+=`<text x="12" y="20" font-size="11" fill="${night?'#fff':'#3c6a4b'}" font-family="Atkinson,sans-serif">+${trees.length-7} pokok lagi</text>`;
  // anak pokok untuk unit semasa
  if(u){const x=W-44,y=128,h=10+Math.round(u.pct*46);
    s+=`<path d="M${x} ${y}V${y-h}" stroke="#4f9a68" stroke-width="4" stroke-linecap="round"/><path d="M${x} ${y-h+6}c-4-8-12-10-18-8 3 8 10 11 18 8z" fill="#7fc795"/><path d="M${x} ${y-h+2}c4-9 12-12 19-10-2 9-11 12-19 10z" fill="#8fd1a3"/>`;
    s+=`<text x="${x}" y="${y+14}" text-anchor="middle" font-size="9.5" font-family="Atkinson,sans-serif" fill="${night?'#d7ecdd':'#3c6a4b'}">${Math.round(u.pct*100)}%</text>`}
  // bunga (halaman yang lancar melalui sabaq)
  const cols=['#f6a6bd','#ffd36e','#b9a6ee','#ffb38a','#9ed6f6'];
  for(let k=0;k<Math.min(fl,26);k++){const fx=14+rnd(k+1)*(W-80),fy=140+rnd(k+50)*24,c=cols[k%5];
    s+=`<g transform="translate(${fx.toFixed(1)} ${fy.toFixed(1)})"><path d="M0 0v9" stroke="#5fa577" stroke-width="1.5"/>${[0,72,144,216,288].map(a=>`<ellipse rx="2.6" ry="4.4" fill="${c}" transform="rotate(${a}) translate(0 -3.6)"/>`).join('')}<circle r="2" fill="#fff5c2"/></g>`}
  return s+'</svg>'}
function gardenCard(){
  const u=unitProgress(),w=streak(),fl=S.grads.length,tr=S.trees.length;
  return`<section class="garden">${gardenSVG()}<div class="cap"><b>Taman Murajaah</b><span>${ico('drop',14)} Disiram ${w} hari berturut</span><span>${tr} pokok, ${fl} bunga</span>${u?`<span>${esc(u.label)}: ${Math.round(u.pct*100)}% lancar</span>`:''}</div></section>`}

/* ---------- Hari Ini ---------- */
const INFO={
  sabaq:['Sabaq','Halaman yang sedang diperkuat atau dihafal. Tasmik '+'beberapa kali lancar berturut-turut, kemudian jawab kuiz ringkas. Lulus 70% baru halaman itu dikira lancar, masuk manzil, dan sekuntum bunga mekar di taman.'],
  sabqi:['Sabqi','Ulangan halaman yang baru lancar, ditambah bahagian daripada juz sederhana mengikut sempadan maqra\'. Tekan selesai dan jawab kuiz. Kalau belum lulus, halaman yang tersalah akan diulang lebih kerap.'],
  manzil:['Manzil','Pusingan halaman yang dah lancar, ikut sempadan hizb atau juz sebenar. Kalau terlepas sehari, esok sambung dari tempat yang sama. Tekan selesai dan jawab kuiz.']};
function vHome(){
  const P=S.plan,today=dkey(),yest=addDays(today,-1);
  const cnt=[0,0,0,0];for(let p=1;p<=604;p++)cnt[lv(p)]++;
  let h='';
  if(!S.set.name)h+=`<section class="panel namecard"><div class="field"><label for="nmIn">Siapa nama anda?</label><input type="text" id="nmIn" maxlength="24" placeholder="Contoh: Ainul" autocomplete="given-name"></div><button class="btn pri" data-savename="1">Simpan</button></section>`;
  h+=gardenCard();
  // Peringatan ringkas
  const recentMarks=openMarks().filter(m=>m.d===today||m.d===yest);
  const todayPages=new Set([...S.sabaq,...sqPages(),...P.mz]);
  const quiz=recentMarks.filter(m=>m.src&&m.src.startsWith('kuiz'));
  const manual=openMarks().filter(m=>!(m.src&&m.src.startsWith('kuiz'))&&(todayPages.has(m.p)||m.d===today||m.d===yest));
  if(quiz.length||manual.length){
    const byKind={};quiz.forEach(m=>{byKind[m.src]=(byKind[m.src]||0)+1});
    h+=`<section class="alert"><h3>Sebelum mula, ingat ini</h3>`;
    Object.entries(byKind).forEach(([k,n])=>{h+=`<div class="it"><span>${k.replace('kuiz','Kuiz')}: ${n} ayat perlu diulang</span><button class="btn sm" data-quizmarks="${esc(k)}">Lihat</button></div>`});
    if(manual.length)h+=`<div class="it"><span>${manual.length} ayat yang anda tandakan ada dalam bacaan hari ini</span><button class="btn sm" data-manualmarks="1">Lihat</button></div>`;
    h+=`</section>`}
  // Sabaq
  h+=`<section class="task sb"><div class="task-h"><h3>Sabaq</h3><button class="info" data-info="sabaq" aria-label="Apa itu sabaq">i</button></div>`;
  if(!S.sabaq.length)h+=`<p class="muted" style="margin:0">Semua halaman dalam susunan sabaq anda dah lancar.</p>`;
  S.sabaq.forEach((p,k)=>{const n=S.tas[p]||0,mk=marksOnPage(p).length;
    h+=`<div class="reading"><button class="t" data-open="${p}" style="border:0;background:none;padding:0;text-align:left"><span class="big">${HL(p)}</span><span class="sub">${esc(pageLabel(p))}, Juz ${PJ[p]}${mk?`, ${mk} ayat bertanda`:''}</span></button>${k>=1?`<button class="x" data-rmsabaq="${p}" aria-label="Buang ${HL(p)} daripada sabaq">${ico('x',16)}</button>`:''}</div>
    <div class="row"><span class="dots" aria-label="${n} daripada ${S.set.need} tasmik">${range(1,S.set.need).map(i=>`<i class="${i<=n?'on':''}"></i>`).join('')}</span><span class="small muted">${n} daripada ${S.set.need} tasmik lancar</span></div>
    <div class="row"><button class="btn ok" data-tas="${p}" data-ok="1">${ico('check',18)}Lancar</button><button class="btn" data-tas="${p}" data-ok="0">${ico('x',18)}Ada salah</button><button class="btn soft" data-ai="${p}">${ico('mic',18)}Tasmik AI</button><button class="btn ghost sm" data-grad="${p}">Tanda lancar terus</button></div>`});
  h+=`<button class="btn ghost sm" id="addSabaq" style="align-self:flex-start">${ico('plus',16)}Tambah halaman sabaq</button></section>`;
  // Sabqi
  const sq=sqPages();
  h+=`<section class="task sq"><div class="task-h"><h3>Sabqi</h3><span class="count">${sq.length} halaman</span><button class="info" data-info="sabqi" aria-label="Apa itu sabqi">i</button></div>`;
  if(sq.length){h+=`<div class="ranges">${groupRanges(sq).map(r=>`<button data-open="${r[0]}">${rangeText(r)}${P.sq&&r[0]>=P.sq.a&&r[1]<=P.sq.b?`<small>${chunkLabel(P.sq.st,P.sq.k)}</small>`:'<small>Baru lancar</small>'}</button>`).join('')}</div>
    <button class="done-btn ${P.done.sq?'done':''}" data-done="sq"><span class="box">${P.done.sq?ico('check',15):''}</span>${P.done.sq?'Sabqi selesai':'Selesai, jawab kuiz'}</button>`}
  else h+=`<p class="muted" style="margin:0">Tiada sabqi hari ini.</p>`;
  h+=`</section>`;
  // Manzil
  h+=`<section class="task mz"><div class="task-h"><h3>Manzil</h3><span class="count">${P.mz.length} halaman</span><button class="info" data-info="manzil" aria-label="Apa itu manzil">i</button></div>`;
  if(P.mz.length){h+=`<div class="ranges">${groupRanges(P.mz).map(r=>`<button data-open="${r[0]}">${rangeText(r)}<small>${P.mzc?chunkLabel(P.mzc.st,P.mzc.k):''}</small></button>`).join('')}</div>
    <button class="done-btn ${P.done.mz?'done':''}" data-done="mz"><span class="box">${P.done.mz?ico('check',15):''}</span>${P.done.mz?'Manzil selesai':'Selesai, jawab kuiz'}</button>`}
  else h+=`<p class="muted" style="margin:0">Belum ada halaman lancar untuk manzil.</p>`;
  h+=`</section>`;
  // Rekod
  const days=range(-6,0).map(n=>addDays(today,n)),vals=days.map(k=>(S.log[k]&&S.log[k].p)||0),mx=Math.max(5,...vals),wk=vals.reduce((a,b)=>a+b,0);
  h+=`<h2 class="sec">Rekod</h2><div class="stats"><div class="stat"><b>${streak()}</b><span>hari disiram</span></div><div class="stat"><b>${wk}</b><span>halaman minggu ini</span></div><div class="stat"><b>${openMarks().length}</b><span>ayat bertanda</span></div></div>
  <section class="panel"><div class="row" style="justify-content:space-between"><b>7 hari lepas</b><span class="small muted">halaman diulang</span></div><div class="week">${days.map((k,i)=>`<div><em>${vals[i]||''}</em><i class="${vals[i]?'':'zero'}" style="height:${Math.max(4,vals[i]/mx*62)}px"></i><span>${HARI[new Date(k+'T00:00').getDay()].slice(0,3)}</span></div>`).join('')}</div></section>
  <section class="panel"><div class="row" style="justify-content:space-between"><b>Tahap 604 halaman</b><button class="btn sm ghost" data-tab-go="peta">Lihat peta</button></div><div class="lvbar">${[2,1,0,3].map(v=>`<i class="l${v}" style="width:${cnt[v]/6.04}%"></i>`).join('')}</div><div class="legend"><span><b class="l2"></b>Lancar ${cnt[2]}</span><span><b class="l1"></b>Sederhana ${cnt[1]}</span><span><b class="l0"></b>Lemah ${cnt[0]}</span>${cnt[3]?`<span><b class="l3"></b>Belum hafal ${cnt[3]}</span>`:''}</div></section>`;
  return h}
function marksListSheet(list,title){
  openSheet(`<h3>${esc(title)}</h3><div>${list.map(m=>`<div class="mk"><div class="h"><span class="pill ${m.t}">${m.t==='lupa'?'Lupa':'Tertukar'}</span><b>${esc(SURAH[m.s-1])} ${m.s}:${m.a}</b><span>${HL(m.p)}</span></div><div class="ar">${esc(T[m.i])}</div><div class="row"><button class="btn sm" data-open="${m.p}" data-ay="${m.i}">Buka</button><button class="btn sm ok" data-res="${m.id}" data-close="1">Dah baik</button></div></div>`).join('')}</div><button class="btn ghost" data-close="1">Tutup</button>`)}

/* ---------- Peta kelancaran ---------- */
let mapMode='juz',markFilter='open';
const LVN=['Lemah','Sederhana','Lancar','Belum hafal'];
const lvColor=v=>['var(--bad)','var(--mid)','var(--ok)','var(--none)'][v];
function cellsFor(a,b){const mp=new Set(openMarks().map(m=>m.p));return range(a,b).map(p=>`<button style="background:${lvColor(lv(p))}" class="${mp.has(p)?'has-m':''}" data-open="${p}" aria-label="${HL(p)}, ${LVN[lv(p)]}"></button>`).join('')}
function avgLv(a,b){let s=0,n=0;for(let p=a;p<=b;p++){const v=lv(p);if(v<3){s+=v;n++}}if(!n)return 3;const x=s/n;return x<0.67?0:x<1.5?1:2}
function vPeta(){
  let h=`<div class="seg" role="tablist">${[['juz','Juz'],['surah','Surah'],['hizb','Hizb']].map(([k,l])=>`<button class="${mapMode===k?'on':''}" data-map="${k}">${l}</button>`).join('')}</div>
  <div class="legend"><span><b class="l2"></b>Lancar</span><span><b class="l1"></b>Sederhana</span><span><b class="l0"></b>Lemah</span><span><b class="l3"></b>Belum hafal</span></div><section class="panel">`;
  if(mapMode==='juz'){for(let j=1;j<=30;j++){const [a,b]=juzPages(j);h+=`<div class="maprow"><button class="lbl" data-open="${a}"><b>Juz ${j}</b><span>Halaman ${a}–${b}</span></button><div class="cells">${cellsFor(a,b)}</div></div>`}}
  else if(mapMode==='surah'){for(let s=1;s<=114;s++){const [a,b]=surahPages(s);h+=`<div class="maprow"><button class="lbl" data-open="${a}"><b>${s}. ${esc(SURAH[s-1])}</b><span>Halaman ${a}${b>a?'–'+b:''}</span></button><div class="cells">${cellsFor(a,b)}</div></div>`}}
  else{for(let hz=1;hz<=60;hz++){const m0=(hz-1)*4+1,[a]=maqraPages(m0),[,b]=maqraPages(m0+3);h+=`<div class="maprow"><button class="lbl" data-open="${a}"><b>Hizb ${hz}</b><span>Juz ${Math.ceil(hz/2)}, halaman ${a}–${b}</span></button><div class="quarters">${[0,1,2,3].map(q=>{const [x,y]=maqraPages(m0+q);const v=avgLv(x,y);return`<button style="background:${lvColor(v)}" data-open="${x}" aria-label="Maqra' ${m0+q}, ${LVN[v]}">${['Awal','¼','½','¾'][q]}</button>`}).join('')}</div></div>`}}
  return h+`</section>`}

/* ---------- Tanda ---------- */
function vTanda(){
  let list=S.marks;
  if(markFilter==='open')list=list.filter(m=>!m.r);else if(markFilter==='lupa'||markFilter==='tukar')list=list.filter(m=>!m.r&&m.t===markFilter);else if(markFilter==='kuiz')list=list.filter(m=>!m.r&&m.src&&m.src.startsWith('kuiz'));else if(markFilter==='res')list=list.filter(m=>m.r);
  list=[...list].sort((x,y)=>markFilter==='open'?x.i-y.i:0);
  let h=`<div class="filters">${[['open','Belum selesai'],['lupa','Lupa'],['tukar','Tertukar'],['kuiz','Dari kuiz'],['res','Dah baik']].map(([k,l])=>`<button class="${markFilter===k?'on':''}" data-mf="${k}">${l}</button>`).join('')}</div><section class="panel">`;
  if(!list.length)h+=`<div class="empty">${markFilter==='res'?'Belum ada tanda yang dibaiki.':'Tiada ayat bertanda. Tekan mana-mana ayat dalam Mushaf untuk menandakannya.'}</div>`;
  list.forEach(m=>{h+=`<div class="mk ${m.r?'res':''}"><div class="h"><span class="pill ${m.t}">${m.t==='lupa'?'Lupa':'Tertukar'}</span><b>${esc(SURAH[m.s-1])} ${m.s}:${m.a}</b><span>${HL(m.p)}, ${fmtShort(m.d)}${m.src?', '+esc(m.src):''}</span></div><div class="ar">${esc(T[m.i])}</div>${m.n?`<div class="note">${esc(m.n)}</div>`:''}<div class="row"><button class="btn sm" data-open="${m.p}" data-ay="${m.i}">Buka</button>${m.r?`<button class="btn sm ghost" data-unres="${m.id}">Tanda semula</button>`:`<button class="btn sm ok" data-res="${m.id}">Dah baik</button>`}<button class="btn sm ghost" data-del="${m.id}">Padam</button></div></div>`});
  return h+`</section>`}
