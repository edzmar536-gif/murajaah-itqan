/* ---------- Helaian & paparan ---------- */
let tab='home';
const $=s=>document.querySelector(s);
function toast(msg){document.querySelectorAll('.toast').forEach(x=>x.remove());const t=document.createElement('div');t.className='toast';t.setAttribute('role','status');t.textContent=msg;document.body.appendChild(t);setTimeout(()=>t.remove(),3200)}
function petals(){if(matchMedia('(prefers-reduced-motion: reduce)').matches)return;const cols=['#f6a6bd','#ffd36e','#b9a6ee','#ffb38a','#9ed6f6','#9fd8b0'];
  for(let k=0;k<20;k++){const e=document.createElement('i');e.className='petal';e.style.left=(Math.random()*100)+'vw';e.style.background=cols[k%cols.length];e.style.setProperty('--dx',(Math.random()*120-60)+'px');e.style.animationDuration=(1.8+Math.random()*1.4)+'s';e.style.animationDelay=(Math.random()*.4)+'s';document.body.appendChild(e);setTimeout(()=>e.remove(),3800)}}
const layerOpen=()=>!!$('#layer').innerHTML;
function closeLayer(){$('#layer').innerHTML=''}
function closeSheet(){closeLayer();if(selAyah!==null&&tab==='mushaf'){selAyah=null;render()}}
function openSheet(html,onMount){$('#layer').innerHTML=`<div class="scrim" data-close="1"></div><div class="sheet" role="dialog" aria-modal="true"><div class="grab"></div><div class="wrap">${html}</div></div>`;onMount&&onMount($('#layer .sheet'))}
function greet(){const n=S.set.name.trim();$('#greet').textContent='Bismillah, jom mula'+(n?' '+n:'');$('#greetSub').textContent=fmtDate(dkey())}
function render(){
  ensure();greet();
  if(tab==='mushaf'){if(curPage!==lastPg){revealed=new Set();lastPg=curPage}S.lastPage=curPage;saveLocal()}
  $('#view').innerHTML=tab==='home'?vHome():tab==='mushaf'?vMushaf():tab==='peta'?vPeta():vTanda();
  if(tab==='mushaf')afterMushaf();
  document.querySelectorAll('nav.tabs button').forEach(b=>b.setAttribute('aria-current',b.dataset.tab===tab?'page':'false'))}
function go(t,opts={}){if(t!=='mushaf'&&fullscreen){fullscreen=false;document.body.classList.remove('fs')}tab=t;if(opts.page)curPage=opts.page;if(opts.ayah!==undefined)selAyah=opts.ayah;render();window.scrollTo(0,0)}

/* ---------- Tetapan ---------- */
const sqOpts=[[0,'Tiada'],[2,'¼ juz'],[4,'½ juz'],[8,'1 juz'],[16,'2 juz']],mzOpts=[[2,'¼ juz'],[4,'½ juz'],[8,'1 juz'],[16,'2 juz']];
function startOptions(mode,cur){
  if(mode==='surah')return SURAH.map((n,k)=>`<option value="${k+1}" ${cur===k+1?'selected':''}>${k+1}. ${esc(n)}</option>`).join('');
  if(mode==='juz')return range(1,30).map(j=>`<option value="${j}" ${cur===j?'selected':''}>Juz ${j}</option>`).join('');
  return range(1,30).map(j=>{const a=juzPages(j)[0];return`<option value="${a}" ${cur===a?'selected':''}>Halaman ${a} (awal Juz ${j})</option>`}).join('')}
let deferredInstall=null;window.addEventListener('beforeinstallprompt',e=>{e.preventDefault();deferredInstall=e});
function settingsSheet(){
  const st=S.set;
  openSheet(`<h3>Tetapan</h3>
  <div class="field"><label for="sName">Nama</label><input type="text" id="sName" maxlength="24" value="${esc(st.name)}" placeholder="Nama anda"></div>
  <div class="field"><span class="lbl">Tema</span><div class="seg">${[['light','Terang'],['dark','Gelap'],['','Ikut fon']].map(([k,l])=>`<button class="${st.theme===k?'on':''}" data-themeset="${k}">${l}</button>`).join('')}</div></div>
  <div class="field"><span class="lbl">Warna</span><div class="swatches">${Object.entries(PALET).map(([k,v])=>`<button class="${st.palette===k?'on':''}" data-palette="${k}" aria-label="${v.n}" title="${v.n}"><span style="background:${v.L[2]}"></span></button>`).join('')}</div><small>${PALET[st.palette].n}. Halaman mushaf kekal krim.</small></div>
  <div class="field"><span class="lbl">Sabaq ikut</span><div class="seg" id="sMode">${[['halaman','Halaman'],['surah','Surah'],['juz','Juz']].map(([k,l])=>`<button class="${st.sabaqMode===k?'on':''}" data-v="${k}">${l}</button>`).join('')}</div></div>
  <div class="grid2"><div class="field"><label for="sStart">Mula dari</label><select id="sStart">${startOptions(st.sabaqMode,st.start)}</select></div>
  <div class="field"><label for="sDir">Arah</label><select id="sDir"><option value="maju" ${st.sabaqDir==='maju'?'selected':''}>Ke hadapan</option><option value="undur" ${st.sabaqDir==='undur'?'selected':''}>Ke belakang</option></select></div></div>
  <div class="grid2"><div class="field"><label for="sN">Halaman sabaq serentak</label><input type="number" id="sN" min="1" max="10" value="${st.sabaqN}"></div><div class="field"><label for="sNeed">Tasmik untuk lancar</label><input type="number" id="sNeed" min="1" max="10" value="${st.need}"></div></div>
  <div class="grid2"><div class="field"><label for="sR">Sabqi: halaman baru lancar</label><input type="number" id="sR" min="0" max="20" value="${st.recentN}"></div><div class="field"><label for="sSq">Sabqi: dari juz sederhana</label><select id="sSq">${sqOpts.map(([v,l])=>`<option value="${v}" ${st.sqMaqra===v?'selected':''}>${l}</option>`).join('')}</select></div></div>
  <div class="field"><label for="sMz">Manzil sehari</label><select id="sMz">${mzOpts.map(([v,l])=>`<option value="${v}" ${st.mzMaqra===v?'selected':''}>${l}</option>`).join('')}</select><small>Ikut sempadan hizb dan juz sebenar.</small></div>
  <div class="field"><label for="sRec">Qari utama</label><select id="sRec">${Object.entries(QARI).map(([k,v])=>`<option value="${k}" ${st.reciter===k?'selected':''}>${esc(v.n)}</option>`).join('')}</select></div>
  <label class="row" style="font-weight:600"><input type="checkbox" id="sRest" ${st.rest?'checked':''}> Hari rehat: satu hari terlepas setiap minggu tidak memutuskan siraman taman</label>
  ${NATIVE?`<div class="field"><span class="lbl">Reminder harian</span><div class="grid2"><div class="field"><label for="r1">Pertama</label><input type="time" id="r1" value="${st.rem1}"></div><div class="field"><label for="r2">Kedua</label><input type="time" id="r2" value="${st.rem2}"></div></div><label class="row"><input type="checkbox" id="rOn" ${st.remOn?'checked':''}> Hidupkan reminder</label><button class="btn sm" id="rTest">Cuba notifikasi (5 saat)</button></div>`:`<p class="small muted" style="margin:0">Reminder harian hanya ada dalam app Android.</p><a class="btn soft" href="${esc(CFG.apkUrl)}" rel="noopener">Muat turun app Android (APK)</a>${deferredInstall?'<button class="btn soft" id="instBtn">Pasang app di skrin utama</button>':''}`}
  <button class="btn pri" id="sSave">Simpan tetapan</button>
  <details><summary><b>Sandaran data</b></summary><div class="row" style="margin-top:8px"><button class="btn sm" id="bkCopy">Salin data</button>${NATIVE?'':'<button class="btn sm" id="bkFile">Simpan fail sandaran</button>'}<button class="btn sm" id="bkPaste">Pulihkan dari teks</button><label class="btn sm" for="bkIn">Pulihkan dari fail</label><input type="file" id="bkIn" accept=".json,application/json" hidden></div><p class="small muted">Untuk pindah ke fon atau app lain: salin data di sini, kemudian pulihkan di sana.</p></details>
  <details><summary><b>Ulang soalan permulaan</b></summary><p class="small muted">Tetapkan semula tahap setiap juz dan cara mengulang. Tanda ayat, rekod dan taman tidak dipadam.</p><button class="btn sm" id="rsWiz">Mula soalan permulaan</button></details>
  <details><summary><b>Tentang & penghargaan</b></summary><div class="small muted" style="display:flex;flex-direction:column;gap:6px;margin-top:8px">
   <span>Teks dan fon mushaf: King Fahd Glorious Qur'an Printing Complex (QPC Hafs), susunan halaman melalui projek mushaf-layout.</span>
   <span>Terjemahan: Abdullah Muhammad Basmeih (Bahasa Melayu). Maksud perkataan: Quran.com (Inggeris).</span>
   <span>Audio: EveryAyah.com dan arkib bacaan Bandar Baleela di archive.org.</span>
   <span>Tasmik AI: model Zipformer projek Tilawa (lesen NPL-1.2, bukan komersial). AI masih beta, boleh tersilap dan tidak menyemak tajwid.</span>
   <span>Fon: Shantell Sans dan Atkinson Hyperlegible Next (SIL OFL).</span>
   <span>App ini percuma untuk kegunaan peribadi. Penerbitan app Al-Quran kepada umum di Malaysia memerlukan perakuan KDN.</span></div></details>
  <button class="btn ghost" data-close="1">Tutup</button>`,sh=>{
    let mode=st.sabaqMode;
    sh.querySelectorAll('#sMode button').forEach(b=>b.onclick=()=>{mode=b.dataset.v;sh.querySelectorAll('#sMode button').forEach(x=>x.classList.toggle('on',x===b));sh.querySelector('#sStart').innerHTML=startOptions(mode,mode==='halaman'?1:1)});
    sh.querySelector('#sSave').onclick=()=>{const n=(id,lo,hi,d)=>Math.min(hi,Math.max(lo,parseInt(sh.querySelector(id).value)||d));
      const before=JSON.stringify([st.sabaqMode,st.sabaqDir,st.start]);
      st.name=sh.querySelector('#sName').value.trim();st.sabaqMode=mode;st.start=+sh.querySelector('#sStart').value;st.sabaqDir=sh.querySelector('#sDir').value;
      st.sabaqN=n('#sN',1,10,1);st.need=n('#sNeed',1,10,3);st.recentN=n('#sR',0,20,5);st.sqMaqra=+sh.querySelector('#sSq').value;st.mzMaqra=+sh.querySelector('#sMz').value;
      st.reciter=sh.querySelector('#sRec').value;st.rest=sh.querySelector('#sRest').checked;
      if(NATIVE){st.rem1=sh.querySelector('#r1').value||'06:30';st.rem2=sh.querySelector('#r2').value||'19:15';st.remOn=sh.querySelector('#rOn').checked}
      if(before!==JSON.stringify([st.sabaqMode,st.sabaqDir,st.start]))S.sabaq=S.sabaq.filter(p=>(S.tas[p]||0)>0);
      while(S.sabaq.length>st.sabaqN&&!(S.tas[S.sabaq[S.sabaq.length-1]]>0))S.sabaq.pop();
      if(S.plan&&!S.plan.done.mz&&!S.plan.done.sq)S.plan=null;save();closeLayer();render();if(NATIVE)setTimeout(()=>scheduleReminders(true),300);toast('Tetapan disimpan')};
    const t=sh.querySelector('#rTest');if(t)t.onclick=async()=>{const r=await scheduleReminders(true);if(r!=='granted'){toast('Benarkan notifikasi dalam Tetapan fon dahulu.');return}try{await Capacitor.Plugins.LocalNotifications.schedule({notifications:[{id:99,title:'Murajaah Itqan',body:'Notifikasi berfungsi. Jumpa waktu murajaah nanti!',smallIcon:'ic_stat_quran',schedule:{at:new Date(Date.now()+5000),allowWhileIdle:true}}]});toast('Notifikasi cubaan akan muncul dalam 5 saat')}catch(e){toast('Notifikasi cubaan tidak dapat dihantar')}};
    const ib=sh.querySelector('#instBtn');if(ib)ib.onclick=async()=>{deferredInstall.prompt();deferredInstall=null;closeLayer()};
    sh.querySelector('#bkCopy').onclick=()=>{const t=JSON.stringify(S);const fb=()=>openSheet(`<h3>Data sandaran</h3><p class="small muted">Tekan lama, pilih semua dan salin.</p><textarea readonly style="min-height:200px">${esc(t)}</textarea><button class="btn ghost" data-close="1">Tutup</button>`);try{navigator.clipboard.writeText(t).then(()=>toast('Data disalin. Simpan dalam nota anda.'),fb)}catch(e){fb()}};
    const bf=sh.querySelector('#bkFile');if(bf)bf.onclick=()=>{const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([JSON.stringify(S)],{type:'application/json'}));a.download='murajaah-sandaran-'+dkey()+'.json';a.click()};
    const restore=txt=>{try{const x=JSON.parse(txt);if(!x.levels)throw 0;S=migrate(x);orderCache.key='';save();applyTheme();closeLayer();render();toast('Data dipulihkan')}catch(e){toast('Ini bukan data sandaran Murajaah Itqan.')}};
    sh.querySelector('#bkPaste').onclick=()=>openSheet(`<h3>Pulihkan dari teks</h3><textarea id="pst" placeholder="Tampal data sandaran di sini" style="min-height:180px"></textarea><button class="btn pri" id="pstGo">Pulihkan</button><button class="btn ghost" data-close="1">Batal</button>`,s2=>{s2.querySelector('#pstGo').onclick=()=>restore(s2.querySelector('#pst').value)});
    sh.querySelector('#bkIn').onchange=e=>{const f=e.target.files[0];if(!f)return;const r=new FileReader();r.onload=()=>restore(r.result);r.readAsText(f)};
    sh.querySelector('#rsWiz').onclick=()=>{closeLayer();openWizard(true)};
  })}

/* ---------- Reminder (Android) ---------- */
function reminderBody(){try{ensure();const P=S.plan,sb=S.sabaq.length?'Sabaq halaman '+S.sabaq.join(', '):'Sabaq selesai';const mz=groupRanges(P.mz).map(r=>rangeText(r).replace('Halaman','halaman')).join(', ');return sb+'. Sabqi '+sqPages().length+' halaman.'+(mz?' Manzil '+mz+'.':'')}catch(e){return'Buka app untuk lihat jadual hari ini.'}}
async function scheduleReminders(ask){
  if(!NATIVE)return'web';const LN=Capacitor.Plugins&&Capacitor.Plugins.LocalNotifications;if(!LN)return'none';
  try{let p=await LN.checkPermissions();if(p.display!=='granted'&&ask)p=await LN.requestPermissions();
    try{await LN.cancel({notifications:[{id:1},{id:2}]})}catch(e){}
    if(p.display!=='granted')return p.display;if(!S.set.remOn)return'granted';
    const body=reminderBody(),who=S.set.name?', '+S.set.name:'',mk=(id,tm,title)=>{const [h,m]=tm.split(':').map(Number);return{id,title,body,largeBody:body,smallIcon:'ic_stat_quran',schedule:{on:{hour:h,minute:m},allowWhileIdle:true}}};
    await LN.schedule({notifications:[mk(1,S.set.rem1,'Jom murajaah'+who),mk(2,S.set.rem2,'Masa murajaah'+who)]});return'granted'}catch(e){return'error'}}
