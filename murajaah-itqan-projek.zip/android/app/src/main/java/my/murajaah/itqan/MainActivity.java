package my.murajaah.itqan;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
