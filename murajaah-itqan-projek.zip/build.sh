#!/usr/bin/env bash
# Bina APK Murajaah Itqan (dijalankan oleh GitHub Actions)
set -euo pipefail
npm ci
# Fon mushaf 15 baris (QPC1, 604 muka) diambil semasa bina supaya zip kecil
if [ ! -f www/qpc1/p604.woff2 ]; then
  rm -rf /tmp/ml
  git clone --depth 1 --filter=blob:none --sparse https://github.com/zonetecde/mushaf-layout /tmp/ml
  git -C /tmp/ml sparse-checkout set fonts/QPC1
  mkdir -p www/qpc1
  cp /tmp/ml/fonts/QPC1/*.woff2 /tmp/ml/fonts/QPC1/QPC1BSML.ttf www/qpc1/
fi
test "$(ls www/qpc1/p*.woff2 | wc -l)" -eq 604
npx cap sync android
cd android
chmod +x gradlew
./gradlew assembleRelease --no-daemon
cp app/build/outputs/apk/release/app-release.apk ../MurajaahItqan.apk
