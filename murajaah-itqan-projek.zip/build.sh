#!/usr/bin/env bash
# Bina Murajaah Itqan: APK Android (dan fail web app) — dijalankan oleh GitHub Actions
set -euo pipefail
npm ci
# 1. Kod app
cat src/*.js > www/app.js
# 2. AI tasmik: worker + ONNX runtime
npx esbuild ai/tasmik-worker.js --bundle --format=esm --minify --platform=browser --outfile=www/ai-rt/tasmik-worker.js
cp node_modules/onnxruntime-web/dist/ort-wasm-simd-threaded.wasm node_modules/onnxruntime-web/dist/ort-wasm-simd-threaded.mjs www/ai-rt/
if [ -n "${GITHUB_REPOSITORY:-}" ]; then
  OWNER="${GITHUB_REPOSITORY%%/*}"; REPO="${GITHUB_REPOSITORY##*/}"
  echo "window.APP_CFG={aiBase:'https://${OWNER,,}.github.io/${REPO}/ai/',apkUrl:'https://github.com/${GITHUB_REPOSITORY}/releases/latest/download/MurajaahItqan.apk'};" > www/config.js
fi
# 3. Fon mushaf 15 baris (QPC1, 604 halaman)
if [ ! -f www/qpc1/p604.woff2 ]; then
  rm -rf /tmp/ml
  git clone --depth 1 --filter=blob:none --sparse https://github.com/zonetecde/mushaf-layout /tmp/ml
  git -C /tmp/ml sparse-checkout set fonts/QPC1
  mkdir -p www/qpc1
  cp /tmp/ml/fonts/QPC1/*.woff2 www/qpc1/
fi
test "$(ls www/qpc1/p*.woff2 | wc -l)" -eq 604
# 4. APK
npx cap sync android
cd android
chmod +x gradlew
./gradlew assembleRelease --no-daemon
cp app/build/outputs/apk/release/app-release.apk ../MurajaahItqan.apk
