'use strict';
/* ---------- Persekitaran ---------- */
const NATIVE=!!(window.Capacitor&&Capacitor.isNativePlatform&&Capacitor.isNativePlatform());
const CFG=Object.assign({aiBase:'ai/',apkUrl:'https://github.com/edzmar536-gif/murajaah-itqan/releases/latest/download/MurajaahItqan.apk'},window.APP_CFG||{});
const D=window.QD, LAYOUT=window.QPC_LAYOUT||null;

/* ---------- Indeks Al-Quran ---------- */
const T=D.t.split('|'), N=T.length;
const SURAH=["Al-Fatihah","Al-Baqarah","Ali 'Imran","An-Nisa'","Al-Ma'idah","Al-An'am","Al-A'raf","Al-Anfal","At-Taubah","Yunus","Hud","Yusuf","Ar-Ra'd","Ibrahim","Al-Hijr","An-Nahl","Al-Isra'","Al-Kahfi","Maryam","Taha","Al-Anbiya'","Al-Hajj","Al-Mu'minun","An-Nur","Al-Furqan","Asy-Syu'ara'","An-Naml","Al-Qasas","Al-'Ankabut","Ar-Rum","Luqman","As-Sajdah","Al-Ahzab","Saba'","Fatir","Yasin","As-Saffat","Sad","Az-Zumar","Ghafir","Fussilat","Asy-Syura","Az-Zukhruf","Ad-Dukhan","Al-Jathiyah","Al-Ahqaf","Muhammad","Al-Fath","Al-Hujurat","Qaf","Az-Zariyat","At-Tur","An-Najm","Al-Qamar","Ar-Rahman","Al-Waqi'ah","Al-Hadid","Al-Mujadalah","Al-Hasyr","Al-Mumtahanah","As-Saff","Al-Jumu'ah","Al-Munafiqun","At-Taghabun","At-Talaq","At-Tahrim","Al-Mulk","Al-Qalam","Al-Haqqah","Al-Ma'arij","Nuh","Al-Jinn","Al-Muzzammil","Al-Muddaththir","Al-Qiyamah","Al-Insan","Al-Mursalat","An-Naba'","An-Nazi'at","'Abasa","At-Takwir","Al-Infitar","Al-Mutaffifin","Al-Insyiqaq","Al-Buruj","At-Tariq","Al-A'la","Al-Ghasyiyah","Al-Fajr","Al-Balad","Asy-Syams","Al-Lail","Ad-Duha","Asy-Syarh","At-Tin","Al-'Alaq","Al-Qadr","Al-Bayyinah","Az-Zalzalah","Al-'Adiyat","Al-Qari'ah","At-Takathur","Al-'Asr","Al-Humazah","Al-Fil","Quraisy","Al-Ma'un","Al-Kauthar","Al-Kafirun","An-Nasr","Al-Masad","Al-Ikhlas","Al-Falaq","An-Nas"];
const VS=new Uint8Array(N),VA=new Uint16Array(N),VP=new Uint16Array(N),VJ=new Uint8Array(N),VM=new Uint8Array(N),SS=[];
{let k=0;D.sc.forEach((c,s)=>{SS[s]=k;for(let a=1;a<=c;a++){VS[k]=s+1;VA[k]=a;k++}});SS[114]=N;
 for(let p=1;p<=604;p++)for(let i=D.pg[p-1];i<D.pg[p];i++)VP[i]=p;
 for(let j=0;j<30;j++){const e=j<29?D.jz[j+1]:N;for(let i=D.jz[j];i<e;i++)VJ[i]=j+1}
 for(let m=0;m<240;m++){const e=m<239?D.mq[m+1]:N;for(let i=D.mq[m];i<e;i++)VM[i]=m+1}}
const pageFirst=p=>D.pg[p-1], pageEnd=p=>D.pg[p];
const PJ=[0];for(let p=1;p<=604;p++){const c={};for(let i=pageFirst(p);i<pageEnd(p);i++)c[VJ[i]]=(c[VJ[i]]||0)+1;PJ[p]=+Object.keys(c).sort((a,b)=>c[b]-c[a])[0]}
const juzPages=j=>{const a=VP[D.jz[j-1]],b=j<30?VP[D.jz[j]]-(D.jz[j]===pageFirst(VP[D.jz[j]])?1:0):604;return[a,b]};
const surahPages=s=>[VP[SS[s-1]],VP[SS[s]-1]];
const maqraPages=m=>{const a=D.mq[m-1],e=(m<240?D.mq[m]:N)-1;return[VP[a],VP[e]]};
const chunkPages=(st,k)=>{const a=D.mq[st],e=(st+k<240?D.mq[st+k]:N)-1;return[VP[a],VP[e]]};
const AR=n=>String(n).replace(/\d/g,d=>'٠١٢٣٤٥٦٧٨٩'[d]);
const range=(a,b)=>{const r=[];for(let i=a;i<=b;i++)r.push(i);return r};
const surahsOnPage=p=>{const s=new Set();for(let i=pageFirst(p);i<pageEnd(p);i++)s.add(VS[i]);return[...s]};
const pageLabel=p=>surahsOnPage(p).map(x=>SURAH[x-1]).join(', ');
const esc=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const vkey=i=>VS[i]+':'+VA[i];
const vIndex=(s,a)=>SS[s-1]+a-1;
const pad3=n=>String(n).padStart(3,'0');
const HL=p=>'Halaman '+p;
const rangeText=([a,b])=>a===b?'Halaman '+a:'Halaman '+a+'–'+b;
function groupRanges(pages){const s=[...new Set(pages)].sort((a,b)=>a-b),r=[];for(const p of s){const l=r[r.length-1];if(l&&p===l[1]+1)l[1]=p;else r.push([p,p])}return r}
function chunkLabel(st,k){const j=Math.floor(st/8)+1;
  if(k>=16)return'Juz '+j+'–'+(j+k/8-1);if(k===8)return'Juz '+j;
  if(k===4)return'Hizb '+(st/4+1)+', Juz '+j;return'Suku '+((st%8)/2+1)+' Juz '+j}

/* ---------- Tarikh ---------- */
const dkey=(d=new Date())=>{const z=n=>String(n).padStart(2,'0');return d.getFullYear()+'-'+z(d.getMonth()+1)+'-'+z(d.getDate())};
const addDays=(k,n)=>{const [y,m,d]=k.split('-').map(Number);return dkey(new Date(y,m-1,d+n))};
const HARI=['Ahad','Isnin','Selasa','Rabu','Khamis','Jumaat','Sabtu'],BULAN=['Januari','Februari','Mac','April','Mei','Jun','Julai','Ogos','September','Oktober','November','Disember'];
const fmtDate=k=>{const [y,m,d]=k.split('-').map(Number);const dt=new Date(y,m-1,d);return HARI[dt.getDay()]+', '+d+' '+BULAN[m-1]};
const fmtShort=k=>{const [y,m,d]=k.split('-').map(Number);return d+' '+BULAN[m-1].slice(0,3)};

/* ---------- Ikon ---------- */
const IC={
  check:'<path d="M5 12.5l4.5 4.5L19 7.5"/>',x:'<path d="M6 6l12 12M18 6L6 18"/>',play:'<path d="M7 5l12 7-12 7z"/>',stop:'<rect x="6" y="6" width="12" height="12" rx="2"/>',
  mic:'<rect x="9" y="3" width="6" height="11" rx="3"/><path d="M5 11a7 7 0 0 0 14 0M12 18v3"/>',search:'<circle cx="11" cy="11" r="7"/><path d="M20 20l-4-4"/>',
  expand:'<path d="M4 9V4h5M20 9V4h-5M4 15v5h5M20 15v5h-5"/>',shrink:'<path d="M9 4v5H4M15 4v5h5M9 20v-5H4M15 20v-5h5"/>',eye:'<path d="M2 12s4-7 10-7 10 7 10 7-4 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/>',
  more:'<circle cx="5" cy="12" r="1.5"/><circle cx="12" cy="12" r="1.5"/><circle cx="19" cy="12" r="1.5"/>',left:'<path d="M15 5l-7 7 7 7"/>',right:'<path d="M9 5l7 7-7 7"/>',
  plus:'<path d="M12 5v14M5 12h14"/>',head:'<path d="M4 15v-3a8 8 0 0 1 16 0v3"/><rect x="3" y="14" width="5" height="7" rx="2"/><rect x="16" y="14" width="5" height="7" rx="2"/>',
  drop:'<path d="M12 3s6 7 6 11a6 6 0 0 1-12 0c0-4 6-11 6-11z"/>',book:'<path d="M2 4h6a4 4 0 0 1 4 4v13a3 3 0 0 0-3-3H2zM22 4h-6a4 4 0 0 0-4 4v13a3 3 0 0 1 3-3h7z"/>'};
const ico=(n,s=20)=>`<svg class="i" viewBox="0 0 24 24" style="width:${s}px;height:${s}px" aria-hidden="true">${IC[n]}</svg>`;

/* ---------- Palet & tema ---------- */
const PALET={
  sakura:{n:'Pink Sakura',L:['#fdf4f6','#ffffff','#e1879f','#fbe1e8','#f2dce2','#3a2930','#8a6c76'],Dk:['#1d1418','#291d22','#f0a3b8','#3e2630','#3b2a31','#f5e8ec','#b89aa4']},
  hijau:{n:'Hijau Lembut',L:['#f2f7f1','#ffffff','#5fa577','#dcefe1','#dbe8dd','#23362a','#66806d'],Dk:['#121a15','#1a251e','#8cc9a0','#213a2a','#283a2e','#e5f1e8','#93ad9b']},
  awan:{n:'Biru Awan',L:['#eef6fd','#ffffff','#5ea8de','#d9ecfa','#d5e6f3','#1f3a55','#6a84a0'],Dk:['#0f1a2b','#16253b','#8fcaf3','#1b3554','#253a56','#e4f0fb','#94aac3']},
  oren:{n:'Oren Lembut',L:['#fff6ee','#ffffff','#e58f4f','#fde5d1','#f3e0d0','#3d2a1c','#8c705c'],Dk:['#1d150f','#281d15','#f4b07c','#3d2a1b','#3a2b20','#f6eadf','#b89f8b']},
  ungu:{n:'Ungu Lembut',L:['#f5f2fc','#ffffff','#957ed3','#e7e0f7','#e3ddf2','#2c2540','#776e92'],Dk:['#16131f','#201b2d','#b9a6ee','#2f2745','#2f2942','#ece8f7','#a59dbd']}};
const mqDark=window.matchMedia?matchMedia('(prefers-color-scheme: dark)'):null;
function isDark(){const t=S.set.theme;return t==='dark'||(t!=='light'&&!!(mqDark&&mqDark.matches))}
function applyTheme(){
  const P=PALET[S.set.palette]||PALET.awan,dark=isDark(),c=dark?P.Dk:P.L,r=document.documentElement;
  ['--bg','--paper','--accent','--accent-soft','--line','--ink','--muted'].forEach((k,i)=>r.style.setProperty(k,c[i]));
  r.style.setProperty('--on-accent',dark?c[0]:'#ffffff');r.classList.toggle('dark',dark);
  const m=document.querySelector('meta[name=theme-color]');if(m)m.content=c[0];applySky()}
if(mqDark&&mqDark.addEventListener)mqDark.addEventListener('change',()=>{applyTheme()});

/* ---------- Langit ikut waktu ---------- */
function skyNow(){const h=new Date().getHours()+new Date().getMinutes()/60;
  if(h>=5&&h<7)return{k:'subuh',a:'#c9c2ec',b:'#fbd7c4',ink:'#2d2a4a',sun:[300,70,'#ffcf9e']};
  if(h>=7&&h<11)return{k:'pagi',a:'#bfe3fb',b:'#e6f4fd',ink:'#1f3a55',sun:[330,38,'#ffe3a3']};
  if(h>=11&&h<15)return{k:'tengahari',a:'#9fd2f6',b:'#d8eefc',ink:'#173750',sun:[350,22,'#fff1b8']};
  if(h>=15&&h<18.5)return{k:'petang',a:'#ffd8b0',b:'#fff0de',ink:'#4a2e15',sun:[330,48,'#ffbf7a']};
  if(h>=18.5&&h<20)return{k:'maghrib',a:'#f2a7a9',b:'#fbd2b0',ink:'#3f2130',sun:[320,82,'#ff9f7a']};
  return{k:'malam',a:'#1d2a4d',b:'#33416d',ink:'#eef2ff',moon:true}}
function applySky(){
  const s=skyNow(),hd=document.getElementById('sky');if(!hd)return;
  hd.style.setProperty('--sky1',s.a);hd.style.setProperty('--sky2',s.b);hd.style.setProperty('--sky-ink',s.ink);
  let g='';
  if(s.moon){g+=`<circle cx="340" cy="30" r="14" fill="#f6f1d3"/><circle cx="347" cy="25" r="12" fill="${s.a}"/>`;
    [[60,20],[120,45],[200,15],[250,60],[290,25],[385,55],[160,70],[30,62]].forEach(([x,y],i)=>g+=`<circle cx="${x}" cy="${y}" r="${i%3?1.3:1.9}" fill="#fff" opacity=".8"/>`)}
  else{const [x,y,c]=s.sun;g+=`<circle cx="${x}" cy="${y}" r="20" fill="${c}" opacity=".9"/>`;
    g+=`<g fill="#fff" opacity=".55"><ellipse cx="250" cy="70" rx="34" ry="10"/><ellipse cx="272" cy="62" rx="20" ry="11"/><ellipse cx="90" cy="22" rx="26" ry="8"/><ellipse cx="106" cy="16" rx="15" ry="9"/></g>`}
  document.getElementById('celestial').innerHTML=g}
/* ---------- Keadaan (disimpan dalam fon) ---------- */
const LKEY='murajaah-itqan-v1';
function initialLevels(){let s='';for(let p=1;p<=604;p++){const j=PJ[p];s+=(j<=6||j>=25)?'2':(j<=10?'1':'0')}return s}
function defSet(){return{name:'',sabaqMode:'halaman',sabaqDir:'maju',start:VP[D.jz[10]],sabaqN:1,need:3,recentN:5,sqMaqra:2,mzMaqra:4,
  reciter:'ghamidi',theme:'',palette:'awan',view:'full',order:'lemah',remOn:true,rem1:'06:30',rem2:'19:15',rest:true}}
function freshState(){return{v:2,updatedAt:0,levels:'3'.repeat(604),tas:{},sabaq:[],recent:[],sqPtr:0,mzPtr:0,plan:null,log:{},marks:[],
  onboarded:false,lastPage:1,trees:[],grads:[],set:defSet()}}
function migrate(s){
  const legacy=!!s&&s.onboarded===undefined;const had=!!s;
  s=Object.assign(freshState(),s||{});if(legacy)s.onboarded=true;
  const old=s.set||{};s.set=Object.assign(defSet(),old);
  if(had&&(s.v||1)<2){ // daripada versi 1.x
    s.sqPtr=((s.sqPtr|0)*2)%240;
    const mp=Math.min(604,Math.max(1,s.mzPtr|0||1));s.mzPtr=Math.floor((VM[pageFirst(mp)]-1)/4)*4;
    s.set.mzMaqra=({5:2,10:4,20:8,40:16})[old.mzN]||4;s.set.sqMaqra=2;s.set.sabaqMode='halaman';s.set.sabaqDir='maju';
    if(!old.palette)s.set.palette='awan';s.plan=null;s.lastPage=(s.sabaq&&s.sabaq[0])||1;s.v=2}
  if(typeof s.levels!=='string'||s.levels.length!==604)s.levels=had&&!legacy?'3'.repeat(604):initialLevels();
  if(!Array.isArray(s.trees))s.trees=[];if(!Array.isArray(s.grads))s.grads=[];
  return s}
let S;
try{S=migrate(JSON.parse(localStorage.getItem(LKEY)||'null'))}catch(e){S=freshState()}
const lv=p=>+S.levels[p-1];
const setLv=(p,v)=>{S.levels=S.levels.slice(0,p-1)+v+S.levels.slice(p)};
let remT=null;
function saveLocal(){try{localStorage.setItem(LKEY,JSON.stringify(S))}catch(e){}}
function save(){S.updatedAt=Date.now();saveLocal();clearTimeout(remT);remT=setTimeout(()=>scheduleReminders(false),2500)}

/* ---------- Susunan sabaq ---------- */
let orderCache={key:'',list:[]};
function sabaqOrder(){
  const st=S.set,key=st.sabaqMode+st.sabaqDir+st.start;if(orderCache.key===key)return orderCache.list;
  const out=[],seen=new Set(),push=p=>{if(!seen.has(p)){seen.add(p);out.push(p)}};
  const seq=(from,max,dir)=>{const r=[];if(dir==='undur'){for(let x=from;x>=1;x--)r.push(x);for(let x=max;x>from;x--)r.push(x)}else{for(let x=from;x<=max;x++)r.push(x);for(let x=1;x<from;x++)r.push(x)}return r};
  if(st.sabaqMode==='surah')seq(Math.min(114,Math.max(1,st.start)),114,st.sabaqDir).forEach(s=>{const [a,b]=surahPages(s);for(let p=a;p<=b;p++)push(p)});
  else if(st.sabaqMode==='juz')seq(Math.min(30,Math.max(1,st.start)),30,st.sabaqDir).forEach(j=>{const [a,b]=juzPages(j);for(let p=a;p<=b;p++)push(p)});
  else seq(Math.min(604,Math.max(1,st.start)),604,st.sabaqDir).forEach(push);
  orderCache={key,list:out};return out}
function nextSabaqPage(){const taken=new Set(S.sabaq),ord=sabaqOrder();
  for(const want of (S.set.order==='baru'?[3,0,1]:[0,1,3]))for(const p of ord)if(lv(p)===want&&!taken.has(p))return p;return null}
function fillSabaq(){S.sabaq=S.sabaq.filter(p=>lv(p)!==2);while(S.sabaq.length<S.set.sabaqN){const p=nextSabaqPage();if(!p)break;S.sabaq.push(p)}}

/* ---------- Pelan harian ---------- */
const sqPool=p=>{const v=lv(p);return(v===1||(S.set.order==='baru'&&v===0))&&!S.sabaq.includes(p)};
function makePlan(){
  const today=dkey();if(S.plan&&S.plan.date===today)return;
  let sq=null;const k=S.set.sqMaqra|0;
  if(k>0){const n=Math.ceil(240/k),c0=Math.floor(S.sqPtr/k)%n;
    for(let i=0;i<n;i++){const st=((c0+i)%n)*k,kk=Math.min(k,240-st),[a,b]=chunkPages(st,kk);if(range(a,b).some(sqPool)){sq={st,k:kk,a,b};break}}}
  const recent=S.recent.slice(0,S.set.recentN),rs=new Set(recent),sab=new Set(S.sabaq);
  const km=S.set.mzMaqra|0||4,nm=Math.ceil(240/km),m0=Math.floor(S.mzPtr/km)%nm;let mz=[],mzc=null;
  for(let i=0;i<nm;i++){const st=((m0+i)%nm)*km,kk=Math.min(km,240-st),[a,b]=chunkPages(st,kk);const pg=range(a,b).filter(p=>lv(p)===2&&!rs.has(p)&&!sab.has(p));if(pg.length){mz=pg;mzc={st,k:kk,a,b};break}}
  S.plan={date:today,sq,recent,mz,mzc,done:{sq:false,mz:false},prev:{sqPtr:S.sqPtr,mzPtr:S.mzPtr}}}
function sqPages(){const P=S.plan,out=[...P.recent];if(P.sq)for(let p=P.sq.a;p<=P.sq.b;p++)if(!out.includes(p))out.push(p);return out}
function ensure(){fillSabaq();makePlan()}
function logAdd(field,n=1){const k=dkey();const L=S.log[k]||(S.log[k]={p:0,t:0});L[field]=(L[field]||0)+n}
function streak(){ // hari rehat: satu hari terlepas setiap 7 hari tidak memutuskan siraman
  const did=k=>S.log[k]&&S.log[k].p>0;let k=dkey(),n=0,lastRest=-99,i=0;if(!did(k))k=addDays(k,-1);
  for(;i<2000;i++){if(did(k)){n++}else if(S.set.rest&&n>0&&i-lastRest>=7&&did(addDays(k,-1))){lastRest=i}else break;k=addDays(k,-1)}return n}

/* ---------- Tasmik, lancar, selesai ---------- */
function tasmik(p,ok){
  if(ok){const n=(S.tas[p]||0)+1;
    if(n>=S.set.need){startQuiz({kind:'sabaq',pages:[p],n:5,
      onPass:()=>{logAdd('p');logAdd('t');graduate(p)},
      onFail:()=>{S.tas[p]=0;logAdd('p');save();render();toast('Hampir! Ulang halaman ini dan tasmik semula.')}});return}
    S.tas[p]=n;logAdd('p');logAdd('t');toast('Tasmik lancar '+n+' daripada '+S.set.need)}
  else{S.tas[p]=0;logAdd('p');toast('Kiraan bermula semula. Tandakan ayat yang tersalah dalam mushaf.')}
  save();render()}
function askGraduate(p){startQuiz({kind:'sabaq',pages:[p],n:5,onPass:()=>graduate(p,true),onFail:()=>{S.tas[p]=0;save();render();toast('Hampir! Ulang halaman ini dan cuba lagi.')}})}
function graduate(p,manual){
  setLv(p,2);delete S.tas[p];S.sabaq=S.sabaq.filter(x=>x!==p);S.recent=[p,...S.recent.filter(x=>x!==p)].slice(0,20);
  S.grads.push({p,d:dkey()});if(manual)logAdd('p');
  const t=checkTree(p);fillSabaq();save();render();petals();
  toast(t?'Masya-Allah! '+t+' lancar sepenuhnya. Sebatang pokok berbuah tumbuh di taman.':'Alhamdulillah! '+HL(p)+' lancar. Sekuntum bunga mekar di taman.')}
function checkTree(p){
  const units=S.set.sabaqMode==='surah'?surahsOnPage(p).map(s=>['surah',s,surahPages(s)]):[['juz',PJ[p],juzPages(PJ[p])]];
  let made=null;for(const [t,n,[a,b]] of units){if(S.trees.some(x=>x.t===t&&x.n===n))continue;
    if(range(a,b).every(q=>lv(q)===2)){S.trees.push({t,n,d:dkey()});made=t==='surah'?'Surah '+SURAH[n-1]:'Juz '+n}}return made}
function removeSabaq(p){S.sabaq=S.sabaq.filter(x=>x!==p);delete S.tas[p];if(S.set.sabaqN>S.sabaq.length)S.set.sabaqN=Math.max(1,S.sabaq.length);fillSabaq();save();render();toast(HL(p)+' dibuang daripada sabaq')}
function markDone(which){
  const P=S.plan,L=S.log[dkey()]||(S.log[dkey()]={p:0,t:0});
  if(which==='sq'){P.done.sq=true;if(P.sq)S.sqPtr=(P.sq.st+P.sq.k)%240;L.p+=sqPages().length}
  else{P.done.mz=true;if(P.mzc)S.mzPtr=(P.mzc.st+P.mzc.k)%240;L.p+=P.mz.length}
  save();render();petals()}
function downgrade(pages){const out=[];for(const p of new Set(pages)){const v=lv(p);if(v>0&&v<3){setLv(p,v-1);out.push(p)}}return out}
function toggleDone(which){
  const P=S.plan;if(!P)return;const L=S.log[dkey()]||(S.log[dkey()]={p:0,t:0});
  if(P.done[which]){
    if(which==='sq'){P.done.sq=false;S.sqPtr=P.prev.sqPtr;L.p=Math.max(0,L.p-sqPages().length)}
    else{P.done.mz=false;S.mzPtr=P.prev.mzPtr;L.p=Math.max(0,L.p-P.mz.length)}
    save();render();return}
  const pages=which==='sq'?sqPages():P.mz;
  startQuiz({kind:which==='sq'?'sabqi':'manzil',pages,n:which==='sq'?8:10,
    onPass:()=>markDone(which),
    onFail:(wrong)=>{const d=downgrade(wrong.map(i=>VP[i]));save();render();toast(d.length?'Hampir! '+groupRanges(d).map(rangeText).join(', ')+' perlu lebih ulangan. Ulang dan cuba kuiz lagi.':'Hampir! Ulang sedikit lagi dan cuba kuiz semula.')}})}

/* ---------- Tanda ayat ---------- */
const openMarks=()=>S.marks.filter(m=>!m.r);
const marksOnPage=p=>openMarks().filter(m=>m.p===p);
function addMark(i,t,note,src){S.marks.unshift({id:Date.now().toString(36)+Math.random().toString(36).slice(2,6),i,s:VS[i],a:VA[i],p:VP[i],t,n:note||'',src:src||'',d:dkey(),r:false});save()}
function resolveMark(id,val=true){const m=S.marks.find(x=>x.id===id);if(m){m.r=val;m.rd=dkey();save();render()}}
function deleteMark(id){S.marks=S.marks.filter(x=>x.id!==id);save();render()}
/* ---------- Taman Murajaah ---------- */
function unitProgress(){ // unit sabaq semasa (juz atau surah) dan peratus lancar
  const p=S.sabaq[0];if(!p)return null;
  const [t,n,[a,b]]=S.set.sabaqMode==='surah'?['surah',VS[pageFirst(p)],surahPages(VS[pageFirst(p)])]:['juz',PJ[p],juzPages(PJ[p])];
  let ok=0;for(let q=a;q<=b;q++)if(lv(q)===2)ok++;return{label:t==='surah'?'Surah '+SURAH[n-1]:'Juz '+n,pct:ok/(b-a+1)}}
function rnd(seed){let x=Math.sin(seed*999)*10000;return x-Math.floor(x)}
function gardenSVG(){
  const W=400,H=170,trees=S.trees,fl=S.grads.length,u=unitProgress(),night=skyNow().k==='malam';
  let s=`<svg viewBox="0 0 ${W} ${H}" role="img" aria-label="Taman: ${trees.length} pokok, ${fl} bunga">`;
  s+=`<defs><linearGradient id="gsky" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="${night?'#2c3a63':'#e4f3fd'}"/><stop offset="1" stop-color="${night?'#46507a':'#fbf3e8'}"/></linearGradient></defs>`;
  s+=`<rect width="${W}" height="${H}" fill="url(#gsky)"/>`;
  s+=`<path d="M0 118c60-22 120-22 190-8s140 12 210-6v66H0z" fill="${night?'#3f6b55':'#c5e6c9'}"/><path d="M0 132c70-14 140-10 210 0s130 8 190-4v42H0z" fill="${night?'#355d49':'#a9d8b2'}"/>`;
  // pokok berbuah (juz/surah lancar)
  const show=trees.slice(-7);
  show.forEach((t,i)=>{const x=34+i*46,y=124,h=38+((i*7)%10),fruit=t.t==='surah'?'#f4a259':'#e8687e';
    s+=`<rect x="${x-3}" y="${y-h}" width="6" height="${h}" rx="3" fill="#9a6b45"/><circle cx="${x}" cy="${y-h-6}" r="20" fill="#6dbb84"/><circle cx="${x-11}" cy="${y-h+2}" r="13" fill="#7fc795"/><circle cx="${x+12}" cy="${y-h+1}" r="12" fill="#5fae78"/>`;
    for(let f=0;f<5;f++){const fx=x-12+rnd(i*10+f)*24,fy=y-h-14+rnd(i*20+f)*22;s+=`<circle cx="${fx.toFixed(1)}" cy="${fy.toFixed(1)}" r="3.4" fill="${fruit}"/>`}
    s+=`<text x="${x}" y="${y+13}" text-anchor="middle" font-size="9.5" font-family="Atkinson,sans-serif" fill="${night?'#d7ecdd':'#3c6a4b'}">${t.t==='surah'?'S'+t.n:'J'+t.n}</text>`});
  if(trees.length>7)s+=`<text x="12" y="20" font-size="11" fill="${night?'#fff':'#3c6a4b'}" font-family="Atkinson,sans-serif">+${trees.length-7} pokok lagi</text>`;
  // anak pokok untuk unit semasa
  if(u){const x=W-44,y=128,h=10+Math.round(u.pct*46);
    s+=`<path d="M${x} ${y}V${y-h}" stroke="#4f9a68" stroke-width="4" stroke-linecap="round"/><path d="M${x} ${y-h+6}c-4-8-12-10-18-8 3 8 10 11 18 8z" fill="#7fc795"/><path d="M${x} ${y-h+2}c4-9 12-12 19-10-2 9-11 12-19 10z" fill="#8fd1a3"/>`;
    s+=`<text x="${x}" y="${y+14}" text-anchor="middle" font-size="9.5" font-family="Atkinson,sans-serif" fill="${night?'#d7ecdd':'#3c6a4b'}">${Math.round(u.pct*100)}%</text>`}
  // bunga (halaman yang lancar melalui sabaq)
  const cols=['#f6a6bd','#ffd36e','#b9a6ee','#ffb38a','#9ed6f6'];
  for(let k=0;k<Math.min(fl,26);k++){const fx=14+rnd(k+1)*(W-80),fy=140+rnd(k+50)*24,c=cols[k%5];
    s+=`<g transform="translate(${fx.toFixed(1)} ${fy.toFixed(1)})"><path d="M0 0v9" stroke="#5fa577" stroke-width="1.5"/>${[0,72,144,216,288].map(a=>`<ellipse rx="2.6" ry="4.4" fill="${c}" transform="rotate(${a}) translate(0 -3.6)"/>`).join('')}<circle r="2" fill="#fff5c2"/></g>`}
  return s+'</svg>'}
function gardenCard(){
  const u=unitProgress(),w=streak(),fl=S.grads.length,tr=S.trees.length;
  return`<section class="garden">${gardenSVG()}<div class="cap"><b>Taman Murajaah</b><span>${ico('drop',14)} Disiram ${w} hari berturut</span><span>${tr} pokok, ${fl} bunga</span>${u?`<span>${esc(u.label)}: ${Math.round(u.pct*100)}% lancar</span>`:''}</div></section>`}

/* ---------- Hari Ini ---------- */
const INFO={
  sabaq:['Sabaq','Halaman yang sedang diperkuat atau dihafal. Tasmik '+'beberapa kali lancar berturut-turut, kemudian jawab kuiz ringkas. Lulus 70% baru halaman itu dikira lancar, masuk manzil, dan sekuntum bunga mekar di taman.'],
  sabqi:['Sabqi','Ulangan halaman yang baru lancar, ditambah bahagian daripada juz sederhana mengikut sempadan maqra\'. Tekan selesai dan jawab kuiz. Kalau belum lulus, halaman yang tersalah akan diulang lebih kerap.'],
  manzil:['Manzil','Pusingan halaman yang dah lancar, ikut sempadan hizb atau juz sebenar. Kalau terlepas sehari, esok sambung dari tempat yang sama. Tekan selesai dan jawab kuiz.']};
function vHome(){
  const P=S.plan,today=dkey(),yest=addDays(today,-1);
  const cnt=[0,0,0,0];for(let p=1;p<=604;p++)cnt[lv(p)]++;
  let h='';
  if(!S.set.name)h+=`<section class="panel namecard"><div class="field"><label for="nmIn">Siapa nama anda?</label><input type="text" id="nmIn" maxlength="24" placeholder="Contoh: Ainul" autocomplete="given-name"></div><button class="btn pri" data-savename="1">Simpan</button></section>`;
  h+=gardenCard();
  // Peringatan ringkas
  const recentMarks=openMarks().filter(m=>m.d===today||m.d===yest);
  const todayPages=new Set([...S.sabaq,...sqPages(),...P.mz]);
  const quiz=recentMarks.filter(m=>m.src&&m.src.startsWith('kuiz'));
  const manual=openMarks().filter(m=>!(m.src&&m.src.startsWith('kuiz'))&&(todayPages.has(m.p)||m.d===today||m.d===yest));
  if(quiz.length||manual.length){
    const byKind={};quiz.forEach(m=>{byKind[m.src]=(byKind[m.src]||0)+1});
    h+=`<section class="alert"><h3>Sebelum mula, ingat ini</h3>`;
    Object.entries(byKind).forEach(([k,n])=>{h+=`<div class="it"><span>${k.replace('kuiz','Kuiz')}: ${n} ayat perlu diulang</span><button class="btn sm" data-quizmarks="${esc(k)}">Lihat</button></div>`});
    if(manual.length)h+=`<div class="it"><span>${manual.length} ayat yang anda tandakan ada dalam bacaan hari ini</span><button class="btn sm" data-manualmarks="1">Lihat</button></div>`;
    h+=`</section>`}
  // Sabaq
  h+=`<section class="task sb"><div class="task-h"><h3>Sabaq</h3><button class="info" data-info="sabaq" aria-label="Apa itu sabaq">i</button></div>`;
  if(!S.sabaq.length)h+=`<p class="muted" style="margin:0">Semua halaman dalam susunan sabaq anda dah lancar.</p>`;
  S.sabaq.forEach((p,k)=>{const n=S.tas[p]||0,mk=marksOnPage(p).length;
    h+=`<div class="reading"><button class="t" data-open="${p}" style="border:0;background:none;padding:0;text-align:left"><span class="big">${HL(p)}</span><span class="sub">${esc(pageLabel(p))}, Juz ${PJ[p]}${mk?`, ${mk} ayat bertanda`:''}</span></button>${k>=1?`<button class="x" data-rmsabaq="${p}" aria-label="Buang ${HL(p)} daripada sabaq">${ico('x',16)}</button>`:''}</div>
    <div class="row"><span class="dots" aria-label="${n} daripada ${S.set.need} tasmik">${range(1,S.set.need).map(i=>`<i class="${i<=n?'on':''}"></i>`).join('')}</span><span class="small muted">${n} daripada ${S.set.need} tasmik lancar</span></div>
    <div class="row"><button class="btn ok" data-tas="${p}" data-ok="1">${ico('check',18)}Lancar</button><button class="btn" data-tas="${p}" data-ok="0">${ico('x',18)}Ada salah</button><button class="btn soft" data-ai="${p}">${ico('mic',18)}Tasmik AI</button><button class="btn ghost sm" data-grad="${p}">Tanda lancar terus</button></div>`});
  h+=`<button class="btn ghost sm" id="addSabaq" style="align-self:flex-start">${ico('plus',16)}Tambah halaman sabaq</button></section>`;
  // Sabqi
  const sq=sqPages();
  h+=`<section class="task sq"><div class="task-h"><h3>Sabqi</h3><span class="count">${sq.length} halaman</span><button class="info" data-info="sabqi" aria-label="Apa itu sabqi">i</button></div>`;
  if(sq.length){h+=`<div class="ranges">${groupRanges(sq).map(r=>`<button data-open="${r[0]}">${rangeText(r)}${P.sq&&r[0]>=P.sq.a&&r[1]<=P.sq.b?`<small>${chunkLabel(P.sq.st,P.sq.k)}</small>`:'<small>Baru lancar</small>'}</button>`).join('')}</div>
    <button class="done-btn ${P.done.sq?'done':''}" data-done="sq"><span class="box">${P.done.sq?ico('check',15):''}</span>${P.done.sq?'Sabqi selesai':'Selesai, jawab kuiz'}</button>`}
  else h+=`<p class="muted" style="margin:0">Tiada sabqi hari ini.</p>`;
  h+=`</section>`;
  // Manzil
  h+=`<section class="task mz"><div class="task-h"><h3>Manzil</h3><span class="count">${P.mz.length} halaman</span><button class="info" data-info="manzil" aria-label="Apa itu manzil">i</button></div>`;
  if(P.mz.length){h+=`<div class="ranges">${groupRanges(P.mz).map(r=>`<button data-open="${r[0]}">${rangeText(r)}<small>${P.mzc?chunkLabel(P.mzc.st,P.mzc.k):''}</small></button>`).join('')}</div>
    <button class="done-btn ${P.done.mz?'done':''}" data-done="mz"><span class="box">${P.done.mz?ico('check',15):''}</span>${P.done.mz?'Manzil selesai':'Selesai, jawab kuiz'}</button>`}
  else h+=`<p class="muted" style="margin:0">Belum ada halaman lancar untuk manzil.</p>`;
  h+=`</section>`;
  // Rekod
  const days=range(-6,0).map(n=>addDays(today,n)),vals=days.map(k=>(S.log[k]&&S.log[k].p)||0),mx=Math.max(5,...vals),wk=vals.reduce((a,b)=>a+b,0);
  h+=`<h2 class="sec">Rekod</h2><div class="stats"><div class="stat"><b>${streak()}</b><span>hari disiram</span></div><div class="stat"><b>${wk}</b><span>halaman minggu ini</span></div><div class="stat"><b>${openMarks().length}</b><span>ayat bertanda</span></div></div>
  <section class="panel"><div class="row" style="justify-content:space-between"><b>7 hari lepas</b><span class="small muted">halaman diulang</span></div><div class="week">${days.map((k,i)=>`<div><em>${vals[i]||''}</em><i class="${vals[i]?'':'zero'}" style="height:${Math.max(4,vals[i]/mx*62)}px"></i><span>${HARI[new Date(k+'T00:00').getDay()].slice(0,3)}</span></div>`).join('')}</div></section>
  <section class="panel"><div class="row" style="justify-content:space-between"><b>Tahap 604 halaman</b><button class="btn sm ghost" data-tab-go="peta">Lihat peta</button></div><div class="lvbar">${[2,1,0,3].map(v=>`<i class="l${v}" style="width:${cnt[v]/6.04}%"></i>`).join('')}</div><div class="legend"><span><b class="l2"></b>Lancar ${cnt[2]}</span><span><b class="l1"></b>Sederhana ${cnt[1]}</span><span><b class="l0"></b>Lemah ${cnt[0]}</span>${cnt[3]?`<span><b class="l3"></b>Belum hafal ${cnt[3]}</span>`:''}</div></section>`;
  return h}
function marksListSheet(list,title){
  openSheet(`<h3>${esc(title)}</h3><div>${list.map(m=>`<div class="mk"><div class="h"><span class="pill ${m.t}">${m.t==='lupa'?'Lupa':'Tertukar'}</span><b>${esc(SURAH[m.s-1])} ${m.s}:${m.a}</b><span>${HL(m.p)}</span></div><div class="ar">${esc(T[m.i])}</div><div class="row"><button class="btn sm" data-open="${m.p}" data-ay="${m.i}">Buka</button><button class="btn sm ok" data-res="${m.id}" data-close="1">Dah baik</button></div></div>`).join('')}</div><button class="btn ghost" data-close="1">Tutup</button>`)}

/* ---------- Peta kelancaran ---------- */
let mapMode='juz',markFilter='open';
const LVN=['Lemah','Sederhana','Lancar','Belum hafal'];
const lvColor=v=>['var(--bad)','var(--mid)','var(--ok)','var(--none)'][v];
function cellsFor(a,b){const mp=new Set(openMarks().map(m=>m.p));return range(a,b).map(p=>`<button style="background:${lvColor(lv(p))}" class="${mp.has(p)?'has-m':''}" data-open="${p}" aria-label="${HL(p)}, ${LVN[lv(p)]}"></button>`).join('')}
function avgLv(a,b){let s=0,n=0;for(let p=a;p<=b;p++){const v=lv(p);if(v<3){s+=v;n++}}if(!n)return 3;const x=s/n;return x<0.67?0:x<1.5?1:2}
function vPeta(){
  let h=`<div class="seg" role="tablist">${[['juz','Juz'],['surah','Surah'],['hizb','Hizb']].map(([k,l])=>`<button class="${mapMode===k?'on':''}" data-map="${k}">${l}</button>`).join('')}</div>
  <div class="legend"><span><b class="l2"></b>Lancar</span><span><b class="l1"></b>Sederhana</span><span><b class="l0"></b>Lemah</span><span><b class="l3"></b>Belum hafal</span></div><section class="panel">`;
  if(mapMode==='juz'){for(let j=1;j<=30;j++){const [a,b]=juzPages(j);h+=`<div class="maprow"><button class="lbl" data-open="${a}"><b>Juz ${j}</b><span>Halaman ${a}–${b}</span></button><div class="cells">${cellsFor(a,b)}</div></div>`}}
  else if(mapMode==='surah'){for(let s=1;s<=114;s++){const [a,b]=surahPages(s);h+=`<div class="maprow"><button class="lbl" data-open="${a}"><b>${s}. ${esc(SURAH[s-1])}</b><span>Halaman ${a}${b>a?'–'+b:''}</span></button><div class="cells">${cellsFor(a,b)}</div></div>`}}
  else{for(let hz=1;hz<=60;hz++){const m0=(hz-1)*4+1,[a]=maqraPages(m0),[,b]=maqraPages(m0+3);h+=`<div class="maprow"><button class="lbl" data-open="${a}"><b>Hizb ${hz}</b><span>Juz ${Math.ceil(hz/2)}, halaman ${a}–${b}</span></button><div class="quarters">${[0,1,2,3].map(q=>{const [x,y]=maqraPages(m0+q);const v=avgLv(x,y);return`<button style="background:${lvColor(v)}" data-open="${x}" aria-label="Maqra' ${m0+q}, ${LVN[v]}">${['Awal','¼','½','¾'][q]}</button>`}).join('')}</div></div>`}}
  return h+`</section>`}

/* ---------- Tanda ---------- */
function vTanda(){
  let list=S.marks;
  if(markFilter==='open')list=list.filter(m=>!m.r);else if(markFilter==='lupa'||markFilter==='tukar')list=list.filter(m=>!m.r&&m.t===markFilter);else if(markFilter==='kuiz')list=list.filter(m=>!m.r&&m.src&&m.src.startsWith('kuiz'));else if(markFilter==='res')list=list.filter(m=>m.r);
  list=[...list].sort((x,y)=>markFilter==='open'?x.i-y.i:0);
  let h=`<div class="filters">${[['open','Belum selesai'],['lupa','Lupa'],['tukar','Tertukar'],['kuiz','Dari kuiz'],['res','Dah baik']].map(([k,l])=>`<button class="${markFilter===k?'on':''}" data-mf="${k}">${l}</button>`).join('')}</div><section class="panel">`;
  if(!list.length)h+=`<div class="empty">${markFilter==='res'?'Belum ada tanda yang dibaiki.':'Tiada ayat bertanda. Tekan mana-mana ayat dalam Mushaf untuk menandakannya.'}</div>`;
  list.forEach(m=>{h+=`<div class="mk ${m.r?'res':''}"><div class="h"><span class="pill ${m.t}">${m.t==='lupa'?'Lupa':'Tertukar'}</span><b>${esc(SURAH[m.s-1])} ${m.s}:${m.a}</b><span>${HL(m.p)}, ${fmtShort(m.d)}${m.src?', '+esc(m.src):''}</span></div><div class="ar">${esc(T[m.i])}</div>${m.n?`<div class="note">${esc(m.n)}</div>`:''}<div class="row"><button class="btn sm" data-open="${m.p}" data-ay="${m.i}">Buka</button>${m.r?`<button class="btn sm ghost" data-unres="${m.id}">Tanda semula</button>`:`<button class="btn sm ok" data-res="${m.id}">Dah baik</button>`}<button class="btn sm ghost" data-del="${m.id}">Padam</button></div></div>`});
  return h+`</section>`}
/* ---------- Mushaf ---------- */
let curPage=S.lastPage||1,selAyah=null,revealed=new Set(),lastPg=0,fullscreen=false;
const heard={}; // `${i}` -> Set kedudukan perkataan yang didengar AI
const aiIssue=new Set(); // indeks ayat yang AI tandakan
const fontP={};
function loadPageFont(p){if(!LAYOUT||p<1||p>604)return Promise.resolve();if(fontP[p])return fontP[p];
  const f=new FontFace('qpc'+p,`url(qpc1/p${pad3(p)}.woff2)`);fontP[p]=f.load().then(x=>{document.fonts.add(x)}).catch(()=>{delete fontP[p]});return fontP[p]}
function qpcLines(p,mmap){
  const mode=S.set.view||'full';
  return LAYOUT[p-1].map((ln,k)=>{
    if(ln[0]===0)return`<div class="ln hdr"><span>${esc(D.sa[ln[1]-1])}</span></div>`;
    if(ln[0]===1)return`<div class="ln bsm">بِسۡمِ ٱللَّهِ ٱلرَّحۡمَٰنِ ٱلرَّحِيمِ</div>`;
    const open=mode==='full'||revealed.has(k);
    return`<div class="ln${open?'':' hl'}" data-ln="${k}">`+ln[1].map(([i,w,g])=>{const c=['w'],hs=heard[i],isH=hs&&hs.has(w);
      if(!open&&!(mode==='awal'&&w===1)&&!isH)c.push('h');
      else{if(mmap[i])c.push('m-'+mmap[i]);if(selAyah===i)c.push('sel');if(AP.playing&&AP.cur===i)c.push('play');if(isH)c.push('heard');if(aiIssue.has(i))c.push('issue')}
      return`<span class="${c.join(' ')}" data-i="${i}" data-w="${w}">${esc(g)}</span>`}).join('')+'</div>'}).join('')}
function fitPage(){
  const el=document.getElementById('qlines');if(!el)return;const W=el.clientWidth;if(!W)return;
  el.style.fontSize='40px';const lines=[...el.querySelectorAll('.ln')];
  lines.forEach(l=>l.classList.add('measure'));
  let mx=0;const wd=lines.map(l=>{const w=l.classList.contains('hdr')||l.classList.contains('bsm')?0:l.offsetWidth;mx=Math.max(mx,w);return w});
  lines.forEach(l=>l.classList.remove('measure'));
  let fs=Math.min(fullscreen?60:46,40*W/mx*(curPage<=2?0.86:0.985));
  if(fullscreen){const avail=window.innerHeight-90;fs=Math.min(fs,avail/15/1.9)}
  el.style.fontSize=fs+'px';
  const center=curPage<=2;
  lines.forEach((l,k)=>{if(!wd[k])return;l.classList.toggle('center',center||wd[k]*fs/40<W*0.8)});
  el.classList.add('ready')}
function afterMushaf(){if(!LAYOUT||tab!=='mushaf')return;const p=curPage;
  loadPageFont(p).then(()=>{if(p===curPage&&tab==='mushaf')fitPage()});
  setTimeout(()=>{loadPageFont(p+1);loadPageFont(p-1)},400)}
function gotoPage(p){curPage=Math.min(604,Math.max(1,p));selAyah=null;S.lastPage=curPage;saveLocal();if(tab!=='mushaf')tab='mushaf';render();window.scrollTo(0,0)}
const VIEWN={full:'Penuh',awal:'Awal ayat',sorok:'Sorok'};
function vMushaf(){
  const p=curPage,marks=marksOnPage(p),mmap={};marks.forEach(m=>{mmap[m.i]=mmap[m.i]||m.t});
  const f=pageFirst(p),e=pageEnd(p),inSab=S.sabaq.includes(p),mode=S.set.view||'full',P=S.plan;
  let body;
  if(LAYOUT)body=`<div class="qlines" id="qlines" style="font-family:qpc${p},var(--f-ar)">${qpcLines(p,mmap)}</div>`;
  else{let txt='';for(let i=f;i<e;i++){
      if(VA[i]===1)txt+=`<div style="text-align:center;font-size:.8em">${esc(D.sa[VS[i]-1])}</div>${VS[i]!==1&&VS[i]!==9?'<div style="text-align:center">بِسۡمِ ٱللَّهِ ٱلرَّحۡمَٰنِ ٱلرَّحِيمِ</div>':''}`;
      txt+=`<span class="w ${mmap[i]?'m-'+mmap[i]:''}" data-i="${i}" data-w="1">${esc(T[i])} ${AR(VA[i])}</span> `}
    body=`<div class="qtext">${txt}</div>`}
  const jumps=[];if(S.sabaq[0])jumps.push(['sb','Sabaq',S.sabaq[0]]);const sq=sqPages();if(sq.length)jumps.push(['sq','Sabqi',Math.min(...sq)]);if(P.mz.length)jumps.push(['mz','Manzil',P.mz[0]]);
  let h=`<div class="mtool"><button class="picker-btn" data-picker="1">${ico('search')}<span class="t"><b>${esc(pageLabel(p))}</b><span>Juz ${PJ[p]}, ${HL(p)}</span></span></button>
    <button class="ibtn" data-player="1" aria-label="Dengar bacaan">${ico('head')}</button><button class="ibtn" data-ai="${p}" aria-label="Tasmik dengan AI">${ico('mic')}</button><button class="ibtn" data-fs="1" aria-label="Skrin penuh">${ico('expand')}</button><button class="ibtn" data-pagemenu="1" aria-label="Pilihan halaman">${ico('more')}</button></div>
  <div class="jumps">${jumps.map(([c,l,pg])=>`<button class="chip ${c}" data-goto="${pg}">${l} ${pg}</button>`).join('')}${LAYOUT?`<button class="chip mode" data-cycleview="1">${ico('eye',16)}${VIEWN[mode]}</button>`:''}</div>`;
  if(LAYOUT&&mode!=='full')h+=`<div class="banner row" style="justify-content:space-between"><span>Tekan baris untuk membukanya satu per satu.</span><button class="btn sm" data-revealall="1">Papar semua</button></div>`;
  if(marks.length)h+=`<div class="banner">${marks.length} ayat bertanda di halaman ini.</div>`;
  h+=`<article class="mushaf" id="mushaf"><div class="mhead"><span>${esc(SURAH[VS[f]-1])}</span><span>Juz ${PJ[p]}</span></div>${body}<div class="mfoot">${AR(p)}</div></article>`;
  if(fullscreen)h+=`<button class="fs-exit" data-fs="0" aria-label="Keluar skrin penuh">${ico('shrink')}</button>`;
  h+=`<p class="hint small muted" style="margin:0;text-align:center">Tekan ayat untuk terjemahan, tanda atau dengar. Leret ke kiri atau kanan untuk tukar halaman.</p>`;
  if(inSab){const n=S.tas[p]||0;h+=`<section class="task sb sabaqbox"><div class="task-h"><h3>Sabaq</h3><span class="count">${n} daripada ${S.set.need} tasmik</span></div><div class="row"><button class="btn ok" data-tas="${p}" data-ok="1">${ico('check',18)}Lancar</button><button class="btn" data-tas="${p}" data-ok="0">${ico('x',18)}Ada salah</button><button class="btn ghost sm" data-grad="${p}">Tanda lancar terus</button></div></section>`}
  h+=`<div class="pager"><button class="pg" data-pg="${p+1}" ${p>=604?'disabled':''} aria-label="Halaman seterusnya">${ico('left',18)} ${Math.min(604,p+1)}</button><button class="pg" data-picker="halaman">${p}</button><button class="pg" data-pg="${p-1}" ${p<=1?'disabled':''} style="justify-self:end" aria-label="Halaman sebelum">${Math.max(1,p-1)} ${ico('right',18)}</button></div>`;
  return h}
function setFullscreen(on){fullscreen=on;document.body.classList.toggle('fs',on);
  try{if(on&&document.documentElement.requestFullscreen&&!NATIVE)document.documentElement.requestFullscreen().catch(()=>{});else if(!on&&document.fullscreenElement)document.exitFullscreen().catch(()=>{})}catch(e){}
  render()}

/* Pilihan halaman: tahap, mod */
function pageMenu(){const p=curPage,v=lv(p),mode=S.set.view||'full';
  openSheet(`<h3>${HL(p)}</h3>
  <div class="field"><span class="lbl">Tahap halaman ini</span><div class="seg">${[0,1,2,3].map(k=>`<button class="${v===k?'on':''}" data-lv="${k}">${LVN[k]}</button>`).join('')}</div></div>
  <div class="field"><span class="lbl">Paparan mushaf</span><div class="seg">${Object.entries(VIEWN).map(([k,l])=>`<button class="${mode===k?'on':''}" data-view="${k}">${l}</button>`).join('')}</div><small>Awal ayat: hanya perkataan pertama setiap ayat ditunjukkan. Sorok: semua disorok untuk uji hafazan.</small></div>
  ${S.sabaq.includes(p)?'':`<button class="btn" data-addsabaqpage="${p}">${ico('plus',18)}Jadikan halaman ini sabaq</button>`}
  <button class="btn ghost" data-close="1">Tutup</button>`)}

/* Pemilih surah / juz / halaman */
let pickTab='surah';
function pickerSheet(tabSel){pickTab=tabSel||pickTab;
  const p=curPage,curS=VS[pageFirst(p)];
  let body='';
  if(pickTab==='surah')body=`<input type="search" id="pkQ" placeholder="Cari nama atau nombor surah" aria-label="Cari surah"><div class="picklist" id="pkList">${SURAH.map((n,k)=>`<button class="${k+1===curS?'cur':''}" data-goto="${surahPages(k+1)[0]}" data-name="${esc((k+1)+' '+n.toLowerCase())}"><span class="n">${k+1}</span><span class="t"><b>${esc(n)}</b><span>${D.sc[k]} ayat, halaman ${surahPages(k+1)[0]}</span></span><span class="ar">${esc(D.sa[k])}</span></button>`).join('')}</div>`;
  else if(pickTab==='juz')body=`<div class="picklist">${range(1,30).map(j=>{const [a,b]=juzPages(j);return`<button class="${PJ[p]===j?'cur':''}" data-goto="${a}"><span class="n">${j}</span><span class="t"><b>Juz ${j}</b><span>Halaman ${a}–${b}, bermula ${esc(SURAH[VS[D.jz[j-1]]-1])} ${VA[D.jz[j-1]]}</span></span></button>`}).join('')}</div>`;
  else body=`<div class="field"><label for="pkN">Nombor halaman (1–604)</label><input type="number" id="pkN" min="1" max="604" inputmode="numeric" value="${p}"></div>
    <input type="range" id="pkR" min="1" max="604" value="${p}" aria-label="Leret untuk pilih halaman"><div class="small muted" id="pkInfo">${esc(pageLabel(p))}, Juz ${PJ[p]}</div>
    <button class="btn pri" id="pkGo">Buka halaman</button>`;
  openSheet(`<h3>Cari dalam mushaf</h3><div class="seg">${[['surah','Surah'],['juz','Juz'],['halaman','Halaman']].map(([k,l])=>`<button class="${pickTab===k?'on':''}" data-pktab="${k}">${l}</button>`).join('')}</div>${body}<button class="btn ghost" data-close="1">Tutup</button>`,sh=>{
    const q=sh.querySelector('#pkQ');if(q)q.oninput=()=>{const v=q.value.trim().toLowerCase();sh.querySelectorAll('#pkList button').forEach(b=>b.hidden=!!v&&!b.dataset.name.includes(v))};
    const c=sh.querySelector('.picklist .cur');if(c)c.scrollIntoView({block:'center'});
    const n=sh.querySelector('#pkN'),r=sh.querySelector('#pkR');
    if(n){const sync=v=>{v=Math.min(604,Math.max(1,v|0||1));sh.querySelector('#pkInfo').textContent=pageLabel(v)+', Juz '+PJ[v];return v};
      n.oninput=()=>{r.value=sync(+n.value)};r.oninput=()=>{n.value=sync(+r.value)};
      sh.querySelector('#pkGo').onclick=()=>{closeLayer();gotoPage(+n.value)};n.onkeydown=e=>{if(e.key==='Enter'){closeLayer();gotoPage(+n.value)}}}
  })}

/* Ayat: terjemahan, maksud perkataan, tanda, dengar */
const DATA={};
function loadJSON(name){if(DATA[name])return DATA[name];DATA[name]=fetch('data/'+name).then(r=>{if(!r.ok)throw 0;return r.json()}).catch(()=>{delete DATA[name];return null});return DATA[name]}
function ayahSheet(i){
  selAyah=i;render();
  const ms=S.marks.filter(m=>m.i===i),p=VP[i];
  openSheet(`<h3>${esc(SURAH[VS[i]-1])} ${vkey(i)}</h3><div class="small muted" style="margin-top:-8px">${HL(p)}, Juz ${PJ[p]}</div>
  ${(()=>{if(LAYOUT){const g=[];LAYOUT[p-1].forEach(ln=>{if(ln[0]===2)ln[1].forEach(([v,w,gl])=>{if(v===i)g.push(gl)})});if(g.length)return`<div class="ar-big" style="font-family:qpc${p},var(--f-ar);font-size:28px">${esc(g.join(' '))}</div>`}return`<div class="ar-big">${esc(T[i])} ${AR(VA[i])}</div>`})()}
  <div class="seg"><button class="on" data-trtab="ms">Terjemahan</button><button data-trtab="wbw">Maksud perkataan</button></div>
  <div id="trBox" class="trans">Memuatkan terjemahan…</div>
  ${ms.length?`<div>${ms.map(m=>`<div class="row" style="margin-bottom:6px"><span class="pill ${m.t}">${m.t==='lupa'?'Lupa':'Tertukar'}</span><span class="small muted">${fmtShort(m.d)}${m.r?', dah baik':''}</span>${m.n?`<span class="small">${esc(m.n)}</span>`:''}<span class="row" style="margin-left:auto">${m.r?'':`<button class="btn sm ok" data-res="${m.id}" data-close="1">Dah baik</button>`}<button class="btn sm ghost" data-del="${m.id}" data-close="1">Padam</button></span></div>`).join('')}</div>`:''}
  <div class="field"><label for="mkNote">Nota (pilihan)</label><textarea id="mkNote" placeholder="Contoh: tertukar dengan Al-A'raf 54"></textarea></div>
  <div class="grid2"><button class="btn" id="mkLupa" style="background:var(--bad-soft);border-color:transparent;color:var(--bad)">Tanda lupa</button><button class="btn" id="mkTukar" style="background:var(--swap-soft);border-color:transparent;color:var(--swap)">Tanda tertukar</button></div>
  <button class="btn soft" data-player-i="${i}">${ico('head',18)}Dengar dari ayat ini</button>
  <button class="btn ghost" data-close="1">Tutup</button>`,sh=>{
    const box=sh.querySelector('#trBox');
    const showMs=()=>loadJSON('tr_ms.json').then(t=>{box.className='trans';box.textContent=t?t[i]:'Terjemahan tidak dapat dimuatkan.'});
    const showW=()=>loadJSON('wbw_en.json').then(w=>{if(!w){box.textContent='Maksud perkataan tidak dapat dimuatkan.';return}
      const glyphs={};if(LAYOUT)LAYOUT[p-1].forEach(ln=>{if(ln[0]===2)ln[1].forEach(([v,wi,g])=>{if(v===i)glyphs[wi]=g})});
      box.className='wbw';box.innerHTML=w[i].map((e,k)=>`<div><span class="g" style="font-family:${glyphs[k+1]?'qpc'+p:'var(--f-ar)'}">${esc(glyphs[k+1]?glyphs[k+1].replace(/\s.*$/,''):T[i].split(' ')[k]||'')}</span><span class="e">${esc(e)}</span></div>`).join('')});
    showMs();
    sh.querySelectorAll('[data-trtab]').forEach(b=>b.onclick=()=>{sh.querySelectorAll('[data-trtab]').forEach(x=>x.classList.toggle('on',x===b));b.dataset.trtab==='ms'?showMs():showW()});
    sh.querySelector('#mkLupa').onclick=()=>{addMark(i,'lupa',sh.querySelector('#mkNote').value.trim());closeLayer();render();toast('Ditanda lupa: '+vkey(i))};
    sh.querySelector('#mkTukar').onclick=()=>{addMark(i,'tukar',sh.querySelector('#mkNote').value.trim());closeLayer();render();toast('Ditanda tertukar: '+vkey(i))};
  })}
/* ---------- Kuiz ---------- */
const QZ={};
const words=i=>T[i].split(' ').filter(Boolean);
const head=(i,n=5)=>{const w=words(i);return w.slice(0,n).join(' ')+(w.length>n?' …':'')};
const tail=(i,n=6)=>{const w=words(i);return(w.length>n?'… ':'')+w.slice(-n).join(' ')};
const shuffle=a=>{a=[...a];for(let i=a.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[a[i],a[j]]=[a[j],a[i]]}return a};
function nearVerses(p,r){const out=[];for(let q=Math.max(1,p-r);q<=Math.min(604,p+r);q++)for(let i=pageFirst(q);i<pageEnd(q);i++)out.push(i);return out}
function distract(correct,fn,p){const ct=fn(correct),first=words(correct)[0],seen=new Set([ct]),out=[];
  for(const r of [3,8,20]){const c=shuffle(nearVerses(p,r).filter(i=>i!==correct)).sort((a,b)=>(words(a)[0]===first?0:1)-(words(b)[0]===first?0:1));
    for(const i of c){const t=fn(i);if(!seen.has(t)){seen.add(t);out.push(t)}if(out.length>=3)return out}}return out}
function makeQuiz(pages,n){
  const verses=[];pages.forEach(p=>{for(let i=pageFirst(p);i<pageEnd(p);i++)verses.push(i)});
  const qs=[],used=new Set(),startDone=new Set(),pool=shuffle(verses);let k=0;
  while(qs.length<n&&k<pool.length*3){const i=pool[k%pool.length];k++;const p=VP[i],r=Math.random();
    if(r<0.18&&!startDone.has(p)){startDone.add(p);const c=pageFirst(p);qs.push({label:HL(p)+' dimulakan dengan ayat apa?',ar:'',ok:head(c),opts:distract(c,x=>head(x),p),target:c});continue}
    if(used.has(i))continue;
    if(r<0.36&&VA[i]>1){used.add(i);qs.push({label:'Apakah ayat sebelum ayat ini?',ar:head(i,7),num:VA[i],ok:tail(i-1),opts:distract(i-1,x=>tail(x),p),target:i-1});continue}
    if(i+1<N&&VS[i+1]===VS[i]){used.add(i);qs.push({label:'Apakah sambungan ayat ini?',ar:tail(i,7),num:VA[i],ok:head(i+1),opts:distract(i+1,x=>head(x),p),target:i+1})}}
  return qs.map(q=>({...q,choices:shuffle([{t:q.ok,ok:true},...q.opts.map(t=>({t,ok:false}))])}))}
const KINDN={sabaq:'Sabaq',sabqi:'Sabqi',manzil:'Manzil'};
function startQuiz(cfg){const qs=makeQuiz(cfg.pages,cfg.n);if(!qs.length){cfg.onPass();return}Object.assign(QZ,{cfg,qs,i:0,score:0,wrong:[],answered:false});renderQuiz()}
function renderQuiz(){
  const {qs,i,cfg}=QZ;
  if(i>=qs.length){const pct=Math.round(QZ.score/qs.length*100),pass=pct>=70;
    openSheet(`<div class="qz-res ${pass?'pass':'fail'}"><div class="qz-pct">${pct}%</div><h3>${pass?'Lulus. Masya-Allah!':'Hampir sampai'}</h3><p class="muted" style="margin:0">${QZ.score} betul daripada ${qs.length}. ${pass?'Bacaan ini dikira lancar.':'Perlukan 70% untuk lulus. Ulang sedikit lagi, kemudian cuba semula.'}</p></div>
      ${QZ.wrong.length?`<button class="btn soft" id="qzShow">Lihat ${QZ.wrong.length} ayat untuk diulang</button><div id="qzWrong" hidden class="ranges">${QZ.wrong.map(t=>`<button data-open="${VP[t]}" data-ay="${t}" style="font-size:15px">${esc(SURAH[VS[t]-1])} ${vkey(t)}</button>`).join('')}</div><small class="muted">Ayat ini disimpan dalam tab Tanda supaya diingatkan esok.</small>`:''}
      <button class="btn pri" data-qzend="1">${pass?'Teruskan':'Baik, saya ulang dulu'}</button>`,sh=>{const b=sh.querySelector('#qzShow');if(b)b.onclick=()=>{sh.querySelector('#qzWrong').hidden=false;b.hidden=true}});return}
  const q=qs[i];
  openSheet(`<div class="qz-top"><b>Kuiz ${KINDN[cfg.kind]}</b><span class="small muted">Soalan ${i+1} daripada ${qs.length}</span></div><div class="qz-bar"><i style="width:${i/qs.length*100}%"></i></div>
    <h3>${esc(q.label)}</h3>${q.ar?`<div class="ar-big">${esc(q.ar)}${q.num?` ${AR(q.num)}`:''}</div>`:''}
    <div class="qz-opts">${q.choices.map((c,k)=>`<button class="qz-opt" data-qz="${k}">${esc(c.t)}</button>`).join('')}</div>
    <div class="row" style="justify-content:space-between"><button class="btn ghost sm" data-close="1">Batal kuiz</button><button class="btn pri" id="qzNext" hidden>${i+1<qs.length?'Seterusnya':'Lihat keputusan'}</button></div>`)}
function answerQuiz(k){if(QZ.answered)return;QZ.answered=true;const q=QZ.qs[QZ.i],c=q.choices[k];
  if(c.ok)QZ.score++;else{QZ.wrong.push(q.target);if(!openMarks().some(m=>m.i===q.target))addMark(q.target,'lupa','','kuiz '+KINDN[QZ.cfg.kind].toLowerCase())}
  document.querySelectorAll('.qz-opt').forEach((b,j)=>{b.disabled=true;if(q.choices[j].ok)b.classList.add('ok');else if(j===k)b.classList.add('no')});
  const n=document.getElementById('qzNext');n.hidden=false;n.onclick=()=>{QZ.i++;QZ.answered=false;renderQuiz()}}
function endQuiz(){const pass=QZ.score/QZ.qs.length>=0.7;closeLayer();if(pass)QZ.cfg.onPass();else QZ.cfg.onFail(QZ.wrong)}

/* ---------- Bacaan imam ---------- */
const QARI={ghamidi:{n:'Saad Al-Ghamidi',dir:'Ghamadi_40kbps'},baleela:{n:'Bandar Baleela (surah penuh)',surah:true},husary:{n:'Mahmoud Al-Husary',dir:'Husary_128kbps'},alafasy:{n:'Mishary Alafasy',dir:'Alafasy_128kbps'}};
const AP={qari:null,s:1,from:1,to:7,repA:1,repAll:1,queue:[],pos:0,playing:false,cur:null};
let AU=null;
const ayahUrl=(q,s,a)=>QARI[q].surah?`https://archive.org/download/alfirdwsiy1433_gmail_0356835683568568356856802/${pad3(s)}.mp3`:`https://everyayah.com/data/${QARI[q].dir}/${pad3(s)}${pad3(a)}.mp3`;
function playStart(){
  if(!AU){AU=new Audio();AU.preload='auto';AU.addEventListener('ended',playNext);AU.addEventListener('error',()=>{if(AP.playing){toast('Audio tidak dapat dimainkan. Semak sambungan internet.');playStop()}})}
  const Q=[];if(QARI[AP.qari].surah){for(let r=0;r<AP.repAll;r++)Q.push(vIndex(AP.s,1))}
  else for(let r=0;r<AP.repAll;r++)for(let a=AP.from;a<=AP.to;a++)for(let k=0;k<AP.repA;k++)Q.push(vIndex(AP.s,a));
  AP.queue=Q;AP.pos=-1;AP.playing=true;playNext()}
function playNext(){AP.pos++;if(AP.pos>=AP.queue.length){playStop();toast('Bacaan selesai');return}
  const i=AP.queue[AP.pos];AP.cur=i;AU.src=ayahUrl(AP.qari,VS[i],VA[i]);AU.play().catch(()=>{});
  if(!QARI[AP.qari].surah&&tab==='mushaf'&&VP[i]!==curPage){curPage=VP[i];render()}else markPlaying();renderDock()}
function playStop(){AP.playing=false;AP.cur=null;if(AU)AU.pause();markPlaying();renderDock()}
function markPlaying(){document.querySelectorAll('.w.play').forEach(e=>e.classList.remove('play'));if(AP.playing&&AP.cur!==null&&!QARI[AP.qari].surah)document.querySelectorAll(`.w[data-i="${AP.cur}"]`).forEach(e=>e.classList.add('play'))}
function playerSheet(i){
  if(i!=null){AP.s=VS[i];AP.from=VA[i];let e=i;while(e+1<pageEnd(VP[i])&&VS[e+1]===VS[i])e++;AP.to=VA[e]}
  else if(!AP.playing){const f=pageFirst(curPage);AP.s=VS[f];AP.from=VA[f];let e=f;while(e+1<pageEnd(curPage)&&VS[e+1]===VS[f])e++;AP.to=VA[e]}
  if(!AP.qari)AP.qari=QARI[S.set.reciter]?S.set.reciter:'ghamidi';
  openSheet(`<h3>Dengar bacaan imam</h3>
   <div class="field"><label for="apQ">Qari</label><select id="apQ">${Object.entries(QARI).map(([k,v])=>`<option value="${k}" ${AP.qari===k?'selected':''}>${esc(v.n)}</option>`).join('')}</select></div>
   <div class="field"><label for="apS">Surah</label><select id="apS">${SURAH.map((n,k)=>`<option value="${k+1}" ${AP.s===k+1?'selected':''}>${k+1}. ${esc(n)}</option>`).join('')}</select></div>
   <div class="grid2" id="apRange"><div class="field"><label for="apF">Dari ayat</label><input type="number" id="apF" min="1" value="${AP.from}"></div><div class="field"><label for="apT">Hingga ayat</label><input type="number" id="apT" min="1" value="${AP.to}"></div></div>
   <div class="grid2"><div class="field" id="apRAw"><label for="apRA">Ulang setiap ayat</label><input type="number" id="apRA" min="1" max="20" value="${AP.repA}"></div><div class="field"><label for="apRAll">Ulang keseluruhan</label><input type="number" id="apRAll" min="1" max="20" value="${AP.repAll}"></div></div>
   <small class="muted" id="apNote"></small>
   <div class="grid2"><button class="btn pri" id="apPlay">${ico('play',18)}Main</button><button class="btn" id="apStop">${ico('stop',18)}Henti</button></div>
   <button class="btn ghost" data-close="1">Tutup</button>`,sh=>{
    const upd=()=>{const q=sh.querySelector('#apQ').value,s=+sh.querySelector('#apS').value,surah=QARI[q].surah;
      sh.querySelector('#apRange').hidden=surah;sh.querySelector('#apRAw').hidden=surah;['#apF','#apT'].forEach(id=>sh.querySelector(id).max=D.sc[s-1]);
      sh.querySelector('#apNote').textContent=surah?'Bacaan Bandar Baleela hanya tersedia untuk surah penuh.':'Surah '+SURAH[s-1]+' ada '+D.sc[s-1]+' ayat. Perlukan internet.'};
    sh.querySelector('#apQ').onchange=upd;sh.querySelector('#apS').onchange=()=>{const s=+sh.querySelector('#apS').value;sh.querySelector('#apF').value=1;sh.querySelector('#apT').value=D.sc[s-1];upd()};upd();
    sh.querySelector('#apPlay').onclick=()=>{const g=(id,lo,hi,d)=>Math.min(hi,Math.max(lo,parseInt(sh.querySelector(id).value)||d));
      AP.qari=sh.querySelector('#apQ').value;AP.s=+sh.querySelector('#apS').value;const mx=D.sc[AP.s-1];
      AP.from=g('#apF',1,mx,1);AP.to=g('#apT',AP.from,mx,mx);AP.repA=g('#apRA',1,20,1);AP.repAll=g('#apRAll',1,20,1);
      closeLayer();selAyah=null;if(!QARI[AP.qari].surah){curPage=VP[vIndex(AP.s,AP.from)];tab='mushaf';render()}playStart()};
    sh.querySelector('#apStop').onclick=()=>{playStop();closeLayer()}})}

/* ---------- Dok bawah (audio / AI) ---------- */
function renderDock(){const d=document.getElementById('dock');
  if(AI.active){d.hidden=false;d.innerHTML=aiDock();return}
  if(!AP.playing){d.hidden=true;d.innerHTML='';return}
  const i=AP.cur;d.hidden=false;
  d.innerHTML=`<div class="dock-in"><span class="eq"><i></i><i></i><i></i></span><div class="dock-t"><b>${esc(SURAH[VS[i]-1])} ${QARI[AP.qari].surah?'(surah penuh)':vkey(i)}</b><span>${esc(QARI[AP.qari].n)}, ${AP.pos+1} daripada ${AP.queue.length}</span></div><button class="btn sm" data-player="1">Ubah</button><button class="btn sm" data-stop="1">${ico('stop',16)}Henti</button></div>`}
/* ---------- Tasmik AI (beta) ---------- */
const AI={w:null,ready:false,active:false,phase:'idle',pct:0,label:'',page:null,issues:[],total:{},stream:null,ctx:null,t0:0,timer:null,err:''};
const AI_KIND={possible_skipped_ayah:'Ayat mungkin tertinggal',possible_omission:'Perkataan mungkin tertinggal',possible_substitution:'Perkataan mungkin tertukar',possible_vowel:'Baris mungkin tersalah',possible_repetition:'Ada ulangan',unclear_ayah:'Bacaan kurang jelas'};
const aiModelUrl=()=>new URL(CFG.aiBase,location.href).href;
function aiWorker(){if(!AI.w){AI.w=new Worker('ai-rt/tasmik-worker.js',{type:'module'});AI.w.onmessage=e=>aiMsg(e.data);AI.w.onerror=()=>aiFail('Komponen AI tidak dapat dimulakan pada peranti ini.')}return AI.w}
async function aiCached(){try{const c=await caches.open('tasmik-ai-v1');return !!(await c.match(aiModelUrl()+'zipformer_a0w_ep1_a05.int8.onnx'))}catch(e){return false}}
async function aiOpen(p){
  if(p!==curPage||tab!=='mushaf')gotoPage(p);
  if(AP.playing)playStop();
  AI.active=true;AI.page=curPage;AI.issues=[];AI.err='';
  if(AI.ready)AI.phase='ready';else AI.phase=(await aiCached())?'loading':'ask';
  if(AI.phase==='loading')aiLoad();renderDock()}
function aiLoad(){AI.phase='loading';AI.pct=0;AI.label='';renderDock();aiWorker().postMessage({type:'init',base:aiModelUrl(),wasmPaths:new URL('ai-rt/',location.href).href})}
function aiFail(msg){AI.phase='error';AI.err=msg;aiStopMic();renderDock()}
function aiClose(){aiStopMic();AI.active=false;AI.phase=AI.ready?'ready':'idle';renderDock()}
function aiExpected(p){const f=pageFirst(p);let e=f;while(e+1<pageEnd(p)&&VS[e+1]===VS[f])e++;return{surah:VS[f],ayah:VA[f],ayahEnd:VA[e]}}
async function aiStartRec(){
  const p=AI.page;for(let i=pageFirst(p);i<pageEnd(p);i++){delete heard[i];aiIssue.delete(i)}
  AI.issues=[];AI.total={};render();
  try{AI.stream=await navigator.mediaDevices.getUserMedia({audio:{channelCount:1,echoCancellation:false,noiseSuppression:true,autoGainControl:true}})}
  catch(e){toast('Benarkan mikrofon untuk guna tasmik AI.');return}
  try{
    const Ctx=window.AudioContext||window.webkitAudioContext,ctx=new Ctx({sampleRate:16000});AI.ctx=ctx;
    const code=`class R extends AudioWorkletProcessor{constructor(){super();this.b=new Float32Array(7680);this.n=0}process(i){const c=i[0]&&i[0][0];if(c){let o=0;while(o<c.length){const k=Math.min(c.length-o,this.b.length-this.n);this.b.set(c.subarray(o,o+k),this.n);this.n+=k;o+=k;if(this.n===this.b.length){this.port.postMessage(this.b.slice(0));this.n=0}}}return true}}registerProcessor('rec16',R)`;
    await ctx.audioWorklet.addModule(URL.createObjectURL(new Blob([code],{type:'text/javascript'})));
    const src=ctx.createMediaStreamSource(AI.stream),node=new AudioWorkletNode(ctx,'rec16'),mute=ctx.createGain();mute.gain.value=0;
    node.port.onmessage=e=>{const s=e.data;let m=0;for(let i=0;i<s.length;i+=40)m=Math.max(m,Math.abs(s[i]));AI.level=m;AI.w.postMessage({type:'audio',samples:s},[s.buffer]);const b=document.getElementById('aiLvl');if(b)b.style.width=Math.min(100,m*140)+'%'};
    src.connect(node);node.connect(mute);mute.connect(ctx.destination);
  }catch(e){aiStopMic();aiFail('Rakaman tidak dapat dimulakan: '+(e&&e.message||e));return}
  aiWorker().postMessage({type:'start',expected:aiExpected(p)});
  AI.phase='recording';AI.t0=Date.now();clearInterval(AI.timer);AI.timer=setInterval(()=>{const t=document.getElementById('aiTime');if(t){const s=Math.floor((Date.now()-AI.t0)/1000);t.textContent=Math.floor(s/60)+':'+String(s%60).padStart(2,'0')}},500);
  renderDock()}
function aiStopMic(){clearInterval(AI.timer);try{if(AI.stream)AI.stream.getTracks().forEach(t=>t.stop())}catch(e){}try{if(AI.ctx)AI.ctx.close()}catch(e){}AI.stream=null;AI.ctx=null}
function aiFinish(){aiStopMic();AI.phase='processing';renderDock();aiWorker().postMessage({type:'stop'})}
function aiMsg(m){
  if(m.type==='loading'){AI.pct=m.percent;AI.label=m.label;const b=document.getElementById('aiMeter');if(b)b.style.width=m.percent+'%';const t=document.getElementById('aiLoadT');if(t)t.textContent=(m.label==='model'?'Memuat turun model AI':m.label==='korpus'?'Memuat turun data ayat':'Menyediakan')+' '+m.percent+'%';return}
  if(m.type==='ready'){AI.ready=true;if(AI.phase==='loading')AI.phase='ready';renderDock();return}
  if(m.type==='error'){aiFail(/fetch|404|Gagal/i.test(m.message)?'Model AI belum tersedia. Pastikan ada internet untuk muat turun kali pertama.':'Ralat AI: '+m.message);return}
  if(m.type==='progress'){const i=vIndex(m.surah,m.ayah);AI.total[i]=m.total;const set=heard[i]||(heard[i]=new Set());m.matched.forEach(x=>set.add(x+1));
    document.querySelectorAll(`.w[data-i="${i}"]`).forEach(el=>{if(set.has(+el.dataset.w)){el.classList.add('heard');el.classList.remove('h')}});
    const c=document.getElementById('aiCount');if(c)c.textContent=aiCoverage().txt;return}
  if(m.type==='issue'){const is=m.issue,i=vIndex(is.surah,is.ayah);AI.issues.push(is);aiIssue.add(i);document.querySelectorAll(`.w[data-i="${i}"]`).forEach(el=>el.classList.add('issue'));return}
  if(m.type==='done'){AI.phase='ready';renderDock();aiResult()}}
function aiCoverage(){const p=AI.page;let n=0,ok=0;for(let i=pageFirst(p);i<pageEnd(p);i++){n++;const t=AI.total[i],h=heard[i];if(t&&h&&h.size/t>=0.6)ok++}return{n,ok,txt:ok+' daripada '+n+' ayat didengar'}}
function aiDock(){
  const ph=AI.phase;let inner='';
  if(ph==='ask')inner=`<div class="dock-t"><b>Tasmik AI (beta)</b><span>Kali pertama perlu muat turun kira-kira 75 MB. Guna Wi-Fi jika boleh.</span></div><button class="btn sm pri" data-aiload="1">Muat turun</button><button class="btn sm ghost" data-aiclose="1">${ico('x',16)}</button>`;
  else if(ph==='loading')inner=`<div class="dock-t"><b id="aiLoadT">Menyediakan AI ${AI.pct||0}%</b><div class="meter"><i id="aiMeter" style="width:${AI.pct||0}%"></i></div></div><button class="btn sm ghost" data-aiclose="1">${ico('x',16)}</button>`;
  else if(ph==='ready')inner=`<button class="mic" data-aistart="1" aria-label="Mula tasmik">${ico('mic',22)}</button><div class="dock-t"><b>Sedia untuk ${HL(AI.page)}</b><span>Tekan mikrofon dan mula membaca. Perkataan yang didengar akan muncul hijau.</span></div><button class="btn sm ghost" data-aiclose="1">${ico('x',16)}</button>`;
  else if(ph==='recording')inner=`<button class="mic rec" data-aistop="1" aria-label="Selesai">${ico('stop',20)}</button><div class="dock-t"><b><span id="aiTime">0:00</span>, sedang mendengar</b><span id="aiCount">${aiCoverage().txt}</span><div class="meter" style="margin-top:4px"><i id="aiLvl" style="width:0"></i></div></div><button class="btn sm pri" data-aistop="1">Selesai</button>`;
  else if(ph==='processing')inner=`<span class="eq"><i></i><i></i><i></i></span><div class="dock-t"><b>Menyemak bacaan…</b></div>`;
  else inner=`<div class="dock-t"><b>Tasmik AI tidak dapat diteruskan</b><span>${esc(AI.err)}</span></div><button class="btn sm" data-aiload="1">Cuba lagi</button><button class="btn sm ghost" data-aiclose="1">${ico('x',16)}</button>`;
  return`<div class="dock-in">${inner}</div>`}
function aiResult(){
  const p=AI.page,cov=aiCoverage(),iss=AI.issues,inSab=S.sabaq.includes(p),good=!iss.length&&cov.ok>=Math.ceil(cov.n*0.9);
  openSheet(`<h3>${good?'Bacaan lancar, alhamdulillah':iss.length?iss.length+' perkara untuk disemak':'Sebahagian ayat belum didengar'}</h3>
   <p class="muted" style="margin:0">${cov.txt} di ${HL(p)}.</p>
   ${iss.length?`<div class="panel" style="display:flex;flex-direction:column;gap:10px">${iss.map((s,k)=>{const i=vIndex(s.surah,s.ayah);return`<div class="row"><span style="flex:1">${AI_KIND[s.kind]||'Perlu disemak'}: ${esc(SURAH[s.surah-1])} ${s.surah}:${s.ayah}${s.kind==='possible_skipped_ayah'?'':', perkataan ke-'+(s.word+1)}</span><button class="btn sm" data-aimark="${k}">Tanda</button></div>`}).join('')}</div><button class="btn soft" data-aimarkall="1">Tanda semua ayat ini</button>`:''}
   ${inSab?(good?`<button class="btn ok" data-aicount="1">${ico('check',18)}Kira sebagai tasmik lancar</button>`:`<button class="btn" data-aicount="0">Kira sebagai ada salah</button>`):''}
   <small class="muted">AI ini masih beta. Ia boleh tersilap dan tidak menyemak tajwid. Gunakan sebagai pembantu, bukan pengganti guru.</small>
   <button class="btn ghost" data-close="1">Tutup</button>`)}
function aiMark(is){const i=vIndex(is.surah,is.ayah);if(!openMarks().some(m=>m.i===i))addMark(i,is.kind==='possible_substitution'?'tukar':'lupa',AI_KIND[is.kind]||'','tasmik AI')}
/* ---------- Helaian & paparan ---------- */
let tab='home';
const $=s=>document.querySelector(s);
function toast(msg){document.querySelectorAll('.toast').forEach(x=>x.remove());const t=document.createElement('div');t.className='toast';t.setAttribute('role','status');t.textContent=msg;document.body.appendChild(t);setTimeout(()=>t.remove(),3200)}
function petals(){if(matchMedia('(prefers-reduced-motion: reduce)').matches)return;const cols=['#f6a6bd','#ffd36e','#b9a6ee','#ffb38a','#9ed6f6','#9fd8b0'];
  for(let k=0;k<20;k++){const e=document.createElement('i');e.className='petal';e.style.left=(Math.random()*100)+'vw';e.style.background=cols[k%cols.length];e.style.setProperty('--dx',(Math.random()*120-60)+'px');e.style.animationDuration=(1.8+Math.random()*1.4)+'s';e.style.animationDelay=(Math.random()*.4)+'s';document.body.appendChild(e);setTimeout(()=>e.remove(),3800)}}
const layerOpen=()=>!!$('#layer').innerHTML;
function closeLayer(){$('#layer').innerHTML=''}
function closeSheet(){closeLayer();if(selAyah!==null&&tab==='mushaf'){selAyah=null;render()}}
function openSheet(html,onMount){$('#layer').innerHTML=`<div class="scrim" data-close="1"></div><div class="sheet" role="dialog" aria-modal="true"><div class="grab"></div><div class="wrap">${html}</div></div>`;onMount&&onMount($('#layer .sheet'))}
function greet(){const n=S.set.name.trim();$('#greet').textContent='Bismillah, jom mula'+(n?' '+n:'');$('#greetSub').textContent=fmtDate(dkey())}
function render(){
  ensure();greet();
  if(tab==='mushaf'){if(curPage!==lastPg){revealed=new Set();lastPg=curPage}S.lastPage=curPage;saveLocal()}
  $('#view').innerHTML=tab==='home'?vHome():tab==='mushaf'?vMushaf():tab==='peta'?vPeta():vTanda();
  if(tab==='mushaf')afterMushaf();
  document.querySelectorAll('nav.tabs button').forEach(b=>b.setAttribute('aria-current',b.dataset.tab===tab?'page':'false'))}
function go(t,opts={}){if(t!=='mushaf'&&fullscreen){fullscreen=false;document.body.classList.remove('fs')}tab=t;if(opts.page)curPage=opts.page;if(opts.ayah!==undefined)selAyah=opts.ayah;render();window.scrollTo(0,0)}

/* ---------- Tetapan ---------- */
const sqOpts=[[0,'Tiada'],[2,'¼ juz'],[4,'½ juz'],[8,'1 juz'],[16,'2 juz']],mzOpts=[[2,'¼ juz'],[4,'½ juz'],[8,'1 juz'],[16,'2 juz']];
function startOptions(mode,cur){
  if(mode==='surah')return SURAH.map((n,k)=>`<option value="${k+1}" ${cur===k+1?'selected':''}>${k+1}. ${esc(n)}</option>`).join('');
  if(mode==='juz')return range(1,30).map(j=>`<option value="${j}" ${cur===j?'selected':''}>Juz ${j}</option>`).join('');
  return range(1,30).map(j=>{const a=juzPages(j)[0];return`<option value="${a}" ${cur===a?'selected':''}>Halaman ${a} (awal Juz ${j})</option>`}).join('')}
let deferredInstall=null;window.addEventListener('beforeinstallprompt',e=>{e.preventDefault();deferredInstall=e});
function settingsSheet(){
  const st=S.set;
  openSheet(`<h3>Tetapan</h3>
  <div class="field"><label for="sName">Nama</label><input type="text" id="sName" maxlength="24" value="${esc(st.name)}" placeholder="Nama anda"></div>
  <div class="field"><span class="lbl">Tema</span><div class="seg">${[['light','Terang'],['dark','Gelap'],['','Ikut fon']].map(([k,l])=>`<button class="${st.theme===k?'on':''}" data-themeset="${k}">${l}</button>`).join('')}</div></div>
  <div class="field"><span class="lbl">Warna</span><div class="swatches">${Object.entries(PALET).map(([k,v])=>`<button class="${st.palette===k?'on':''}" data-palette="${k}" aria-label="${v.n}" title="${v.n}"><span style="background:${v.L[2]}"></span></button>`).join('')}</div><small>${PALET[st.palette].n}. Halaman mushaf kekal krim.</small></div>
  <div class="field"><span class="lbl">Sabaq ikut</span><div class="seg" id="sMode">${[['halaman','Halaman'],['surah','Surah'],['juz','Juz']].map(([k,l])=>`<button class="${st.sabaqMode===k?'on':''}" data-v="${k}">${l}</button>`).join('')}</div></div>
  <div class="grid2"><div class="field"><label for="sStart">Mula dari</label><select id="sStart">${startOptions(st.sabaqMode,st.start)}</select></div>
  <div class="field"><label for="sDir">Arah</label><select id="sDir"><option value="maju" ${st.sabaqDir==='maju'?'selected':''}>Ke hadapan</option><option value="undur" ${st.sabaqDir==='undur'?'selected':''}>Ke belakang</option></select></div></div>
  <div class="grid2"><div class="field"><label for="sN">Halaman sabaq serentak</label><input type="number" id="sN" min="1" max="10" value="${st.sabaqN}"></div><div class="field"><label for="sNeed">Tasmik untuk lancar</label><input type="number" id="sNeed" min="1" max="10" value="${st.need}"></div></div>
  <div class="grid2"><div class="field"><label for="sR">Sabqi: halaman baru lancar</label><input type="number" id="sR" min="0" max="20" value="${st.recentN}"></div><div class="field"><label for="sSq">Sabqi: dari juz sederhana</label><select id="sSq">${sqOpts.map(([v,l])=>`<option value="${v}" ${st.sqMaqra===v?'selected':''}>${l}</option>`).join('')}</select></div></div>
  <div class="field"><label for="sMz">Manzil sehari</label><select id="sMz">${mzOpts.map(([v,l])=>`<option value="${v}" ${st.mzMaqra===v?'selected':''}>${l}</option>`).join('')}</select><small>Ikut sempadan hizb dan juz sebenar.</small></div>
  <div class="field"><label for="sRec">Qari utama</label><select id="sRec">${Object.entries(QARI).map(([k,v])=>`<option value="${k}" ${st.reciter===k?'selected':''}>${esc(v.n)}</option>`).join('')}</select></div>
  <label class="row" style="font-weight:600"><input type="checkbox" id="sRest" ${st.rest?'checked':''}> Hari rehat: satu hari terlepas setiap minggu tidak memutuskan siraman taman</label>
  ${NATIVE?`<div class="field"><span class="lbl">Reminder harian</span><div class="grid2"><div class="field"><label for="r1">Pertama</label><input type="time" id="r1" value="${st.rem1}"></div><div class="field"><label for="r2">Kedua</label><input type="time" id="r2" value="${st.rem2}"></div></div><label class="row"><input type="checkbox" id="rOn" ${st.remOn?'checked':''}> Hidupkan reminder</label><button class="btn sm" id="rTest">Cuba notifikasi (5 saat)</button></div>`:`<p class="small muted" style="margin:0">Reminder harian hanya ada dalam app Android.</p><a class="btn soft" href="${esc(CFG.apkUrl)}" rel="noopener">Muat turun app Android (APK)</a>${deferredInstall?'<button class="btn soft" id="instBtn">Pasang app di skrin utama</button>':''}`}
  <button class="btn pri" id="sSave">Simpan tetapan</button>
  <details><summary><b>Sandaran data</b></summary><div class="row" style="margin-top:8px"><button class="btn sm" id="bkCopy">Salin data</button>${NATIVE?'':'<button class="btn sm" id="bkFile">Simpan fail sandaran</button>'}<button class="btn sm" id="bkPaste">Pulihkan dari teks</button><label class="btn sm" for="bkIn">Pulihkan dari fail</label><input type="file" id="bkIn" accept=".json,application/json" hidden></div><p class="small muted">Untuk pindah ke fon atau app lain: salin data di sini, kemudian pulihkan di sana.</p></details>
  <details><summary><b>Ulang soalan permulaan</b></summary><p class="small muted">Tetapkan semula tahap setiap juz dan cara mengulang. Tanda ayat, rekod dan taman tidak dipadam.</p><button class="btn sm" id="rsWiz">Mula soalan permulaan</button></details>
  <details><summary><b>Tentang & penghargaan</b></summary><div class="small muted" style="display:flex;flex-direction:column;gap:6px;margin-top:8px">
   <span>Teks dan fon mushaf: King Fahd Glorious Qur'an Printing Complex (QPC Hafs), susunan halaman melalui projek mushaf-layout.</span>
   <span>Terjemahan: Abdullah Muhammad Basmeih (Bahasa Melayu). Maksud perkataan: Quran.com (Inggeris).</span>
   <span>Audio: EveryAyah.com dan arkib bacaan Bandar Baleela di archive.org.</span>
   <span>Tasmik AI: model Zipformer projek Tilawa (lesen NPL-1.2, bukan komersial). AI masih beta, boleh tersilap dan tidak menyemak tajwid.</span>
   <span>Fon: Shantell Sans dan Atkinson Hyperlegible Next (SIL OFL).</span>
   <span>App ini percuma untuk kegunaan peribadi. Penerbitan app Al-Quran kepada umum di Malaysia memerlukan perakuan KDN.</span></div></details>
  <button class="btn ghost" data-close="1">Tutup</button>`,sh=>{
    let mode=st.sabaqMode;
    sh.querySelectorAll('#sMode button').forEach(b=>b.onclick=()=>{mode=b.dataset.v;sh.querySelectorAll('#sMode button').forEach(x=>x.classList.toggle('on',x===b));sh.querySelector('#sStart').innerHTML=startOptions(mode,mode==='halaman'?1:1)});
    sh.querySelector('#sSave').onclick=()=>{const n=(id,lo,hi,d)=>Math.min(hi,Math.max(lo,parseInt(sh.querySelector(id).value)||d));
      const before=JSON.stringify([st.sabaqMode,st.sabaqDir,st.start]);
      st.name=sh.querySelector('#sName').value.trim();st.sabaqMode=mode;st.start=+sh.querySelector('#sStart').value;st.sabaqDir=sh.querySelector('#sDir').value;
      st.sabaqN=n('#sN',1,10,1);st.need=n('#sNeed',1,10,3);st.recentN=n('#sR',0,20,5);st.sqMaqra=+sh.querySelector('#sSq').value;st.mzMaqra=+sh.querySelector('#sMz').value;
      st.reciter=sh.querySelector('#sRec').value;st.rest=sh.querySelector('#sRest').checked;
      if(NATIVE){st.rem1=sh.querySelector('#r1').value||'06:30';st.rem2=sh.querySelector('#r2').value||'19:15';st.remOn=sh.querySelector('#rOn').checked}
      if(before!==JSON.stringify([st.sabaqMode,st.sabaqDir,st.start]))S.sabaq=S.sabaq.filter(p=>(S.tas[p]||0)>0);
      while(S.sabaq.length>st.sabaqN&&!(S.tas[S.sabaq[S.sabaq.length-1]]>0))S.sabaq.pop();
      if(S.plan&&!S.plan.done.mz&&!S.plan.done.sq)S.plan=null;save();closeLayer();render();if(NATIVE)setTimeout(()=>scheduleReminders(true),300);toast('Tetapan disimpan')};
    const t=sh.querySelector('#rTest');if(t)t.onclick=async()=>{const r=await scheduleReminders(true);if(r!=='granted'){toast('Benarkan notifikasi dalam Tetapan fon dahulu.');return}try{await Capacitor.Plugins.LocalNotifications.schedule({notifications:[{id:99,title:'Murajaah Itqan',body:'Notifikasi berfungsi. Jumpa waktu murajaah nanti!',smallIcon:'ic_stat_quran',schedule:{at:new Date(Date.now()+5000),allowWhileIdle:true}}]});toast('Notifikasi cubaan akan muncul dalam 5 saat')}catch(e){toast('Notifikasi cubaan tidak dapat dihantar')}};
    const ib=sh.querySelector('#instBtn');if(ib)ib.onclick=async()=>{deferredInstall.prompt();deferredInstall=null;closeLayer()};
    sh.querySelector('#bkCopy').onclick=()=>{const t=JSON.stringify(S);const fb=()=>openSheet(`<h3>Data sandaran</h3><p class="small muted">Tekan lama, pilih semua dan salin.</p><textarea readonly style="min-height:200px">${esc(t)}</textarea><button class="btn ghost" data-close="1">Tutup</button>`);try{navigator.clipboard.writeText(t).then(()=>toast('Data disalin. Simpan dalam nota anda.'),fb)}catch(e){fb()}};
    const bf=sh.querySelector('#bkFile');if(bf)bf.onclick=()=>{const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([JSON.stringify(S)],{type:'application/json'}));a.download='murajaah-sandaran-'+dkey()+'.json';a.click()};
    const restore=txt=>{try{const x=JSON.parse(txt);if(!x.levels)throw 0;S=migrate(x);orderCache.key='';save();applyTheme();closeLayer();render();toast('Data dipulihkan')}catch(e){toast('Ini bukan data sandaran Murajaah Itqan.')}};
    sh.querySelector('#bkPaste').onclick=()=>openSheet(`<h3>Pulihkan dari teks</h3><textarea id="pst" placeholder="Tampal data sandaran di sini" style="min-height:180px"></textarea><button class="btn pri" id="pstGo">Pulihkan</button><button class="btn ghost" data-close="1">Batal</button>`,s2=>{s2.querySelector('#pstGo').onclick=()=>restore(s2.querySelector('#pst').value)});
    sh.querySelector('#bkIn').onchange=e=>{const f=e.target.files[0];if(!f)return;const r=new FileReader();r.onload=()=>restore(r.result);r.readAsText(f)};
    sh.querySelector('#rsWiz').onclick=()=>{closeLayer();openWizard(true)};
  })}

/* ---------- Reminder (Android) ---------- */
function reminderBody(){try{ensure();const P=S.plan,sb=S.sabaq.length?'Sabaq halaman '+S.sabaq.join(', '):'Sabaq selesai';const mz=groupRanges(P.mz).map(r=>rangeText(r).replace('Halaman','halaman')).join(', ');return sb+'. Sabqi '+sqPages().length+' halaman.'+(mz?' Manzil '+mz+'.':'')}catch(e){return'Buka app untuk lihat jadual hari ini.'}}
async function scheduleReminders(ask){
  if(!NATIVE)return'web';const LN=Capacitor.Plugins&&Capacitor.Plugins.LocalNotifications;if(!LN)return'none';
  try{let p=await LN.checkPermissions();if(p.display!=='granted'&&ask)p=await LN.requestPermissions();
    try{await LN.cancel({notifications:[{id:1},{id:2}]})}catch(e){}
    if(p.display!=='granted')return p.display;if(!S.set.remOn)return'granted';
    const body=reminderBody(),who=S.set.name?', '+S.set.name:'',mk=(id,tm,title)=>{const [h,m]=tm.split(':').map(Number);return{id,title,body,largeBody:body,smallIcon:'ic_stat_quran',schedule:{on:{hour:h,minute:m},allowWhileIdle:true}}};
    await LN.schedule({notifications:[mk(1,S.set.rem1,'Jom murajaah'+who),mk(2,S.set.rem2,'Masa murajaah'+who)]});return'granted'}catch(e){return'error'}}
/* ---------- Soalan permulaan ---------- */
const W={step:0,brush:2,jl:[]};
const WLV=[[2,'Lancar'],[1,'Sederhana'],[0,'Lemah'],[3,'Belum hafal']];
function juzLevelNow(j){const [a,b]=juzPages(j),c=[0,0,0,0];for(let p=a;p<=b;p++)c[lv(p)]++;return c.indexOf(Math.max(...c))}
function openWizard(again){const st=S.set;
  Object.assign(W,{step:0,brush:2,again:!!again,name:st.name,palette:st.palette,mode:st.sabaqMode,dir:st.sabaqDir,start:st.start,startAuto:!again,order:st.order,sabaqN:st.sabaqN,need:st.need,recentN:st.recentN,sqMaqra:st.sqMaqra,mzMaqra:st.mzMaqra,rem1:st.rem1,rem2:st.rem2,remOn:st.remOn});
  W.jl=range(1,30).map(j=>again?juzLevelNow(j):3);renderWiz()}
function wizAutoStart(){const want=W.order==='baru'?[3,0,1]:[0,1,3];let j=1;for(const v of want){const k=W.jl.findIndex(x=>x===v);if(k>=0){j=k+1;break}}
  if(W.mode==='juz')return j;const [a]=juzPages(j);if(W.mode==='surah')return VS[pageFirst(a)];return a}
function renderWiz(){
  let el=$('#wiz');if(!el){el=document.createElement('div');el.id='wiz';document.body.appendChild(el)}
  const last=NATIVE?6:5,s=W.step,cnt=[0,0,0,0];W.jl.forEach(v=>cnt[v]++);
  if(W.startAuto)W.start=wizAutoStart();
  let h=`<div class="wiz-in"><div class="row" style="justify-content:space-between;min-height:34px"><span class="small muted">Langkah ${s+1} daripada ${last+1}</span>${W.again?'<button class="btn sm ghost" data-wz="cancel">Batal</button>':''}</div><div class="qz-bar"><i style="width:${s/last*100}%"></i></div>`;
  if(s===0)h+=`<div class="wiz-hero">${document.getElementById('splash')?'':''}<svg viewBox="0 0 120 120" width="150" height="150" aria-hidden="true"><circle cx="60" cy="58" r="26" fill="#ffd9a8"/><path d="M6 96c22-14 40-14 58-6s36 8 50-2v32H6z" fill="#bfe3c6"/><path d="M0 104c26-10 46-8 66-2s38 6 54-2v20H0z" fill="#9fd3ab"/><path d="M60 98V66" stroke="#4f9a68" stroke-width="4" stroke-linecap="round"/><path d="M60 72c-3-10-12-14-20-12 2 9 10 14 20 12z" fill="#6fbf86"/><path d="M60 68c3-11 13-15 22-13-2 10-12 15-22 13z" fill="#83cc98"/></svg><h2>Assalamualaikum!</h2><p>Murajaah Itqan menyusun sabaq, sabqi dan manzil ikut tahap hafazan anda. Setiap hari yang selesai menyiram Taman Murajaah anda.</p><p class="small muted">Susunan halaman ikut Mushaf Madinah 604 halaman, 15 baris. Jawab beberapa soalan dan jadual akan disediakan. Semuanya boleh diubah kemudian.</p></div>`;
  else if(s===1)h+=`<h2>Kenalkan diri</h2><div class="field"><label for="wName">Nama panggilan</label><input type="text" id="wName" maxlength="24" value="${esc(W.name)}" placeholder="Contoh: Ainul"><small>Untuk ucapan "Bismillah, jom mula …" di atas.</small></div>
    <div class="field"><span class="lbl">Warna kegemaran</span><div class="swatches">${Object.entries(PALET).map(([k,v])=>`<button class="${W.palette===k?'on':''}" data-wpal="${k}" aria-label="${v.n}"><span style="background:${v.L[2]}"></span></button>`).join('')}</div><small>${PALET[W.palette].n}</small></div>`;
  else if(s===2)h+=`<h2>Tahap hafazan setiap juz</h2><p class="muted" style="margin:0">Pilih tahap, kemudian tekan juz untuk mewarnakannya.</p>
    <div class="brushes">${WLV.map(([v,l])=>`<button class="br l${v}b ${W.brush===v?'on':''}" data-wbrush="${v}">${l}</button>`).join('')}</div>
    <div class="juzgrid">${W.jl.map((v,k)=>`<button class="jz l${v}b" data-wjuz="${k}" aria-label="Juz ${k+1}: ${WLV.find(x=>x[0]===v)[1]}"><b>${k+1}</b><span>${WLV.find(x=>x[0]===v)[1]}</span></button>`).join('')}</div>
    <button class="btn sm" data-wfill="1" style="align-self:flex-start">Isi semua juz dengan "${WLV.find(x=>x[0]===W.brush)[1]}"</button>`;
  else if(s===3){const both=cnt[3]>0&&(cnt[0]+cnt[1])>0;
    h+=`<h2>Sabaq</h2><p class="muted" style="margin:0">Sabaq ialah bacaan yang sedang dihafal atau diperkuat.</p>
    <div class="field"><span class="lbl">Ikut susunan</span><div class="opts">${[['halaman','Halaman','Satu demi satu halaman'],['surah','Surah','Surah demi surah, sesuai untuk Juz Amma'],['juz','Juz','Juz demi juz']].map(([k,l,d])=>`<button class="${W.mode===k?'on':''}" data-wmode="${k}"><b>${l}</b><span>${d}</span></button>`).join('')}</div></div>
    <div class="grid2"><div class="field"><label for="wStart">Mula dari</label><select id="wStart">${startOptions(W.mode,W.start)}</select></div><div class="field"><label for="wDir">Arah</label><select id="wDir"><option value="maju" ${W.dir==='maju'?'selected':''}>Ke hadapan</option><option value="undur" ${W.dir==='undur'?'selected':''}>Ke belakang (contoh: An-Nas dahulu)</option></select></div></div>
    ${both?`<div class="field"><span class="lbl">Utamakan</span><div class="opts"><button class="${W.order==='lemah'?'on':''}" data-worder="lemah"><b>Kuatkan yang lemah</b><span>Lemah dan sederhana dahulu</span></button><button class="${W.order==='baru'?'on':''}" data-worder="baru"><b>Hafazan baru</b><span>Yang lemah dijaga dalam sabqi</span></button></div></div>`:''}
    <div class="grid2"><div class="field"><label for="wN">Halaman sabaq serentak</label><input type="number" id="wN" min="1" max="10" value="${W.sabaqN}"></div><div class="field"><label for="wNeed">Tasmik untuk lancar</label><input type="number" id="wNeed" min="1" max="10" value="${W.need}"><small>kali berturut-turut</small></div></div>`}
  else if(s===4){h+=`<h2>Sabqi & Manzil</h2>
    <div class="field"><label for="wR">Sabqi: berapa halaman terakhir yang baru lancar diulang?</label><input type="number" id="wR" min="0" max="20" value="${W.recentN}"></div>
    <div class="field"><span class="lbl">Sabqi: bahagian daripada juz sederhana setiap hari</span><div class="opts">${sqOpts.map(([v,l])=>`<button class="${W.sqMaqra===v?'on':''}" data-wsq="${v}"><b>${l}</b></button>`).join('')}</div></div>
    <div class="field"><span class="lbl">Manzil: pusingan halaman lancar setiap hari</span><div class="opts">${mzOpts.map(([v,l])=>`<button class="${W.mzMaqra===v?'on':''}" data-wmz="${v}"><b>${l}</b></button>`).join('')}</div><small>Dengan ${cnt[2]} juz lancar, satu pusingan manzil ambil kira-kira ${Math.max(1,Math.ceil(cnt[2]*8/W.mzMaqra))} hari.</small></div>`}
  else if(s===5&&NATIVE){h+=`<h2>Reminder harian</h2><p class="muted" style="margin:0">Notifikasi menunjukkan bacaan hari itu.</p>
    <div class="grid2"><div class="field"><label for="wr1">Pertama</label><input type="time" id="wr1" value="${W.rem1}"></div><div class="field"><label for="wr2">Kedua</label><input type="time" id="wr2" value="${W.rem2}"></div></div>
    <label class="row" style="font-weight:600"><input type="checkbox" id="wrOn" ${W.remOn?'checked':''}> Hidupkan reminder</label>`}
  else{const jt=v=>{const r=groupRanges(W.jl.map((x,k)=>x===v?k+1:0).filter(Boolean));return r.length?r.map(([a,b])=>a===b?'Juz '+a:'Juz '+a+'–'+b).join(', '):'tiada'};
    const sl=W.mode==='surah'?'Surah '+SURAH[W.start-1]:W.mode==='juz'?'Juz '+W.start:HL(W.start);
    h+=`<h2>Sedia, ${esc(W.name||'sahabat')}?</h2><div class="panel" style="display:flex;flex-direction:column;gap:6px">
    <div><b>Lancar:</b> ${jt(2)}</div><div><b>Sederhana:</b> ${jt(1)}</div><div><b>Lemah:</b> ${jt(0)}</div><div><b>Belum hafal:</b> ${jt(3)}</div></div>
    <div class="panel" style="display:flex;flex-direction:column;gap:4px"><div>Sabaq ikut ${W.mode}, mula ${esc(sl)}, ${W.dir==='undur'?'ke belakang':'ke hadapan'}</div><div>Sabqi ${W.recentN} halaman baru lancar${W.sqMaqra?' + '+sqOpts.find(x=>x[0]===W.sqMaqra)[1]+' juz sederhana':''}</div><div>Manzil ${mzOpts.find(x=>x[0]===W.mzMaqra)[1]} sehari</div>${NATIVE&&W.remOn?`<div>Reminder ${W.rem1} dan ${W.rem2}</div>`:''}</div>
    ${W.again?'<p class="small muted" style="margin:0">Tanda ayat, rekod dan taman kekal. Kiraan tasmik sabaq semasa bermula semula.</p>':''}`}
  h+=`<div class="wiz-nav">${s>0?`<button class="btn" data-wz="back">${ico('left',18)}Kembali</button>`:'<span></span>'}<button class="btn pri" data-wz="${s>=last?'done':'next'}">${s===0?'Mula':s>=last?'Mula murajaah':'Seterusnya'}</button></div></div>`;
  el.innerHTML=h;el.scrollTop=0}
function wizCollect(){const v=id=>{const e=document.querySelector('#wiz '+id);return e?e.value:null},n=(id,lo,hi,d)=>{const x=v(id);return x===null?null:Math.min(hi,Math.max(lo,parseInt(x)||d))};
  if(W.step===1){W.name=(v('#wName')||'').trim()}
  if(W.step===3){const st=+v('#wStart');if(st&&st!==W.start){W.start=st;W.startAuto=false}W.dir=v('#wDir')||'maju';W.sabaqN=n('#wN',1,10,1);W.need=n('#wNeed',1,10,3)}
  if(W.step===4){W.recentN=n('#wR',0,20,5)}
  if(W.step===5&&NATIVE){W.rem1=v('#wr1')||'06:30';W.rem2=v('#wr2')||'19:15';W.remOn=$('#wrOn').checked}}
function wizFinish(){
  let s='';for(let p=1;p<=604;p++)s+=W.jl[PJ[p]-1];S.levels=s;
  Object.assign(S.set,{name:W.name,palette:W.palette,sabaqMode:W.mode,sabaqDir:W.dir,start:W.start,order:W.order,sabaqN:W.sabaqN,need:W.need,recentN:W.recentN,sqMaqra:W.sqMaqra,mzMaqra:W.mzMaqra,rem1:W.rem1,rem2:W.rem2,remOn:W.remOn});
  S.tas={};S.sabaq=[];S.recent=[];S.sqPtr=0;S.mzPtr=0;S.plan=null;S.onboarded=true;orderCache.key='';
  $('#wiz').remove();applyTheme();ensure();save();go('home');if(NATIVE)setTimeout(()=>scheduleReminders(true),500);petals();toast('Jadual anda dah siap. Bismillah!')}

/* ---------- Kawalan butang Back ---------- */
let backAt=0;
function handleBack(){
  if($('#wiz')){if(W.step>0){wizCollect();W.step--;renderWiz();return true}if(W.again){$('#wiz').remove();return true}return false}
  if(layerOpen()){closeSheet();return true}
  if(AI.active&&AI.phase!=='recording'){aiClose();return true}
  if(fullscreen){setFullscreen(false);return true}
  if(tab!=='home'){go('home');return true}
  if(Date.now()-backAt<2000)return false;
  backAt=Date.now();toast('Tekan sekali lagi untuk keluar');return true}
if(NATIVE&&Capacitor.Plugins&&Capacitor.Plugins.App){Capacitor.Plugins.App.addListener('backButton',()=>{if(!handleBack())Capacitor.Plugins.App.exitApp()})}
else{try{history.pushState({m:1},'');window.addEventListener('popstate',()=>{if(handleBack())history.pushState({m:1},'');else history.back()})}catch(e){}}

/* ---------- Peristiwa ---------- */
document.addEventListener('click',e=>{
  const t=e.target.closest('button,[data-close],.w,.ln.hl,label[for]');if(!t||t.closest('#wiz'))return;const d=t.dataset;
  if(t.classList.contains('w')||t.classList.contains('ln')){const ln=t.closest('.ln.hl');if(ln&&!(t.classList.contains('w')&&!t.classList.contains('h'))){revealed.add(+ln.dataset.ln);render();return}if(t.classList.contains('w')){ayahSheet(+d.i)}return}
  if(d.tab){go(d.tab);return}
  if(d.tabGo){go(d.tabGo);return}
  if(d.qz!==undefined){answerQuiz(+d.qz);return}
  if(d.qzend){endQuiz();return}
  if(d.res){resolveMark(d.res,true);if(d.close)closeSheet();toast('Alhamdulillah, ditanda dah baik');return}
  if(d.unres){resolveMark(d.unres,false);return}
  if(d.del){deleteMark(d.del);if(d.close)closeSheet();return}
  if(d.close){closeSheet();return}
  if(d.open){closeLayer();curPage=+d.open;selAyah=d.ay!==undefined?+d.ay:null;go('mushaf');if(d.ay!==undefined)setTimeout(()=>{const el=document.querySelector(`.w[data-i="${d.ay}"]`);el&&el.scrollIntoView({block:'center'})},120);return}
  if(d.goto){closeLayer();gotoPage(+d.goto);return}
  if(d.tas){tasmik(+d.tas,d.ok==='1');return}
  if(d.grad){askGraduate(+d.grad);return}
  if(d.rmsabaq){removeSabaq(+d.rmsabaq);return}
  if(d.done){toggleDone(d.done);return}
  if(d.info){const [n,txt]=INFO[d.info];openSheet(`<h3>${n}</h3><p style="margin:0">${esc(txt)}</p><button class="btn ghost" data-close="1">Faham</button>`);return}
  if(d.quizmarks){marksListSheet(openMarks().filter(m=>m.src===d.quizmarks&&(m.d===dkey()||m.d===addDays(dkey(),-1))),d.quizmarks.replace('kuiz','Kuiz')+': ayat untuk diulang');return}
  if(d.manualmarks){const tp=new Set([...S.sabaq,...sqPages(),...S.plan.mz]);marksListSheet(openMarks().filter(m=>!(m.src&&m.src.startsWith('kuiz'))&&(tp.has(m.p)||m.d===dkey()||m.d===addDays(dkey(),-1))),'Ayat yang anda tandakan');return}
  if(d.savename){const v=$('#nmIn').value.trim();if(v){S.set.name=v;save();render();scheduleReminders(false);toast('Selamat datang, '+v+'!')}return}
  if(d.lv!==undefined){const v=+d.lv;setLv(curPage,v);if(v===2){S.sabaq=S.sabaq.filter(x=>x!==curPage);delete S.tas[curPage]}save();closeLayer();render();toast(HL(curPage)+': '+LVN[v]);return}
  if(d.view){S.set.view=d.view;revealed=new Set();save();closeLayer();render();return}
  if(d.cycleview){const o=['full','awal','sorok'];S.set.view=o[(o.indexOf(S.set.view||'full')+1)%3];revealed=new Set();save();render();return}
  if(d.revealall){S.set.view='full';save();render();return}
  if(d.addsabaqpage){const p=+d.addsabaqpage;if(lv(p)===2)setLv(p,1);S.sabaq.push(p);save();closeLayer();render();toast(HL(p)+' ditambah ke sabaq');return}
  if(d.pagemenu){pageMenu();return}
  if(d.picker){pickerSheet(d.picker==='1'?null:d.picker);return}
  if(d.pktab){pickerSheet(d.pktab);return}
  if(d.fs!==undefined){setFullscreen(d.fs==='1');return}
  if(d.pg){gotoPage(+d.pg);return}
  if(d.map){mapMode=d.map;render();return}
  if(d.mf){markFilter=d.mf;render();return}
  if(d.playerI!==undefined){closeLayer();playerSheet(+d.playerI);return}
  if(d.player){if(AI.active)aiClose();playerSheet(null);return}
  if(d.stop){playStop();return}
  if(d.ai){aiOpen(+d.ai);return}
  if(d.aiload){aiLoad();return}
  if(d.aiclose){aiClose();return}
  if(d.aistart){aiStartRec();return}
  if(d.aistop){aiFinish();return}
  if(d.aimark!==undefined){aiMark(AI.issues[+d.aimark]);t.disabled=true;t.textContent='Ditanda';return}
  if(d.aimarkall){AI.issues.forEach(aiMark);closeLayer();render();toast('Ayat ditanda untuk diulang');return}
  if(d.aicount!==undefined){closeLayer();tasmik(AI.page,d.aicount==='1');return}
  if(d.themeset!==undefined){S.set.theme=d.themeset;applyTheme();save();document.querySelectorAll('[data-themeset]').forEach(b=>b.classList.toggle('on',b.dataset.themeset===S.set.theme));return}
  if(d.palette){S.set.palette=d.palette;applyTheme();save();document.querySelectorAll('[data-palette]').forEach(b=>b.classList.toggle('on',b.dataset.palette===S.set.palette));return}
  if(t.id==='addSabaq'){const p=nextSabaqPage();if(p){S.sabaq.push(p);save();render();toast(HL(p)+' ditambah ke sabaq')}return}
  if(t.id==='btnSet'){settingsSheet();return}
});
document.addEventListener('click',e=>{const t=e.target.closest('#wiz button');if(!t)return;const d=t.dataset;
  if(d.wbrush!==undefined){W.brush=+d.wbrush;renderWiz();return}
  if(d.wjuz!==undefined){W.jl[+d.wjuz]=W.brush;renderWiz();return}
  if(d.wfill){W.jl=W.jl.map(()=>W.brush);renderWiz();return}
  if(d.wpal){wizCollect();W.palette=d.wpal;S.set.palette=d.wpal;applyTheme();renderWiz();return}
  if(d.wmode){wizCollect();W.mode=d.wmode;W.startAuto=true;renderWiz();return}
  if(d.worder){wizCollect();W.order=d.worder;W.startAuto=true;renderWiz();return}
  if(d.wsq!==undefined){wizCollect();W.sqMaqra=+d.wsq;renderWiz();return}
  if(d.wmz!==undefined){wizCollect();W.mzMaqra=+d.wmz;renderWiz();return}
  if(d.wz==='cancel'){$('#wiz').remove();applyTheme();return}
  wizCollect();
  if(d.wz==='next'){W.step++;if(W.step===3&&W.startAuto)W.start=wizAutoStart();renderWiz()}else if(d.wz==='back'){W.step--;renderWiz()}else if(d.wz==='done')wizFinish()});
document.addEventListener('keydown',e=>{if(e.key==='Escape')handleBack();if(e.key==='Enter'&&e.target.id==='nmIn'){const b=document.querySelector('[data-savename]');b&&b.click()}});
// leret untuk tukar halaman (mushaf Arab: leret ke kanan = halaman seterusnya)
let tx=null,ty=null;
document.addEventListener('touchstart',e=>{if(tab!=='mushaf'||!e.target.closest('.mushaf'))return;tx=e.touches[0].clientX;ty=e.touches[0].clientY},{passive:true});
document.addEventListener('touchend',e=>{if(tx===null)return;const dx=e.changedTouches[0].clientX-tx,dy=e.changedTouches[0].clientY-ty;tx=null;if(Math.abs(dx)>70&&Math.abs(dx)>Math.abs(dy)*1.5)gotoPage(curPage+(dx>0?1:-1))},{passive:true});
window.addEventListener('resize',()=>{clearTimeout(window._rz);window._rz=setTimeout(fitPage,150)});
document.addEventListener('visibilitychange',()=>{if(!document.hidden){applySky();if(S.plan&&S.plan.date!==dkey())render()}});
setInterval(applySky,5*60*1000);

/* ---------- Mula ---------- */
applyTheme();
{const h=(location.hash||'').slice(1);if(['home','mushaf','peta','tanda'].includes(h))tab=h}
ensure();saveLocal();render();
if(!S.onboarded)openWizard(false);
/* ---------- Kod jemputan (web app sahaja) ---------- */
const INVITE_HASH='f5918f1ee5f6d1d2e1ae26b755993e8c7f6b600a53410389f38c37edb777fb20';
function inviteOk(){try{return localStorage.getItem('mi-invite')===INVITE_HASH}catch(e){return false}}
async function sha256(s){const b=await crypto.subtle.digest('SHA-256',new TextEncoder().encode(s));return[...new Uint8Array(b)].map(x=>x.toString(16).padStart(2,'0')).join('')}
if(!NATIVE&&!inviteOk()){
  const g=document.createElement('div');g.id='gate';
  g.innerHTML=`<form class="gate-in" id="gateF"><svg viewBox="0 0 120 120" width="120" height="120" aria-hidden="true"><circle cx="60" cy="58" r="26" fill="#ffd9a8"/><path d="M6 96c22-14 40-14 58-6s36 8 50-2v32H6z" fill="#bfe3c6"/><path d="M0 104c26-10 46-8 66-2s38 6 54-2v20H0z" fill="#9fd3ab"/><path d="M60 98V66" stroke="#4f9a68" stroke-width="4" stroke-linecap="round"/><path d="M60 72c-3-10-12-14-20-12 2 9 10 14 20 12z" fill="#6fbf86"/><path d="M60 68c3-11 13-15 22-13-2 10-12 15-22 13z" fill="#83cc98"/></svg>
    <h2>Murajaah Itqan</h2><p class="muted">App ini untuk jemputan sahaja. Masukkan kod yang diberi oleh rakan anda.</p>
    <div class="field"><label for="gateIn">Kod jemputan</label><input type="text" id="gateIn" autocomplete="off" autocapitalize="characters" spellcheck="false" placeholder="Contoh: ABCDE12"></div>
    <p class="small" id="gateErr" style="color:var(--bad);margin:0" hidden>Kod tidak betul. Semak semula dengan rakan yang menjemput anda.</p>
    <button class="btn pri" type="submit">Masuk</button></form>`;
  document.body.appendChild(g);
  g.querySelector('#gateF').addEventListener('submit',async e=>{e.preventDefault();const v=g.querySelector('#gateIn').value.trim().toUpperCase();
    let h='';try{h=await sha256(v)}catch(err){h=''}
    if(h===INVITE_HASH){try{localStorage.setItem('mi-invite',h)}catch(err){}g.remove();toast('Selamat datang!')}
    else{g.querySelector('#gateErr').hidden=false}});
}
if(NATIVE&&S.onboarded)setTimeout(()=>scheduleReminders(true),800);
setTimeout(()=>{const s=$('#splash');if(s){s.classList.add('out');setTimeout(()=>s.remove(),500)}},matchMedia('(prefers-reduced-motion: reduce)').matches?100:1300);
if(!NATIVE&&'serviceWorker' in navigator&&location.protocol==='https:')navigator.serviceWorker.register('sw.js').catch(()=>{});
