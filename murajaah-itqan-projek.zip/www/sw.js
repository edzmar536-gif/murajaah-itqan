// Service worker web app: simpan fail app untuk guna tanpa internet
const V='murajaah-v2';
const CORE=['./','index.html','app.css','app.js','config.js','data/core.js','layout.js','manifest.webmanifest','icons/icon-192.png','fonts/hafs.woff2',
 'fonts/shantell-sans-latin-700-normal.woff2','fonts/shantell-sans-latin-800-normal.woff2','fonts/atkinson-hyperlegible-next-latin-400-normal.woff2','fonts/atkinson-hyperlegible-next-latin-700-normal.woff2'];
self.addEventListener('install',e=>{e.waitUntil(caches.open(V).then(c=>c.addAll(CORE)).then(()=>self.skipWaiting()))});
self.addEventListener('activate',e=>{e.waitUntil(caches.keys().then(ks=>Promise.all(ks.filter(k=>k.startsWith('murajaah-')&&k!==V).map(k=>caches.delete(k)))).then(()=>self.clients.claim()))});
self.addEventListener('fetch',e=>{
  const u=new URL(e.request.url);
  if(e.request.method!=='GET'||u.origin!==location.origin||u.pathname.includes('/ai/'))return;
  const core=/\/(index\.html|app\.js|app\.css|config\.js)?$/.test(u.pathname);
  if(core){ // rangkaian dahulu supaya kemas kini cepat sampai
    e.respondWith(fetch(e.request).then(r=>{const c=r.clone();caches.open(V).then(x=>x.put(e.request,c));return r}).catch(()=>caches.match(e.request,{ignoreSearch:true})));return}
  e.respondWith(caches.match(e.request,{ignoreSearch:true}).then(hit=>hit||fetch(e.request).then(r=>{if(r.ok){const c=r.clone();caches.open(V).then(x=>x.put(e.request,c))}return r})));
});
