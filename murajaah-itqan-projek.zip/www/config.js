window.APP_CFG={aiBase:'ai/'};
