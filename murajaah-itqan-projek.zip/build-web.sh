#!/usr/bin/env bash
# Sediakan web app untuk GitHub Pages (selepas build.sh)
set -euo pipefail
rm -rf _site && cp -r www _site && mkdir -p _site/ai
curl -fsSL -o _site/ai/zipformer_a0w_ep1_a05.int8.onnx https://github.com/yazinsai/tilawa/releases/download/zipformer-a0w-ep1-a0.5/zipformer_a0w_ep1_a05.int8.onnx
curl -fsSL -o _site/ai/zipformer_quran.json https://github.com/yazinsai/tilawa/releases/download/v0.3.0/zipformer_quran.json
touch _site/.nojekyll
du -sh _site
