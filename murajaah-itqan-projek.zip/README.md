# Murajaah Itqan

App peribadi untuk jadual murajaah Al-Quran (sabaq, sabqi, manzil) ikut Mushaf Madinah 604 halaman, 15 baris.

- **App Android:** buka [Releases](../../releases/latest) dan muat turun `MurajaahItqan.apk`.
- **Web app:** buka halaman GitHub Pages repo ini dan pilih "Pasang app" / "Add to Home screen".

## Penghargaan
- Teks & fon mushaf: King Fahd Glorious Qur'an Printing Complex (QPC Hafs); susunan halaman: zonetecde/mushaf-layout.
- Terjemahan Melayu: Abdullah Muhammad Basmeih. Maksud perkataan Inggeris: Quran.com (melalui @kmaslesa/holy-quran-word-by-word-full-data).
- Audio: EveryAyah.com; bacaan Bandar Baleela dari archive.org.
- Tasmik AI: Tilawa (yazinsai/tilawa), model Zipformer & korpus berlesen NPL-1.2 (bukan komersial). Beta, boleh tersilap, tidak menyemak tajwid.
- Fon antara muka: Shantell Sans, Atkinson Hyperlegible Next (SIL OFL 1.1).

App ini percuma untuk kegunaan peribadi. Penerbitan app Al-Quran kepada umum di Malaysia memerlukan perakuan Kementerian Dalam Negeri (KDN).
