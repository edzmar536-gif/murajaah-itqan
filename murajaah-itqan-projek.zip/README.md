# Murajaah Itqan

App Android peribadi untuk jadual murajaah Quran (sabaq, sabqi, manzil) ikut Mushaf 604 muka, dengan tanda ayat lupa/tertukar dan reminder harian.

**Muat turun:** buka tab [Releases](../../releases/latest) dan muat turun `MurajaahItqan.apk`.

Teks Al-Quran: KFGQPC Hafs (melalui fawazahmed0/quran-api). Fon: KFGQPC Uthmanic Hafs, Nunito.
