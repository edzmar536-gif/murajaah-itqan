// Worker AI tasmik: Tilawa Zipformer (onnxruntime-web, WASM, 1 thread)
import * as ort from 'onnxruntime-web/wasm';
import { createZipformerSession } from '@tilawa/core';

ort.env.wasm.numThreads = 1;
let session = null, busy = Promise.resolve(), issues = [], progress = {};
const post = (m) => self.postMessage(m);

async function cachedBytes(url, label) {
  let cache = null;
  try { cache = await caches.open('tasmik-ai-v1'); const hit = await cache.match(url); if (hit) return await hit.arrayBuffer(); } catch (e) {}
  const res = await fetch(url);
  if (!res.ok) throw new Error('Gagal muat turun ' + label + ' (' + res.status + ')');
  const total = +res.headers.get('content-length') || 0, reader = res.body.getReader(), parts = [];
  let got = 0;
  for (;;) { const { done, value } = await reader.read(); if (done) break; parts.push(value); got += value.length; if (total) post({ type: 'loading', label, percent: Math.round(got / total * 100) }); }
  const blob = new Blob(parts);
  try { if (cache) await cache.put(url, new Response(blob)); } catch (e) {}
  return await blob.arrayBuffer();
}

function handle(events) {
  for (const ev of events || []) {
    if (ev.type === 'correction' && ev.state && ev.state.phase === 'error' && ev.state.issue) {
      issues.push(ev.state.issue); post({ type: 'issue', issue: ev.state.issue });
      handle(session.correct('review_later'));
    } else if (ev.type === 'correction_note' && ev.issue) {
      issues.push(ev.issue); post({ type: 'issue', issue: ev.issue });
    } else if (ev.type === 'word_progress') {
      progress[ev.surah + ':' + ev.ayah] = ev.matched_indices; post({ type: 'progress', surah: ev.surah, ayah: ev.ayah, matched: ev.matched_indices, total: ev.total_words, word: ev.word_index });
    } else if (ev.type === 'verse_match') {
      post({ type: 'verse', surah: ev.surah, ayah: ev.ayah });
    }
  }
}

self.onmessage = (e) => {
  const m = e.data;
  busy = busy.then(async () => {
    try {
      if (m.type === 'init') {
        if (m.wasmPaths) ort.env.wasm.wasmPaths = m.wasmPaths;
        if (!session) {
          const [model, corpus] = await Promise.all([
            cachedBytes(m.base + 'zipformer_a0w_ep1_a05.int8.onnx', 'model'),
            cachedBytes(m.base + 'zipformer_quran.json', 'korpus').then((b) => JSON.parse(new TextDecoder().decode(b))),
          ]);
          post({ type: 'loading', label: 'sedia', percent: 100 });
          session = await createZipformerSession({ ort, model, corpus });
          session.setMode('correction');
        }
        post({ type: 'ready' });
      } else if (m.type === 'start') {
        session.reset(); issues = []; progress = {};
        session.setExpected(m.expected);
        post({ type: 'started' });
      } else if (m.type === 'audio') {
        handle(await session.feed(m.samples));
      } else if (m.type === 'stop') {
        handle(await session.stop());
        post({ type: 'done', issues, progress });
      }
    } catch (err) { post({ type: 'error', message: String(err && err.message || err) }); }
  });
};
